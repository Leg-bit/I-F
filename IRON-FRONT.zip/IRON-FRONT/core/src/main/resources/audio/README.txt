Place cannon_fire.ogg and explosion.ogg here.
