Default libGDX BitmapFont is initialized in AssetManager.kt.
