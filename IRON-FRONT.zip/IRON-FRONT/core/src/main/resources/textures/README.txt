Procedural textures are generated automatically in AssetManager.kt.
