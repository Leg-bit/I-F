package com.ironfront

import com.badlogic.gdx.Game
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.save.SaveManager
import com.ironfront.ui.MainMenuScreen

class IronFront : Game() {
    lateinit var batch: SpriteBatch
        private set

    override fun create() {
        batch = SpriteBatch()
        AssetManager.loadAll()
        GameManager.init()
        SaveManager.load()
        AudioManager.init()
        ScreenManager.init(this)
        ScreenManager.setScreen(MainMenuScreen(this))
    }

    override fun dispose() {
        super.dispose()
        ScreenManager.dispose()
        AudioManager.dispose()
        AssetManager.dispose()
        batch.dispose()
    }
}
