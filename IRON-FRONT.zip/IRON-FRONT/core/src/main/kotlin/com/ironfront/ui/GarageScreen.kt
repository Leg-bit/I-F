package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.equipment.EquipmentLoadout
import com.ironfront.equipment.EquipmentType
import com.ironfront.save.SaveManager
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec
import com.ironfront.weapons.AmmoType
import kotlin.math.max

/** Owned tanks on the left, full technical sheet of the active tank on the right. */
class GarageScreen(game: IronFront) : UiScreen(game) {
    private var time = 0f
    private var scroll = 0f
    private var toast = ""
    private var toastTimer = 0f

    private val itemH = 88f
    private val listTop = 616f
    private val listBottom = 30f

    private fun owned(): List<TankSpec> =
        TankDatabase.all()
            .filter { GameManager.techTree.isUnlocked(it.id) }
            .sortedWith(compareBy({ it.nation.ordinal }, { it.tier }))

    private fun maxScroll(count: Int): Float = max(0f, count * itemH - (listTop - listBottom))

    override fun update(delta: Float) {
        time += delta
        if (toastTimer > 0f) toastTimer -= delta
    }

    override fun draw(b: SpriteBatch) {
        val list = owned()
        val spec = TankDatabase.get(GameManager.selectedTankId)

        // header
        UiDraw.fillRect(b, 0f, 650f, 1280f, 70f, Theme.header)
        UiDraw.fillRect(b, 0f, 648f, 1280f, 2f, Theme.border)
        UiDraw.smallButton(b, 20f, 662f, 120f, 46f, Theme.darkRed, "< BACK")
        UiDraw.big(b, "GARAGE", 165f, 703f, Theme.gold)
        UiDraw.currencyBar(b, 1250f, 668f)

        drawList(b, list)
        drawPreview(b, spec)
        drawStats(b, spec)
        drawArmor(b, spec)
        drawGun(b, spec)
        drawEquipment(b)
        drawBottom(b)

        if (toastTimer > 0f) {
            UiDraw.centered(b, AssetManager.font, toast, 800f, 330f, Theme.gold)
        }
    }

    private fun drawList(b: SpriteBatch, list: List<TankSpec>) {
        UiDraw.panel(b, 20f, 20f, 300f, 620f)
        UiDraw.small(b, "OWNED TANKS (" + list.size + ")", 32f, 632f, Theme.textDim)
        scroll = MathUtils.clamp(scroll, 0f, maxScroll(list.size))
        list.forEachIndexed { i, t ->
            val y = listTop - 26f - (i + 1) * itemH + scroll
            if (y < listBottom || y + itemH > listTop - 20f) return@forEachIndexed
            val selected = t.id == GameManager.selectedTankId
            UiDraw.fillRect(b, 28f, y + 4f, 284f, itemH - 8f, if (selected) Theme.darkGreen else Theme.panelLight)
            UiDraw.fillRect(b, 28f, y + 4f, 6f, itemH - 8f, t.nation.primary)
            if (selected) UiDraw.outlineRect(b, 28f, y + 4f, 284f, itemH - 8f, 2f, Theme.gold)
            UiDraw.tankIcon(b, t, 100f, y + itemH / 2f, UiDraw.iconScale(t, 84f))
            UiDraw.small(b, t.shortName, 160f, y + itemH - 14f, Theme.text)
            UiDraw.small(b, "T" + t.tier + " " + t.tankClass.label, 160f, y + itemH - 38f, Theme.textDim)
            UiDraw.small(b, t.nation.code, 160f, y + itemH - 60f, t.nation.primary)
        }
    }

    private fun drawPreview(b: SpriteBatch, spec: TankSpec) {
        UiDraw.panel(b, 340f, 330f, 330f, 310f)
        UiDraw.fillRect(b, 342f, 332f, 326f, 5f, spec.nation.primary)
        UiDraw.text(b, spec.name, 352f, 628f)
        UiDraw.small(b, spec.nation.label + "  |  Tier " + spec.tier + "  |  " + spec.tankClass.label, 352f, 598f, spec.nation.primary)
        val scale = UiDraw.iconScale(spec, 270f).coerceAtMost(4f)
        UiDraw.tankIcon(b, spec, 505f, 480f, scale, 0f, MathUtils.sin(time) * 20f)
        UiDraw.smallWrapped(b, spec.description, 352f, 395f, 306f)
        if (spec.isCasemate) {
            UiDraw.small(b, "Fixed gun: +/-" + spec.casemateArcDeg.toInt() + " deg traverse", 352f, 345f + 0f, Theme.orange)
        }
    }

    private fun row(b: SpriteBatch, label: String, value: String, x: Float, y: Float, w: Float) {
        UiDraw.small(b, label, x, y, Theme.textDim)
        UiDraw.rightText(b, AssetManager.fontSmall, value, x + w, y, Theme.text)
    }

    private fun drawStats(b: SpriteBatch, spec: TankSpec) {
        UiDraw.panel(b, 680f, 330f, 270f, 310f)
        UiDraw.small(b, "SPECIFICATIONS", 692f, 628f, Theme.gold)
        var y = 598f
        val x = 692f
        val w = 246f
        row(b, "Weight", spec.weightTons.toString() + " t", x, y, w); y -= 26f
        row(b, "Crew", spec.crew.toString(), x, y, w); y -= 26f
        row(b, "Engine", spec.enginePowerHp.toString() + " hp", x, y, w); y -= 26f
        row(b, "Power / weight", String.format("%.1f hp/t", spec.powerToWeight), x, y, w); y -= 26f
        row(b, "Top speed", spec.maxSpeedKmh.toInt().toString() + " km/h", x, y, w); y -= 26f
        row(b, "Hit points", spec.maxHp.toInt().toString(), x, y, w); y -= 26f
        row(b, "Hull traverse", spec.hullTurnSpeedDeg.toInt().toString() + " deg/s", x, y, w); y -= 26f
        row(b, "Turret traverse", spec.turretTurnSpeedDeg.toInt().toString() + " deg/s", x, y, w); y -= 26f
        row(b, "Length x width", String.format("%.1f x %.1f m", spec.design.hullLenM, spec.design.hullWidM), x, y, w)
    }

    private fun drawArmor(b: SpriteBatch, spec: TankSpec) {
        UiDraw.panel(b, 960f, 330f, 300f, 310f)
        UiDraw.small(b, "ARMOUR  (mm @ slope)", 972f, 628f, Theme.gold)
        val a = spec.armor
        val colX = intArrayOf(1040, 1105, 1175)
        UiDraw.small(b, "FRONT", colX[0].toFloat(), 600f, Theme.textDim)
        UiDraw.small(b, "SIDE", colX[1].toFloat(), 600f, Theme.textDim)
        UiDraw.small(b, "REAR", colX[2].toFloat(), 600f, Theme.textDim)

        val hull = listOf(a.hullFront, a.hullSide, a.hullRear)
        val turret = listOf(a.turretFront, a.turretSide, a.turretRear)
        val casemate = spec.isCasemate
        UiDraw.small(b, "HULL", 972f, 572f, Theme.text)
        UiDraw.small(b, if (casemate) "CASEMATE" else "TURRET", 972f, 500f, Theme.text)
        for (i in 0 until 3) {
            val hf = hull[i]
            val tf = turret[i]
            val x = colX[i].toFloat()
            UiDraw.small(b, hf.thicknessMm.toInt().toString() + "@" + hf.slopeDeg.toInt(), x, 572f, Theme.text)
            UiDraw.bar(b, x, 550f, 56f, 9f, hf.thicknessMm / 250f, Theme.green)
            UiDraw.small(b, tf.thicknessMm.toInt().toString() + "@" + tf.slopeDeg.toInt(), x, 500f, Theme.text)
            UiDraw.bar(b, x, 478f, 56f, 9f, tf.thicknessMm / 250f, Theme.blue)
        }
        val eff = a.hullFront.effective(0f)
        UiDraw.small(b, "Effective hull front: " + eff.toInt() + " mm", 972f, 440f, Theme.gold)
        UiDraw.smallWrapped(
            b,
            "Shells hitting at a steep angle ricochet: AP 70 deg, APCR 68 deg. Calibre 3x thicker than the plate overmatches and never bounces.",
            972f, 412f, 276f
        )
    }

    private fun drawGun(b: SpriteBatch, spec: TankSpec) {
        UiDraw.panel(b, 340f, 150f, 610f, 170f)
        val g = spec.gun
        UiDraw.small(b, "ARMAMENT", 352f, 308f, Theme.gold)
        UiDraw.text(b, g.name, 352f, 286f)
        UiDraw.small(
            b,
            "Calibre " + g.caliberMm + " mm   Reload " + g.reloadTimeSec + " s   DPS " + g.damagePerSecond.toInt() +
                "   Muzzle velocity " + g.shellSpeed.toInt() + " m/s",
            352f, 252f, Theme.textDim
        )
        var x = 352f
        for (ammo in AmmoType.values()) {
            val has = g.availableAmmo.contains(ammo)
            UiDraw.fillRect(b, x, 160f, 190f, 82f, Theme.panelLight)
            UiDraw.fillRect(b, x, 160f, 5f, 82f, if (has) ammo.color else Theme.grey)
            UiDraw.small(b, ammo.shortName, x + 14f, 234f, if (has) ammo.color else Theme.grey)
            if (has) {
                UiDraw.small(b, "Pen " + g.penFor(ammo).toInt() + " mm", x + 14f, 210f, Theme.text)
                UiDraw.small(b, "Dmg " + (g.baseDamage * ammo.dmgMultiplier).toInt(), x + 14f, 188f, Theme.text)
                UiDraw.bar(b, x + 100f, 205f, 80f, 8f, g.penFor(ammo) / 320f, ammo.color)
                UiDraw.bar(b, x + 100f, 183f, 80f, 8f, g.baseDamage * ammo.dmgMultiplier / 320f, Theme.red)
            } else {
                UiDraw.small(b, "not available", x + 14f, 205f, Theme.grey)
            }
            x += 198f
        }
    }

    private fun equipX(i: Int): Float = 970f + (i % 2) * 150f
    private fun equipY(i: Int): Float = 232f - (i / 2) * 76f

    private fun drawEquipment(b: SpriteBatch) {
        UiDraw.panel(b, 960f, 150f, 300f, 170f)
        UiDraw.small(
            b,
            "EQUIPMENT (" + GameManager.equippedEquipment.size + "/" + EquipmentLoadout.MAX_SLOTS + ")",
            972f, 308f, Theme.gold
        )
        EquipmentType.values().forEachIndexed { i, e ->
            val x = equipX(i)
            val y = equipY(i)
            val owned = GameManager.ownedEquipment.contains(e)
            val on = GameManager.equippedEquipment.contains(e)
            val fill = when {
                on -> Theme.darkGreen
                owned -> Theme.panelLight
                else -> Theme.dark
            }
            UiDraw.fillRect(b, x, y, 140f, 68f, fill)
            UiDraw.outlineRect(b, x, y, 140f, 68f, 2f, if (on) Theme.gold else Theme.border)
            UiDraw.small(b, e.title, x + 8f, y + 60f, Theme.text)
            UiDraw.smallWrapped(b, e.description, x + 8f, y + 40f, 126f, Theme.textDim)
            val status = when {
                on -> "EQUIPPED"
                owned -> "TAP TO EQUIP"
                else -> e.costCredits.toString() + " CR"
            }
            UiDraw.small(b, status, x + 8f, y + 14f, if (owned) Theme.green else Theme.gold)
        }
    }

    private fun drawBottom(b: SpriteBatch) {
        UiDraw.panel(b, 340f, 20f, 920f, 120f)
        UiDraw.small(b, "Tap a tank in the list to make it your active tank.", 356f, 118f, Theme.textDim)
        UiDraw.small(b, "Research new tanks in the Tech Tree.", 356f, 92f, Theme.textDim)
        UiDraw.button(b, 700f, 40f, 260f, 80f, Color(0.18f, 0.30f, 0.45f, 1f), "TECH TREE")
        UiDraw.button(b, 980f, 40f, 260f, 80f, Color(0.75f, 0.27f, 0.14f, 1f), "BATTLE!")
    }

    private fun say(text: String) {
        toast = text
        toastTimer = 2.2f
    }

    override fun onDrag(dx: Float, dy: Float) {
        scroll -= dy
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 20f, 662f, 120f, 46f)) {
            SaveManager.save()
            AudioManager.playClick()
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }
        if (UiDraw.hit(x, y, 700f, 40f, 260f, 80f)) {
            SaveManager.save()
            ScreenManager.setScreen(TechTreeScreen(game))
            return
        }
        if (UiDraw.hit(x, y, 980f, 40f, 260f, 80f)) {
            SaveManager.save()
            ScreenManager.setScreen(BattleSetupScreen(game))
            return
        }

        // tank list
        val list = owned()
        list.forEachIndexed { i, t ->
            val iy = listTop - 26f - (i + 1) * itemH + scroll
            if (iy < listBottom || iy + itemH > listTop - 20f) return@forEachIndexed
            if (UiDraw.hit(x, y, 28f, iy + 4f, 284f, itemH - 8f)) {
                GameManager.selectedTankId = t.id
                SaveManager.save()
                AudioManager.playClick()
                return
            }
        }

        // equipment
        EquipmentType.values().forEachIndexed { i, e ->
            if (UiDraw.hit(x, y, equipX(i), equipY(i), 140f, 68f)) {
                AudioManager.playClick()
                val owned = GameManager.ownedEquipment.contains(e)
                if (!owned) {
                    if (GameManager.wallet.spendCredits(e.costCredits)) {
                        GameManager.ownedEquipment.add(e)
                        if (GameManager.equippedEquipment.size < EquipmentLoadout.MAX_SLOTS) GameManager.equippedEquipment.add(e)
                        say("Bought " + e.title)
                    } else {
                        say("Not enough credits")
                    }
                } else if (GameManager.equippedEquipment.contains(e)) {
                    GameManager.equippedEquipment.remove(e)
                } else if (GameManager.equippedEquipment.size < EquipmentLoadout.MAX_SLOTS) {
                    GameManager.equippedEquipment.add(e)
                } else {
                    say("All 3 slots are full")
                }
                SaveManager.save()
                return
            }
        }
    }
}
