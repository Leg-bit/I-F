package com.ironfront.tanks

import com.badlogic.gdx.graphics.Color
import kotlin.math.max
import kotlin.math.roundToInt

enum class TurretShape { ROUND, OCTAGON, ANGULAR, BOX, CAST, FLAT_CAST, MOUNT }

enum class Muzzle { NONE, SINGLE, DOUBLE, PEPPERPOT, FLASH }

/** Factory paint scheme. camoA / camoB are painted as blotches on top of [body]. */
enum class Paint(val body: Color, val camoA: Color?, val camoB: Color?) {
    PANZER_GREY(Color(0.36f, 0.38f, 0.40f, 1f), null, null),
    GERMAN_CAMO(Color(0.70f, 0.60f, 0.34f, 1f), Color(0.30f, 0.37f, 0.22f, 1f), Color(0.42f, 0.27f, 0.17f, 1f)),
    SOVIET_GREEN(Color(0.30f, 0.40f, 0.21f, 1f), null, null),
    US_OLIVE(Color(0.31f, 0.36f, 0.23f, 1f), null, null),
    BRITISH_KHAKI(Color(0.45f, 0.41f, 0.29f, 1f), Color(0.27f, 0.32f, 0.22f, 1f), null),
    JAPANESE_CAMO(Color(0.43f, 0.39f, 0.23f, 1f), Color(0.26f, 0.33f, 0.21f, 1f), Color(0.43f, 0.25f, 0.17f, 1f))
}

/**
 * Real-world dimensions (metres) of a tank, used to paint its top-down 2D sprite
 * and to size its collision box. 1 metre = [PX_PER_M] pixels.
 */
data class TankDesign(
    val hullLenM: Float,
    val hullWidM: Float,
    val trackWidM: Float = 0.40f,
    val noseM: Float = 0.8f,
    val noseTaper: Float = 0.10f,
    val fenders: Boolean = true,
    val skirts: Boolean = false,
    val casemate: Boolean = false,
    val turretShape: TurretShape = TurretShape.ROUND,
    val turretLenM: Float = 1.7f,
    val turretWidM: Float = 1.7f,
    val turretOffsetM: Float = 0f,
    val bustleM: Float = 0f,
    val cupola: Boolean = true,
    val openTop: Boolean = false,
    val barrelM: Float = 3f,
    val barrelThickPx: Int = 3,
    val muzzle: Muzzle = Muzzle.NONE,
    val mantletWidM: Float = 0.5f,
    val paint: Paint = Paint.PANZER_GREY,
    val engineDeckFrac: Float = 0.26f,
    val seed: Int = 1
) {
    val hullLenPx: Int get() = (hullLenM * PX_PER_M).roundToInt()
    val hullWidPx: Int get() = (hullWidM * PX_PER_M).roundToInt()
    val trackWidPx: Int get() = max(3, (trackWidM * PX_PER_M).roundToInt())
    val nosePx: Int get() = (noseM * PX_PER_M).roundToInt().coerceIn(4, hullLenPx / 2)

    val turretRxPx: Int
        get() = if (turretShape == TurretShape.MOUNT) 4 else max(4, (turretLenM * PX_PER_M / 2f).roundToInt())
    val turretRyPx: Int
        get() = if (turretShape == TurretShape.MOUNT) 4 else max(4, (turretWidM * PX_PER_M / 2f).roundToInt())
    val turretOffsetPx: Int get() = (turretOffsetM * PX_PER_M).roundToInt()
    val bustlePx: Int get() = (bustleM * PX_PER_M).roundToInt()
    val barrelPx: Int get() = max(6, (barrelM * PX_PER_M).roundToInt())
    val mantletPx: Int get() = max(4, (mantletWidM * PX_PER_M).roundToInt())

    val muzzleLenPx: Int
        get() = when (muzzle) {
            Muzzle.NONE -> 0
            Muzzle.SINGLE -> 3
            Muzzle.DOUBLE -> 5
            Muzzle.PEPPERPOT -> 5
            Muzzle.FLASH -> 3
        }

    /** Distance from the turret pivot to the muzzle tip. */
    val muzzleReachPx: Int get() = turretRxPx + barrelPx + muzzleLenPx

    /** Radius around the turret pivot that counts as a turret hit. */
    val turretHitRadiusPx: Float get() = max(turretRxPx, turretRyPx) * 0.9f

    /** How far the gun sticks out in front of the hull nose (used to centre icons). */
    val overhangPx: Int get() = max(0, turretOffsetPx + muzzleReachPx - hullLenPx / 2)

    companion object {
        const val PX_PER_M = 14f
    }
}
