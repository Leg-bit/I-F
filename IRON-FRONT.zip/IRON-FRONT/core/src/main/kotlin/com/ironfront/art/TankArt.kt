package com.ironfront.art

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Pixmap
import com.ironfront.nations.Nation
import com.ironfront.tanks.Muzzle
import com.ironfront.tanks.TankDesign
import com.ironfront.tanks.TankSpec
import com.ironfront.tanks.TurretShape
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Paints a top-down sprite of a real tank from its [TankDesign].
 * Sprites face right (+x). The hull sprite is centred on the tank,
 * the turret sprite is centred on the turret pivot ([Result.pivotX]).
 */
object TankArt {
    const val PAD = 3

    class Result(val hull: Pixmap, val turret: Pixmap, val pivotX: Int)

    private val STEEL = Color(0.20f, 0.20f, 0.21f, 1f)
    private val STEEL_LIGHT = Color(0.42f, 0.42f, 0.43f, 1f)
    private val STEEL_DARK = Color(0.10f, 0.10f, 0.11f, 1f)
    private val TRACK = Color(0.12f, 0.12f, 0.12f, 1f)
    private val TRACK_LIGHT = Color(0.24f, 0.24f, 0.22f, 1f)
    private val WHITE = Color(0.96f, 0.96f, 0.96f, 1f)

    fun build(spec: TankSpec): Result {
        val d = spec.design
        val hull = drawHull(d, spec.nation)
        val turretPair = drawTurret(d)
        return Result(hull, turretPair.first, turretPair.second)
    }

    // ------------------------------------------------------------------ hull

    private fun drawHull(d: TankDesign, nation: Nation): Pixmap {
        val l = d.hullLenPx
        val w = d.hullWidPx
        val pm = Pixmap(l + PAD * 2, w + PAD * 2, Pixmap.Format.RGBA8888)
        pm.setBlending(Pixmap.Blending.None)
        val ox = PAD
        val oy = PAD
        val body = d.paint.body
        val dark = shade(body, 0.70f)
        val mid = shade(body, 0.88f)
        val light = shade(body, 1.20f)
        val tw = d.trackWidPx
        val nose = d.nosePx

        // tracks with tread marks
        pm.rect(ox, oy, l, tw, TRACK)
        pm.rect(ox, oy + w - tw, l, tw, TRACK)
        var u = 1
        while (u < l - 1) {
            pm.rect(ox + u, oy, 1, tw, TRACK_LIGHT)
            pm.rect(ox + u, oy + w - tw, 1, tw, TRACK_LIGHT)
            u += 3
        }
        // rounded track ends
        pm.clearDot(ox, oy)
        pm.clearDot(ox + l - 1, oy)
        pm.clearDot(ox, oy + w - 1)
        pm.clearDot(ox + l - 1, oy + w - 1)

        // hull body: deck + sloped nose
        val bodyTop = oy + tw - 1
        val bodyH = w - 2 * tw + 2
        val deckLen = l - nose
        pm.rect(ox + 1, bodyTop, deckLen - 1, bodyH, body)
        val taper = (bodyH * d.noseTaper).roundToInt()
        pm.fillPoly(
            light,
            ox + deckLen, bodyTop,
            ox + l - 1, bodyTop + taper,
            ox + l - 1, bodyTop + bodyH - 1 - taper,
            ox + deckLen, bodyTop + bodyH - 1
        )
        // shaded plate between glacis and deck
        pm.seg(ox + deckLen, bodyTop + 1, ox + deckLen, bodyTop + bodyH - 2, dark)

        // fenders cover the middle of the tracks
        if (d.fenders) {
            pm.rect(ox + 4, oy, max(4, deckLen - 2), tw - 1, mid)
            pm.rect(ox + 4, oy + w - tw + 1, max(4, deckLen - 2), tw - 1, mid)
            pm.rect(ox + 4, oy, max(4, deckLen - 2), 1, light)
            pm.rect(ox + 4, oy + w - 1, max(4, deckLen - 2), 1, dark)
        }

        // side skirts (Schuerzen / armoured sides) in segments
        if (d.skirts) {
            var k = (l * 0.14f).roundToInt()
            val end = (l * 0.84f).roundToInt()
            while (k + 8 < end) {
                pm.rect(ox + k, oy, 8, tw, mid)
                pm.rect(ox + k, oy, 8, 1, light)
                pm.rect(ox + k + 8, oy, 1, tw, dark)
                pm.rect(ox + k, oy + w - tw, 8, tw, mid)
                pm.rect(ox + k, oy + w - 1, 8, 1, dark)
                pm.rect(ox + k + 8, oy + w - tw, 1, tw, dark)
                k += 9
            }
        }

        // camouflage on the deck
        paintCamo(pm, d, ox + 4, bodyTop + 3, max(2, deckLen - 8), max(2, bodyH - 6), 7)

        // engine deck with grille and exhausts
        val engLen = max(6, (l * d.engineDeckFrac).roundToInt())
        pm.rect(ox + 3, bodyTop + 2, engLen, max(2, bodyH - 4), shade(body, 0.62f))
        var gy = bodyTop + 3
        while (gy < bodyTop + bodyH - 3) {
            pm.rect(ox + 5, gy, max(2, engLen - 4), 1, shade(body, 0.45f))
            gy += 2
        }
        pm.rect(ox, bodyTop + 2, 3, 2, Color(0.28f, 0.24f, 0.22f, 1f))
        pm.rect(ox, bodyTop + bodyH - 4, 3, 2, Color(0.28f, 0.24f, 0.22f, 1f))

        // national marking on the engine deck
        val r = min(max(3, (engLen - 4) / 2), max(3, bodyH / 2 - 3)).coerceAtMost(8)
        drawInsignia(pm, nation, ox + 3 + engLen / 2, oy + w / 2, r)

        if (d.casemate) {
            drawCasemate(pm, d, ox, bodyTop, bodyH, body)
        } else {
            // driver hatch and hull machine gun
            pm.rect(ox + deckLen - 8, bodyTop + bodyH / 4 - 2, 6, 4, light)
            pm.setColor(dark)
            pm.drawRectangle(ox + deckLen - 8, bodyTop + bodyH / 4 - 2, 6, 4)
            pm.disc(ox + deckLen + 1, bodyTop + bodyH * 3 / 4, 1, STEEL_DARK)
        }

        // crisp outline
        pm.setColor(dark)
        pm.drawRectangle(ox + 1, bodyTop, deckLen - 1, bodyH)
        pm.seg(ox + deckLen, bodyTop, ox + l - 1, bodyTop + taper, dark)
        pm.seg(ox + deckLen, bodyTop + bodyH - 1, ox + l - 1, bodyTop + bodyH - 1 - taper, dark)
        pm.seg(ox + l - 1, bodyTop + taper, ox + l - 1, bodyTop + bodyH - 1 - taper, dark)
        return pm
    }

    private fun drawCasemate(pm: Pixmap, d: TankDesign, ox: Int, bodyTop: Int, bodyH: Int, body: Color) {
        val l = d.hullLenPx
        val dark = shade(body, 0.65f)
        val light = shade(body, 1.15f)
        val x0 = ox + (l * 0.22f).roundToInt()
        val x1 = ox + (l * 0.88f).roundToInt()
        val inset = 2
        val frontCut = (bodyH * 0.16f).roundToInt()
        val pts = intArrayOf(
            x0, bodyTop + inset,
            x1, bodyTop + inset + frontCut,
            x1, bodyTop + bodyH - 1 - inset - frontCut,
            x0, bodyTop + bodyH - 1 - inset
        )
        pm.fillPoly(shade(body, 0.92f), *pts)
        // sloped front plate highlight
        pm.fillPoly(
            light,
            x1 - 5, bodyTop + inset + frontCut / 2,
            x1, bodyTop + inset + frontCut,
            x1, bodyTop + bodyH - 1 - inset - frontCut,
            x1 - 5, bodyTop + bodyH - 1 - inset - frontCut / 2
        )
        if (d.openTop) {
            pm.fillPoly(
                shade(body, 0.35f),
                x0 + 3, bodyTop + inset + 3,
                x1 - 7, bodyTop + inset + frontCut + 2,
                x1 - 7, bodyTop + bodyH - 1 - inset - frontCut - 2,
                x0 + 3, bodyTop + bodyH - 1 - inset - 3
            )
        } else {
            // roof hatches
            pm.rect(x0 + 6, bodyTop + bodyH / 4, 5, 4, light)
            pm.disc(x0 + 10, bodyTop + bodyH * 3 / 4 - 2, 3, dark)
            pm.disc(x0 + 10, bodyTop + bodyH * 3 / 4 - 2, 2, light)
        }
        pm.outlinePoly(dark, pts)
    }

    private fun paintCamo(pm: Pixmap, d: TankDesign, x: Int, y: Int, w: Int, h: Int, count: Int) {
        val a = d.paint.camoA ?: return
        val b = d.paint.camoB ?: a
        val rnd = Random(d.seed.toLong() * 31L + w)
        for (i in 0 until count) {
            val rad = 2 + rnd.nextInt(3)
            val cx = x + rad + rnd.nextInt(max(1, w - rad * 2))
            val cy = y + rad + rnd.nextInt(max(1, h - rad * 2))
            pm.disc(cx, cy, rad, if (i % 2 == 0) a else b)
        }
    }

    private fun drawInsignia(pm: Pixmap, nation: Nation, cx: Int, cy: Int, r: Int) {
        when (nation) {
            Nation.GERMANY -> {
                val t = max(1, r / 3)
                pm.rect(cx - r, cy - t - 1, 2 * r + 1, 2 * t + 3, WHITE)
                pm.rect(cx - t - 1, cy - r, 2 * t + 3, 2 * r + 1, WHITE)
                pm.rect(cx - r + 1, cy - t, 2 * r - 1, 2 * t + 1, STEEL_DARK)
                pm.rect(cx - t, cy - r + 1, 2 * t + 1, 2 * r - 1, STEEL_DARK)
            }
            Nation.USSR -> star(pm, cx, cy, r, Color(0.85f, 0.10f, 0.10f, 1f))
            Nation.USA -> {
                pm.disc(cx, cy, r, Color(0.15f, 0.25f, 0.55f, 1f))
                star(pm, cx, cy, max(2, r - 1), WHITE)
            }
            Nation.UK -> {
                pm.disc(cx, cy, r, Color(0.15f, 0.22f, 0.55f, 1f))
                pm.disc(cx, cy, max(1, r * 2 / 3), WHITE)
                pm.disc(cx, cy, max(1, r / 3), Color(0.80f, 0.12f, 0.15f, 1f))
            }
            Nation.JAPAN -> {
                pm.disc(cx, cy, r, WHITE)
                pm.disc(cx, cy, max(1, r - 1), Color(0.80f, 0.08f, 0.10f, 1f))
            }
        }
    }

    private fun star(pm: Pixmap, cx: Int, cy: Int, r: Int, c: Color) {
        val pts = IntArray(24)
        pts[0] = cx
        pts[1] = cy
        for (i in 0..10) {
            val ang = -Math.PI / 2.0 + (i % 10) * Math.PI / 5.0
            val rad = if (i % 2 == 0) r.toDouble() else r * 0.42
            pts[2 + i * 2] = cx + (cos(ang) * rad).roundToInt()
            pts[3 + i * 2] = cy + (sin(ang) * rad).roundToInt()
        }
        pm.fillPoly(c, *pts)
    }

    // ---------------------------------------------------------------- turret

    private fun drawTurret(d: TankDesign): Pair<Pixmap, Int> {
        val rx = d.turretRxPx
        val ry = d.turretRyPx
        val bustle = d.bustlePx
        val back = rx + bustle
        val barrel = d.barrelPx
        val muzzleLen = d.muzzleLenPx
        val width = PAD + back + rx + barrel + muzzleLen + PAD
        val height = max(ry * 2, max(d.barrelThickPx + 8, d.mantletPx + 2)) + PAD * 2
        val pm = Pixmap(width, height, Pixmap.Format.RGBA8888)
        pm.setBlending(Pixmap.Blending.None)

        val cx = PAD + back
        val cy = height / 2
        val body = shade(d.paint.body, 1.06f)
        val dark = shade(body, 0.66f)
        val mid = shade(body, 0.86f)
        val light = shade(body, 1.22f)

        if (d.turretShape == TurretShape.MOUNT) {
            // fixed casemate gun: just the mantlet ball and the barrel
            pm.disc(cx, cy, 4, dark)
            pm.disc(cx, cy, 3, mid)
            pm.rect(cx + 2, cy - d.mantletPx / 2, 3, d.mantletPx, dark)
            pm.rect(cx + 2, cy - d.mantletPx / 2, 3, 1, light)
        } else {
            if (bustle > 0) {
                val bh = (ry * 1.35f).roundToInt()
                pm.rect(cx - rx - bustle, cy - bh / 2, bustle + 4, bh, mid)
                pm.setColor(dark)
                pm.drawRectangle(cx - rx - bustle, cy - bh / 2, bustle + 4, bh)
                pm.rect(cx - rx - bustle + 1, cy - bh / 2 + 1, bustle + 2, 1, light)
            }
            val poly = shapePoly(d.turretShape, cx, cy, rx, ry)
            pm.fillPoly(body, *poly)
            val roof = shapePoly(d.turretShape, cx, cy, max(2, (rx * 0.72f).roundToInt()), max(2, (ry * 0.72f).roundToInt()))
            pm.fillPoly(light, *roof)
            pm.outlinePoly(dark, poly)
            paintCamo(pm, d, cx - rx / 2, cy - ry / 2, max(2, rx), max(2, ry), 4)

            if (d.openTop) {
                val hole = shapePoly(d.turretShape, cx, cy, max(2, (rx * 0.62f).roundToInt()), max(2, (ry * 0.62f).roundToInt()))
                pm.fillPoly(shade(body, 0.30f), *hole)
                pm.outlinePoly(dark, hole)
            } else {
                // loader hatch
                val hw = max(3, rx / 3)
                val hh = max(3, ry / 3)
                pm.rect(cx - rx / 3, cy - ry / 2 - hh / 2, hw, hh, light)
                pm.setColor(dark)
                pm.drawRectangle(cx - rx / 3, cy - ry / 2 - hh / 2, hw, hh)
                // commander cupola
                if (d.cupola) {
                    val cr = max(3, ry * 28 / 100)
                    pm.disc(cx - rx / 4, cy + ry / 2, cr, dark)
                    pm.disc(cx - rx / 4, cy + ry / 2, cr - 1, mid)
                    pm.disc(cx - rx / 4, cy + ry / 2, max(1, cr - 2), light)
                }
            }
            // gun mantlet
            val mh = d.mantletPx
            pm.rect(cx + rx - 3, cy - mh / 2, 5, mh, dark)
            pm.rect(cx + rx - 3, cy - mh / 2, 5, 1, mid)
        }

        // barrel
        val t = d.barrelThickPx
        val x0 = cx + rx - 1
        pm.rect(x0, cy - t / 2, barrel + 1, t, STEEL)
        pm.rect(x0, cy - t / 2, barrel + 1, 1, STEEL_LIGHT)
        pm.rect(x0, cy - t / 2 + t - 1, barrel + 1, 1, STEEL_DARK)
        if (t >= 4) {
            pm.rect(x0 + (barrel * 0.55f).roundToInt(), cy - t / 2 - 1, 4, t + 2, STEEL_DARK)
        }
        val tip = x0 + barrel
        when (d.muzzle) {
            Muzzle.NONE -> {}
            Muzzle.SINGLE -> pm.rect(tip - 1, cy - t / 2 - 1, 3, t + 2, STEEL_DARK)
            Muzzle.DOUBLE -> {
                pm.rect(tip - 4, cy - t / 2 - 1, 2, t + 2, STEEL_DARK)
                pm.rect(tip - 1, cy - t / 2 - 1, 2, t + 2, STEEL_DARK)
            }
            Muzzle.PEPPERPOT -> {
                pm.rect(tip - 3, cy - t / 2 - 2, 5, t + 4, STEEL_DARK)
                pm.rect(tip - 2, cy - t / 2 - 2, 1, t + 4, STEEL_LIGHT)
            }
            Muzzle.FLASH -> pm.fillPoly(STEEL_DARK, tip - 2, cy - t / 2 - 1, tip + 1, cy, tip - 2, cy + t / 2 + 1)
        }
        return Pair(pm, cx)
    }

    private fun shapePoly(shape: TurretShape, cx: Int, cy: Int, rx: Int, ry: Int): IntArray = when (shape) {
        TurretShape.ROUND -> superEllipse(cx, cy, rx, ry, 2.0)
        TurretShape.CAST -> superEllipse(cx, cy, rx, ry, 2.3)
        TurretShape.FLAT_CAST -> superEllipse(cx, cy, rx, ry, 2.0)
        TurretShape.BOX -> superEllipse(cx, cy, rx, ry, 5.0)
        TurretShape.MOUNT -> superEllipse(cx, cy, rx, ry, 2.0)
        TurretShape.OCTAGON -> scaled(
            floatArrayOf(
                -1.0f, -0.55f, -0.55f, -1.0f, 0.45f, -0.95f, 1.0f, -0.45f,
                1.0f, 0.45f, 0.45f, 0.95f, -0.55f, 1.0f, -1.0f, 0.55f
            ), cx, cy, rx, ry
        )
        TurretShape.ANGULAR -> scaled(
            floatArrayOf(
                -1.0f, -0.70f, -0.75f, -1.0f, 0.55f, -0.85f, 1.0f, -0.45f,
                1.0f, 0.45f, 0.55f, 0.85f, -0.75f, 1.0f, -1.0f, 0.70f
            ), cx, cy, rx, ry
        )
    }

    private fun scaled(pts: FloatArray, cx: Int, cy: Int, rx: Int, ry: Int): IntArray {
        val out = IntArray(pts.size)
        for (i in pts.indices) {
            out[i] = if (i % 2 == 0) cx + (pts[i] * rx).roundToInt() else cy + (pts[i] * ry).roundToInt()
        }
        return out
    }

    private fun superEllipse(cx: Int, cy: Int, rx: Int, ry: Int, e: Double): IntArray {
        val n = 24
        val out = IntArray(n * 2)
        for (i in 0 until n) {
            val t = 2.0 * Math.PI * i / n
            val c = cos(t)
            val s = sin(t)
            val x = Math.signum(c) * Math.pow(abs(c), 2.0 / e)
            val y = Math.signum(s) * Math.pow(abs(s), 2.0 / e)
            out[i * 2] = cx + (x * rx).roundToInt()
            out[i * 2 + 1] = cy + (y * ry).roundToInt()
        }
        return out
    }
}
