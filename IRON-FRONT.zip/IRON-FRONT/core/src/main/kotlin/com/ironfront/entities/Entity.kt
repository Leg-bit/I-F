package com.ironfront.entities

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.Rectangle
import com.badlogic.gdx.math.Vector2

abstract class Entity(
    val id: String,
    x: Float,
    y: Float,
    var width: Float,
    var height: Float
) {
    val position = Vector2(x, y)
    val velocity = Vector2(0f, 0f)
    var rotation: Float = 0f
    var isAlive: Boolean = true

    val bounds: Rectangle
        get() = Rectangle(position.x - width / 2f, position.y - height / 2f, width, height)

    abstract fun update(delta: Float)
    abstract fun render(batch: SpriteBatch)
}
