package com.ironfront.weapons

import com.ironfront.weapons.AmmoKind.AP
import com.ironfront.weapons.AmmoKind.APCBC
import com.ironfront.weapons.AmmoKind.APCR
import com.ironfront.weapons.AmmoKind.HE
import com.ironfront.weapons.AmmoKind.HEAT

/**
 * Real tank guns. Constructor order for AmmoSpec:
 * (kind, shell mass kg, muzzle velocity m/s, pen@100m mm, pen@1000m mm, rounds carried, core caliber mm).
 * Penetration = flat plate at 0 degrees; values are rounded from public firing tables
 * and can be tuned freely, this file is the single place to do it.
 */
object Guns {
    // ---------------------------------------------------------------- USSR
    val K20_45 = GunSpec("45 mm 20-K L/46", 45, 46f, 5f, listOf(
        AmmoSpec(AP, 1.43f, 760f, 51f, 31f, 40, 45f),
        AmmoSpec(HE, 2.14f, 450f, 14f, 14f, 20, 45f)
    ))
    val F34 = GunSpec("76.2 mm F-34 L/41.5", 76, 41.5f, 7f, listOf(
        AmmoSpec(APCBC, 6.3f, 662f, 70f, 52f, 40, 76f),
        AmmoSpec(APCR, 3.0f, 950f, 105f, 58f, 5, 30f),
        AmmoSpec(HE, 6.2f, 680f, 23f, 23f, 25, 76f)
    ))
    val ZIS5 = F34.copy(name = "76.2 mm ZiS-5 L/41.5")
    val D5S = GunSpec("85 mm D-5S L/48.8", 85, 48.8f, 6.5f, listOf(
        AmmoSpec(APCBC, 9.2f, 792f, 118f, 96f, 30, 85f),
        AmmoSpec(APCR, 5.0f, 1050f, 155f, 95f, 5, 38f),
        AmmoSpec(HE, 9.5f, 785f, 26f, 26f, 25, 85f)
    ))
    val ZIS_S53 = GunSpec("85 mm ZIS-S-53 L/54.6", 85, 54.6f, 6f, listOf(
        AmmoSpec(APCBC, 9.2f, 792f, 120f, 98f, 30, 85f),
        AmmoSpec(APCR, 5.0f, 1050f, 160f, 99f, 5, 38f),
        AmmoSpec(HE, 9.5f, 800f, 26f, 26f, 25, 85f)
    ))
    val D25T = GunSpec("122 mm D-25T L/43", 122, 43f, 12f, listOf(
        AmmoSpec(APCBC, 25f, 790f, 157f, 128f, 12, 122f),
        AmmoSpec(HE, 25f, 800f, 37f, 37f, 8, 122f)
    ))

    // -------------------------------------------------------------- GERMANY
    val KWK38_20 = GunSpec("2 cm KwK 38 L/55", 20, 55f, 0.5f, listOf(
        AmmoSpec(AP, 0.12f, 780f, 29f, 8f, 120, 20f, damageOverride = 12f),
        AmmoSpec(HE, 0.12f, 900f, 6f, 6f, 60, 20f, damageOverride = 14f)
    ))
    val KWK38_50 = GunSpec("5 cm KwK 38 L/42", 50, 42f, 5f, listOf(
        AmmoSpec(APCBC, 2.06f, 685f, 72f, 42f, 45, 50f),
        AmmoSpec(APCR, 0.9f, 1180f, 90f, 28f, 5, 20f),
        AmmoSpec(HE, 1.8f, 550f, 15f, 15f, 30, 50f)
    ))
    val KWK40 = GunSpec("7.5 cm KwK 40 L/43", 75, 43f, 6f, listOf(
        AmmoSpec(APCBC, 6.8f, 740f, 95f, 78f, 40, 75f),
        AmmoSpec(APCR, 4.1f, 933f, 126f, 52f, 4, 30f),
        AmmoSpec(HEAT, 4.4f, 450f, 70f, 70f, 6, 75f),
        AmmoSpec(HE, 5.74f, 590f, 22f, 22f, 40, 75f)
    ))
    val STUK40 = GunSpec("7.5 cm StuK 40 L/48", 75, 48f, 6f, listOf(
        AmmoSpec(APCBC, 6.8f, 770f, 98f, 82f, 30, 75f),
        AmmoSpec(APCR, 4.1f, 990f, 136f, 58f, 4, 30f),
        AmmoSpec(HEAT, 4.4f, 450f, 70f, 70f, 4, 75f),
        AmmoSpec(HE, 5.74f, 600f, 22f, 22f, 20, 75f)
    ))
    val KWK42 = GunSpec("7.5 cm KwK 42 L/70", 75, 70f, 6f, listOf(
        AmmoSpec(APCBC, 6.8f, 925f, 149f, 124f, 30, 75f),
        AmmoSpec(APCR, 4.75f, 1120f, 194f, 149f, 6, 30f),
        AmmoSpec(HE, 5.74f, 700f, 23f, 23f, 30, 75f)
    ))
    val KWK36 = GunSpec("8.8 cm KwK 36 L/56", 88, 56f, 8f, listOf(
        AmmoSpec(APCBC, 10.2f, 773f, 120f, 100f, 40, 88f),
        AmmoSpec(APCR, 7.3f, 930f, 165f, 100f, 4, 35f),
        AmmoSpec(HEAT, 7.65f, 600f, 90f, 90f, 4, 88f),
        AmmoSpec(HE, 9.4f, 600f, 26f, 26f, 30, 88f)
    ))
    val KWK43 = GunSpec("8.8 cm KwK 43 L/71", 88, 71f, 8f, listOf(
        AmmoSpec(APCBC, 10.2f, 1000f, 202f, 165f, 40, 88f),
        AmmoSpec(APCR, 7.3f, 1130f, 237f, 182f, 6, 35f),
        AmmoSpec(HE, 9.4f, 1000f, 26f, 26f, 22, 88f)
    ))

    // ----------------------------------------------------------------- USA
    val M6_37 = GunSpec("37 mm M6 L/56.6", 37, 56.6f, 2.5f, listOf(
        AmmoSpec(APCBC, 0.87f, 884f, 60f, 36f, 60, 37f),
        AmmoSpec(HE, 0.74f, 800f, 11f, 11f, 20, 37f)
    ))
    val M3_75 = GunSpec("75 mm M3 L/40", 75, 40f, 5f, listOf(
        AmmoSpec(APCBC, 6.3f, 619f, 81f, 62f, 30, 75f),
        AmmoSpec(HE, 6.6f, 463f, 22f, 22f, 60, 75f)
    ))
    val M1A2_76 = GunSpec("76 mm M1A2 L/52", 76, 52f, 5f, listOf(
        AmmoSpec(APCBC, 7.0f, 792f, 109f, 83f, 30, 76f),
        AmmoSpec(APCR, 4.1f, 1036f, 170f, 105f, 5, 30f),
        AmmoSpec(HE, 6.0f, 700f, 23f, 23f, 40, 76f)
    ))
    val M3_90 = GunSpec("90 mm M3 L/50", 90, 50f, 7f, listOf(
        AmmoSpec(APCBC, 10.9f, 810f, 143f, 107f, 20, 90f),
        AmmoSpec(APCR, 7.6f, 1021f, 230f, 155f, 5, 35f),
        AmmoSpec(HE, 10.6f, 810f, 27f, 27f, 30, 90f)
    ))

    // ------------------------------------------------------------------ UK
    val QF2 = GunSpec("QF 2-pdr (40 mm) L/52", 40, 52f, 3f, listOf(
        AmmoSpec(AP, 1.08f, 792f, 57f, 36f, 80, 40f)
    ))
    val QF6 = GunSpec("QF 6-pdr (57 mm) L/43", 57, 43f, 4f, listOf(
        AmmoSpec(APCBC, 2.85f, 853f, 81f, 66f, 45, 57f),
        AmmoSpec(APCR, 1.4f, 1234f, 146f, 110f, 6, 25f)
    ))
    val QF75 = GunSpec("QF 75 mm L/36.5", 75, 36.5f, 5f, listOf(
        AmmoSpec(APCBC, 6.3f, 618f, 76f, 60f, 30, 75f),
        AmmoSpec(HE, 6.6f, 463f, 22f, 22f, 45, 75f)
    ))
    val QF17 = GunSpec("QF 17-pdr (76 mm) L/55", 76, 55f, 6f, listOf(
        AmmoSpec(APCBC, 7.7f, 884f, 150f, 120f, 25, 76f),
        AmmoSpec(APCR, 3.6f, 1203f, 213f, 171f, 6, 30f),
        AmmoSpec(HE, 7.7f, 884f, 23f, 23f, 18, 76f)
    ))
    val QF77 = GunSpec("OQF 77 mm HV L/50", 77, 50f, 5f, listOf(
        AmmoSpec(APCBC, 7.7f, 792f, 122f, 100f, 30, 77f),
        AmmoSpec(HE, 7.7f, 792f, 23f, 23f, 30, 77f)
    ))
}
