package com.ironfront.input

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.Input
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.Viewport
import com.ironfront.core.AssetManager
import com.ironfront.tanks.TankEntity
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class TouchControls(private val hudViewport: Viewport) {
    private val moveCenter = Vector2(150f, 150f)
    private val aimCenter = Vector2(1130f, 150f)
    private val stickRadius = 85f

    private val moveKnob = Vector2(moveCenter)
    private val aimKnob = Vector2(aimCenter)

    var fireRequested = false
        private set
    var switchAmmoRequested = false
        private set

    private val tmpVec = Vector3()

    fun update(tank: TankEntity) {
        fireRequested = false
        switchAmmoRequested = false

        var throttle = 0f
        var steer = 0f

        if (Gdx.input.isKeyPressed(Input.Keys.W)) throttle += 1f
        if (Gdx.input.isKeyPressed(Input.Keys.S)) throttle -= 1f
        if (Gdx.input.isKeyPressed(Input.Keys.A)) steer -= 1f
        if (Gdx.input.isKeyPressed(Input.Keys.D)) steer += 1f
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) fireRequested = true
        if (Gdx.input.isKeyJustPressed(Input.Keys.Q)) switchAmmoRequested = true

        moveKnob.set(moveCenter)
        aimKnob.set(aimCenter)

        for (i in 0 until 5) {
            if (!Gdx.input.isTouched(i)) continue
            tmpVec.set(Gdx.input.getX(i).toFloat(), Gdx.input.getY(i).toFloat(), 0f)
            hudViewport.unproject(tmpVec)

            if (tmpVec.x < 450f && tmpVec.y < 360f) {
                val dx = tmpVec.x - moveCenter.x
                val dy = tmpVec.y - moveCenter.y
                val dist = Vector2.len(dx, dy).coerceAtMost(stickRadius)
                val angle = atan2(dy, dx)
                moveKnob.set(
                    moveCenter.x + cos(angle) * dist,
                    moveCenter.y + sin(angle) * dist
                )
                throttle = (dy / stickRadius).coerceIn(-1f, 1f)
                steer = (dx / stickRadius).coerceIn(-1f, 1f)
            }

            if (tmpVec.x > 850f && tmpVec.y < 360f) {
                val dx = tmpVec.x - aimCenter.x
                val dy = tmpVec.y - aimCenter.y
                val dist = Vector2.len(dx, dy).coerceAtMost(stickRadius)
                val angle = atan2(dy, dx)
                aimKnob.set(
                    aimCenter.x + cos(angle) * dist,
                    aimCenter.y + sin(angle) * dist
                )
                if (dist > 15f) {
                    tank.desiredTurretRotation = Math.toDegrees(angle.toDouble()).toFloat()
                    fireRequested = true
                }
            }

            if (tmpVec.x >= 1060f && tmpVec.x <= 1240f && tmpVec.y >= 280f && tmpVec.y <= 390f) {
                fireRequested = true
            }

            if (Gdx.input.justTouched() && tmpVec.x >= 900f && tmpVec.x <= 1050f && tmpVec.y >= 280f && tmpVec.y <= 370f) {
                switchAmmoRequested = true
            }
        }

        tank.throttleInput = throttle
        tank.steerInput = steer
    }

    fun render(batch: SpriteBatch) {
        val pixel = AssetManager.getTexture("pixel")

        batch.color = Color(1f, 1f, 1f, 0.22f)
        batch.draw(pixel, moveCenter.x - stickRadius, moveCenter.y - stickRadius, stickRadius * 2f, stickRadius * 2f)
        batch.color = Color(0.9f, 0.9f, 0.9f, 0.65f)
        batch.draw(pixel, moveKnob.x - 24f, moveKnob.y - 24f, 48f, 48f)

        batch.color = Color(1f, 0.4f, 0.3f, 0.22f)
        batch.draw(pixel, aimCenter.x - stickRadius, aimCenter.y - stickRadius, stickRadius * 2f, stickRadius * 2f)
        batch.color = Color(1f, 0.35f, 0.25f, 0.7f)
        batch.draw(pixel, aimKnob.x - 24f, aimKnob.y - 24f, 48f, 48f)

        batch.color = Color(0.85f, 0.2f, 0.15f, 0.75f)
        batch.draw(pixel, 1070f, 285f, 160f, 80f)
        batch.color = Color(0.2f, 0.45f, 0.75f, 0.75f)
        batch.draw(pixel, 910f, 285f, 140f, 80f)

        batch.color = Color.WHITE
        AssetManager.font.draw(batch, "FIRE", 1122f, 333f)
        AssetManager.font.draw(batch, "AMMO", 945f, 333f)
    }
}
