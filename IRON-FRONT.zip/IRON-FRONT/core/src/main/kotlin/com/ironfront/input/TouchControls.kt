package com.ironfront.input

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.Input
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.Viewport
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.tanks.TankEntity
import com.ironfront.ui.UiDraw
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Touch controls. The shooting button is completely separate from the sticks:
 *  - MOVE: put your left thumb ANYWHERE on the left part of the screen. The stick appears under your
 *      thumb, so you never have to look for a button. Slide in any direction, as far as you like.
 *      DIRECT mode: the tank turns towards where you point and drives (point backwards to reverse).
 *      TANK mode:   up/down = forward/back, left/right = turn.
 *  - AIM: put your right thumb ANYWHERE on the right part of the screen and slide. The turret turns to
 *      that direction. Aiming NEVER fires the gun, so you cannot waste a shot and lose the reload.
 *  - FIRE: the big red button. Hold it to keep shooting (the gun still has to reload).
 *  - AMMO and REPAIR buttons.
 * Keyboard: W A S D, Space, Q, R.
 */
class TouchControls(private val hudViewport: Viewport) {
    private val stickRadius = 80f
    private val deadZone = 10f

    // set by the battle screen (kept so older callers still compile)
    var cameraX = 0f
    var cameraY = 0f

    /**
     * World heading (degrees) that points to the TOP of the screen: 90 for the north-up views,
     * the camera heading in the third-person and sight views. The sticks are relative to it.
     */
    var viewYawDeg = 90f

    var fireRequested = false
        private set
    var switchAmmoRequested = false
        private set
    var repairRequested = false
        private set

    /** Set for one frame when the player taps one of the AP / APCR / HE buttons. */
    var selectedAmmo: com.ironfront.weapons.AmmoType? = null
        private set

    private val tmp = Vector3()
    private val tracked = BooleanArray(MAX_POINTERS)

    private var movePtr = -1
    private val moveBase = Vector2(150f, 150f)
    private val moveKnob = Vector2(150f, 150f)
    private var reversing = false

    private var aimPtr = -1
    private val aimBase = Vector2(1130f, 150f)
    private val aimKnob = Vector2(1130f, 150f)

    private var firePtr = -1

    fun update(tank: TankEntity, delta: Float) {
        fireRequested = false
        switchAmmoRequested = false
        repairRequested = false
        selectedAmmo = null

        var kbThrottle = 0f
        var kbSteer = 0f
        if (Gdx.input.isKeyPressed(Input.Keys.W)) kbThrottle += 1f
        if (Gdx.input.isKeyPressed(Input.Keys.S)) kbThrottle -= 1f
        if (Gdx.input.isKeyPressed(Input.Keys.A)) kbSteer -= 1f
        if (Gdx.input.isKeyPressed(Input.Keys.D)) kbSteer += 1f
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) fireRequested = true
        if (Gdx.input.isKeyJustPressed(Input.Keys.Q)) switchAmmoRequested = true
        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) repairRequested = true

        for (i in 0 until MAX_POINTERS) {
            if (!Gdx.input.isTouched(i)) {
                if (tracked[i]) releasePointer(i)
                continue
            }
            tmp.set(Gdx.input.getX(i).toFloat(), Gdx.input.getY(i).toFloat(), 0f)
            hudViewport.unproject(tmp)
            val hx = tmp.x
            val hy = tmp.y

            if (!tracked[i]) {
                tracked[i] = true
                beginPointer(i, hx, hy)
            }

            if (i == movePtr) {
                moveKnob.set(clampToStick(moveBase, hx, hy))
            } else if (i == aimPtr) {
                updateAim(tank, hx, hy)
            } else if (i == firePtr) {
                fireRequested = true
            }
        }

        // movement
        var throttle = kbThrottle
        var steer = kbSteer
        if (movePtr != -1) {
            val res = moveFromStick(tank, moveKnob.x - moveBase.x, moveKnob.y - moveBase.y)
            throttle = res[0]
            steer = res[1]
        }
        tank.throttleInput = throttle.coerceIn(-1f, 1f)
        tank.steerInput = steer.coerceIn(-1f, 1f)
    }

    // ----------------------------------------------------------- pointers

    private fun beginPointer(i: Int, hx: Float, hy: Float) {
        // buttons first: a finger that starts on a button never becomes a stick
        if (sqrt((hx - FIRE_X) * (hx - FIRE_X) + (hy - FIRE_Y) * (hy - FIRE_Y)) <= FIRE_R) {
            firePtr = i
            return
        }
        val ammoList = com.ironfront.weapons.AmmoType.values()
        for (k in ammoList.indices) {
            if (UiDraw.hit(hx, hy, AMMO_X + k * (AMMO_BTN_W + 6f), AMMO_Y, AMMO_BTN_W, AMMO_H)) {
                selectedAmmo = ammoList[k]
                return
            }
        }
        if (UiDraw.hit(hx, hy, AMMO_X, REPAIR_Y, AMMO_W, REPAIR_H)) {
            repairRequested = true
            return
        }
        // only the EXIT / VISION buttons in the top-right corner are off limits
        if (hx > 1120f && hy > 565f) return

        if (hx < SPLIT_X) {
            if (movePtr == -1) {
                movePtr = i
                // the stick starts exactly where the thumb touched, so there is no jump
                moveBase.set(hx.coerceIn(70f, 1210f), hy.coerceIn(70f, 650f))
                moveKnob.set(moveBase)
                reversing = false
            }
        } else if (aimPtr == -1) {
            aimPtr = i
            aimBase.set(hx.coerceIn(70f, 1210f), hy.coerceIn(70f, 650f))
            aimKnob.set(aimBase)
        }
    }

    private fun releasePointer(i: Int) {
        tracked[i] = false
        if (i == movePtr) {
            movePtr = -1
            moveKnob.set(moveBase)
        }
        if (i == firePtr) firePtr = -1
        if (i == aimPtr) {
            // the turret simply keeps pointing where you left it
            aimPtr = -1
            aimKnob.set(aimBase)
        }
    }

    private fun clampToStick(base: Vector2, hx: Float, hy: Float): Vector2 {
        val dx = hx - base.x
        val dy = hy - base.y
        val dist = sqrt(dx * dx + dy * dy)
        if (dist <= stickRadius) return Vector2(hx, hy)
        return Vector2(base.x + dx / dist * stickRadius, base.y + dy / dist * stickRadius)
    }

    /** Aiming only turns the turret. It never fires. */
    private fun updateAim(tank: TankEntity, hx: Float, hy: Float) {
        val dx = hx - aimBase.x
        val dy = hy - aimBase.y
        val dist = sqrt(dx * dx + dy * dy)
        aimKnob.set(clampToStick(aimBase, hx, hy))
        if (dist > 12f) {
            tank.desiredTurretRotation = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + (viewYawDeg - 90f)
        }
    }

    // ----------------------------------------------------------- movement

    private fun angleDiff(a: Float, b: Float): Float {
        var d = (a - b) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    /** Returns [throttle, steer] for the current move stick offset. */
    private fun moveFromStick(tank: TankEntity, dx: Float, dy: Float): FloatArray {
        val len = sqrt(dx * dx + dy * dy)
        val mag = ((len - deadZone) / (stickRadius - deadZone)).coerceIn(0f, 1f)
        if (mag <= 0f) return floatArrayOf(0f, 0f)

        if (!GameManager.controlDirect) {
            return floatArrayOf((dy / stickRadius).coerceIn(-1f, 1f), (dx / stickRadius).coerceIn(-1f, 1f))
        }

        val desired = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + (viewYawDeg - 90f)
        var diff = angleDiff(desired, tank.rotation)
        if (!reversing && abs(diff) > 128f) reversing = true
        if (reversing && abs(diff) < 96f) reversing = false

        val throttle: Float
        if (reversing) {
            diff = angleDiff(desired + 180f, tank.rotation)
            throttle = -mag * max(0.35f, cos(Math.toRadians(diff.toDouble())).toFloat())
        } else {
            throttle = mag * max(0.22f, cos(Math.toRadians(diff.toDouble())).toFloat())
        }
        val steer = -(diff / 38f).coerceIn(-1f, 1f)
        return floatArrayOf(throttle, steer)
    }

    // ------------------------------------------------------------- render

    fun render(batch: SpriteBatch, tank: TankEntity) {
        val circle = AssetManager.getRegion("circle")
        val font = AssetManager.fontSmall

        if (movePtr != -1) {
            drawStick(batch, moveBase, moveKnob, Color(1f, 1f, 1f, 1f))
        } else {
            batch.color = Color(1f, 1f, 1f, 0.08f)
            batch.draw(circle, 150f - 70f, 150f - 70f, 140f, 140f)
            batch.color = Color.WHITE
            UiDraw.centered(batch, font, "MOVE: touch anywhere on the left", 230f, 250f, Color(1f, 1f, 1f, 0.45f))
        }
        if (aimPtr != -1) {
            drawStick(batch, aimBase, aimKnob, Color(1f, 0.45f, 0.35f, 1f))
        } else {
            batch.color = Color(1f, 0.45f, 0.35f, 0.08f)
            batch.draw(circle, 1010f - 70f, 150f - 70f, 140f, 140f)
            batch.color = Color.WHITE
            UiDraw.centered(batch, font, "AIM: slide on the right (does not fire)", 1000f, 250f, Color(1f, 0.6f, 0.5f, 0.5f))
        }

        // FIRE button: its own big button, away from the sticks
        val reloadLeft = 1f - tank.weapon.reloadProgress
        val ready = reloadLeft <= 0.01f
        batch.color = if (ready) Color(0.88f, 0.16f, 0.10f, if (firePtr != -1) 1f else 0.82f) else Color(0.45f, 0.14f, 0.12f, 0.78f)
        batch.draw(circle, FIRE_X - FIRE_R, FIRE_Y - FIRE_R, FIRE_R * 2f, FIRE_R * 2f)
        if (!ready) {
            val r = FIRE_R * reloadLeft
            batch.color = Color(0f, 0f, 0f, 0.5f)
            batch.draw(circle, FIRE_X - r, FIRE_Y - r, r * 2f, r * 2f)
        }
        batch.color = Color.WHITE
        UiDraw.centeredText(batch, if (ready) "FIRE" else "...", FIRE_X, FIRE_Y)

        // quick ammo selector: AP / APCR / HE, tap to switch shells instantly
        val current = tank.weapon.currentAmmo
        val available = tank.spec.gun.availableAmmo
        val ammoList = com.ironfront.weapons.AmmoType.values()
        for (k in ammoList.indices) {
            val ammo = ammoList[k]
            val bx = AMMO_X + k * (AMMO_BTN_W + 6f)
            val has = available.contains(ammo)
            val active = has && ammo == current
            batch.color = if (!has) Color(0.10f, 0.11f, 0.13f, 0.7f)
            else Color(ammo.color.r * (if (active) 0.55f else 0.25f), ammo.color.g * (if (active) 0.55f else 0.25f), ammo.color.b * (if (active) 0.55f else 0.25f), 0.9f)
            batch.draw(AssetManager.getRegion("pixel"), bx, AMMO_Y, AMMO_BTN_W, AMMO_H)
            batch.color = if (active) ammo.color else Color(0.5f, 0.55f, 0.6f, 0.8f)
            batch.draw(AssetManager.getRegion("pixel"), bx, AMMO_Y, AMMO_BTN_W, 3f)
            batch.draw(AssetManager.getRegion("pixel"), bx, AMMO_Y + AMMO_H - 3f, AMMO_BTN_W, 3f)
            batch.color = Color.WHITE
            UiDraw.centered(batch, font, ammo.shortName, bx + AMMO_BTN_W / 2f, AMMO_Y + 40f, if (has) Color.WHITE else Color.DARK_GRAY)
            if (has) {
                UiDraw.centered(batch, font, tank.spec.gun.penFor(ammo).toInt().toString(), bx + AMMO_BTN_W / 2f, AMMO_Y + 16f, if (active) ammo.color else Color.LIGHT_GRAY)
            }
        }

        if (tank.repairCharges > 0) {
            batch.color = Color(0.20f, 0.60f, 0.30f, 0.85f)
            batch.draw(AssetManager.getRegion("pixel"), AMMO_X, REPAIR_Y, AMMO_W, REPAIR_H)
            batch.color = Color.WHITE
            UiDraw.centered(batch, font, "REPAIR KIT", AMMO_X + AMMO_W / 2f, REPAIR_Y + REPAIR_H / 2f)
        }
    }

    private fun drawStick(batch: SpriteBatch, base: Vector2, knob: Vector2, tint: Color) {
        val circle = AssetManager.getRegion("circle")
        batch.color = Color(tint.r, tint.g, tint.b, 0.16f)
        batch.draw(circle, base.x - stickRadius, base.y - stickRadius, stickRadius * 2f, stickRadius * 2f)
        batch.color = Color(tint.r, tint.g, tint.b, 0.30f)
        batch.draw(circle, base.x - 12f, base.y - 12f, 24f, 24f)
        batch.color = Color(tint.r, tint.g, tint.b, 0.70f)
        batch.draw(circle, knob.x - 30f, knob.y - 30f, 60f, 60f)
        batch.color = Color.WHITE
    }

    companion object {
        private const val MAX_POINTERS = 5

        /** Left of this x the finger is the move stick, right of it the aim stick. */
        private const val SPLIT_X = 680f
        const val FIRE_X = 1170f
        const val FIRE_Y = 340f
        const val FIRE_R = 70f
        const val AMMO_X = 836f
        const val AMMO_Y = 556f
        const val AMMO_BTN_W = 78f
        const val AMMO_W = 250f
        const val AMMO_H = 60f
        const val REPAIR_Y = 496f
        const val REPAIR_H = 46f
    }
}
