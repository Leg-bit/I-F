package com.ironfront.art

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Pixmap

fun shade(c: Color, f: Float): Color =
    Color((c.r * f).coerceIn(0f, 1f), (c.g * f).coerceIn(0f, 1f), (c.b * f).coerceIn(0f, 1f), 1f)

fun Pixmap.rect(x: Int, y: Int, w: Int, h: Int, c: Color) {
    if (w <= 0 || h <= 0) return
    setColor(c)
    fillRectangle(x, y, w, h)
}

fun Pixmap.dot(x: Int, y: Int, c: Color) {
    setColor(c)
    drawPixel(x, y)
}

fun Pixmap.clearDot(x: Int, y: Int) {
    setColor(0f, 0f, 0f, 0f)
    drawPixel(x, y)
}

fun Pixmap.seg(x1: Int, y1: Int, x2: Int, y2: Int, c: Color) {
    setColor(c)
    drawLine(x1, y1, x2, y2)
}

fun Pixmap.disc(x: Int, y: Int, r: Int, c: Color) {
    setColor(c)
    fillCircle(x, y, r)
}

/** Fills a polygon that is star-shaped around its first point (fan triangulation). */
fun Pixmap.fillPoly(c: Color, vararg p: Int) {
    setColor(c)
    var i = 2
    while (i + 3 < p.size) {
        fillTriangle(p[0], p[1], p[i], p[i + 1], p[i + 2], p[i + 3])
        i += 2
    }
}

fun Pixmap.outlinePoly(c: Color, p: IntArray) {
    setColor(c)
    val n = p.size / 2
    for (i in 0 until n) {
        val j = (i + 1) % n
        drawLine(p[i * 2], p[i * 2 + 1], p[j * 2], p[j * 2 + 1])
    }
}

/** White copy of [src] grown by [grow] pixels: used as the blue/red team outline. */
fun silhouette(src: Pixmap, grow: Int): Pixmap {
    val out = Pixmap(src.width, src.height, Pixmap.Format.RGBA8888)
    out.setBlending(Pixmap.Blending.None)
    out.setColor(1f, 1f, 1f, 1f)
    for (y in 0 until src.height) {
        for (x in 0 until src.width) {
            if ((src.getPixel(x, y) and 0xff) == 0) continue
            for (dy in -grow..grow) {
                for (dx in -grow..grow) {
                    out.drawPixel(x + dx, y + dy)
                }
            }
        }
    }
    return out
}
