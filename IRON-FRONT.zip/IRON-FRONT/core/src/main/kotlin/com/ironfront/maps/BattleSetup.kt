package com.ironfront.maps

import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.GameManager
import com.ironfront.tanks.TankDatabase
import com.ironfront.teams.Team

enum class Difficulty(val label: String, val rewardMult: Float) {
    EASY("EASY", 0.7f),
    NORMAL("NORMAL", 1.0f),
    HARD("HARD", 1.6f);

    fun next(): Difficulty {
        val v = values()
        return v[(ordinal + 1) % v.size]
    }
}

/** What the player picked on the pre-play screen. Survives between battles. */
class LobbySettings {
    var mapId: String = "steppe"
    var allies: Int = 2
    var enemies: Int = 3
    var randomSides: Boolean = false
    var difficulty: Difficulty = Difficulty.NORMAL

    companion object {
        const val MAX_ALLIES = 4
        const val MIN_ENEMIES = 1
        const val MAX_ENEMIES = 6
    }
}

data class BotSpec(val tankId: String, val team: Team)

data class BattleSetup(
    val map: MapDef,
    val difficulty: Difficulty,
    val bots: List<BotSpec>,
    val rewardCredits: Int,
    val rewardXp: Int
)

object BattleSetupFactory {
    fun create(settings: LobbySettings): BattleSetup {
        val map = MapRegistry.get(settings.mapId)
        val all = TankDatabase.all()

        // Historical sides: Germany (Axis) vs USSR / USA / UK (Allies); opponents are matched by tier.
        val player = TankDatabase.get(GameManager.selectedTankId)
        val pt = player.tier
        val enemySide = all.filter { it.nation.side != player.nation.side }
        val friendSide = all.filter { it.nation.side == player.nation.side }
        val (lo, hi) = when (settings.difficulty) {
            Difficulty.EASY -> Pair(pt - 2, pt)
            Difficulty.NORMAL -> Pair(pt - 1, pt + 1)
            Difficulty.HARD -> Pair(pt, pt + 2)
        }
        val enemyPool = enemySide.filter { it.tier in lo..hi }.ifEmpty { enemySide }
        val allyPool = friendSide.filter { it.tier in (pt - 1)..(pt + 1) }.ifEmpty { friendSide }

        fun pickFor(team: Team): String =
            (if (team == Team.ENEMY) enemyPool else allyPool).random().id

        val bots = mutableListOf<BotSpec>()

        if (settings.randomSides) {
            // Every bot flips a coin: it becomes a friend (blue) or an enemy (red).
            val total = settings.allies + settings.enemies
            repeat(total) {
                val team = if (MathUtils.randomBoolean()) Team.FRIEND else Team.ENEMY
                bots.add(BotSpec(pickFor(team), team))
            }
            // There must always be somebody to fight.
            if (bots.none { it.team == Team.ENEMY }) {
                if (bots.isEmpty()) {
                    bots.add(BotSpec(pickFor(Team.ENEMY), Team.ENEMY))
                } else {
                    bots[0] = BotSpec(pickFor(Team.ENEMY), Team.ENEMY)
                }
            }
        } else {
            repeat(settings.allies) { bots.add(BotSpec(pickFor(Team.FRIEND), Team.FRIEND)) }
            repeat(settings.enemies) { bots.add(BotSpec(pickFor(Team.ENEMY), Team.ENEMY)) }
        }

        val enemyCount = bots.count { it.team == Team.ENEMY }
        val credits = (enemyCount * 900 * settings.difficulty.rewardMult).toInt()
        val xp = (enemyCount * 150 * settings.difficulty.rewardMult).toInt()

        return BattleSetup(map, settings.difficulty, bots, credits, xp)
    }
}
