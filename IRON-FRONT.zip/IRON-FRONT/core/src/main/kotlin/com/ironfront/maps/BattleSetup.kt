package com.ironfront.maps

import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.GameManager
import com.ironfront.nations.Nation
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec
import com.ironfront.teams.Team

enum class Difficulty(val label: String, val rewardMult: Float) {
    EASY("EASY", 0.7f),
    NORMAL("NORMAL", 1.0f),
    HARD("HARD", 1.6f);

    fun next(): Difficulty {
        val v = values()
        return v[(ordinal + 1) % v.size]
    }
}

/** What the player picked on the pre-play screen. Survives between battles. */
class LobbySettings {
    var mapId: String = "steppe"
    var allies: Int = 2
    var enemies: Int = 3
    var randomSides: Boolean = false
    var difficulty: Difficulty = Difficulty.NORMAL
    var visionEnabled: Boolean = true

    /** null = any nation. */
    var enemyNation: Nation? = null
    var allyNation: Nation? = null

    companion object {
        const val MAX_ALLIES = 4
        const val MIN_ENEMIES = 1
        const val MAX_ENEMIES = 6
    }
}

data class BotSpec(val tankId: String, val team: Team)

data class BattleSetup(
    val map: MapDef,
    val difficulty: Difficulty,
    val bots: List<BotSpec>,
    val rewardCredits: Int,
    val rewardXp: Int,
    val tierMin: Int,
    val tierMax: Int,
    val visionEnabled: Boolean = true
)

object BattleSetupFactory {

    /** Tier window used for matchmaking, based on the player's tank and the level. */
    fun tierRange(playerTier: Int, difficulty: Difficulty): IntRange = when (difficulty) {
        Difficulty.EASY -> maxOf(1, playerTier - 2)..playerTier
        Difficulty.NORMAL -> maxOf(1, playerTier - 1)..(playerTier + 1)
        Difficulty.HARD -> playerTier..(playerTier + 2)
    }

    private fun pool(all: List<TankSpec>, nation: Nation?, tiers: IntRange): List<TankSpec> {
        val byNation = if (nation == null) all else all.filter { it.nation == nation }
        val base = byNation.ifEmpty { all }
        return base.filter { it.tier in tiers }.ifEmpty { base }
    }

    fun create(settings: LobbySettings): BattleSetup {
        val map = MapRegistry.get(settings.mapId)
        val all = TankDatabase.all()
        val playerTier = TankDatabase.get(GameManager.selectedTankId).tier
        val tiers = tierRange(playerTier, settings.difficulty)

        val enemyPool = pool(all, settings.enemyNation, tiers)
        val allyPool = pool(all, settings.allyNation, maxOf(1, playerTier - 1)..(playerTier + 1))

        fun pickFor(team: Team): String =
            (if (team == Team.ENEMY) enemyPool else allyPool).random().id

        val bots = mutableListOf<BotSpec>()

        if (settings.randomSides) {
            // Every bot flips a coin: it becomes a friend (blue) or an enemy (red).
            val total = settings.allies + settings.enemies
            repeat(total) {
                val team = if (MathUtils.randomBoolean()) Team.FRIEND else Team.ENEMY
                bots.add(BotSpec(pickFor(team), team))
            }
            // There must always be somebody to fight.
            if (bots.none { it.team == Team.ENEMY }) {
                if (bots.isEmpty()) {
                    bots.add(BotSpec(pickFor(Team.ENEMY), Team.ENEMY))
                } else {
                    bots[0] = BotSpec(pickFor(Team.ENEMY), Team.ENEMY)
                }
            }
        } else {
            repeat(settings.allies) { bots.add(BotSpec(pickFor(Team.FRIEND), Team.FRIEND)) }
            repeat(settings.enemies) { bots.add(BotSpec(pickFor(Team.ENEMY), Team.ENEMY)) }
        }

        var credits = 0f
        var xp = 0f
        for (bot in bots) {
            if (bot.team != Team.ENEMY) continue
            val tier = TankDatabase.get(bot.tankId).tier
            credits += 500f + 450f * tier
            xp += 80f + 70f * tier
        }
        credits *= settings.difficulty.rewardMult
        xp *= settings.difficulty.rewardMult

        return BattleSetup(map, settings.difficulty, bots, credits.toInt(), xp.toInt(), tiers.first, tiers.last, settings.visionEnabled)
    }
}
