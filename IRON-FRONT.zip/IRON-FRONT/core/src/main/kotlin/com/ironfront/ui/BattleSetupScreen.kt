package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.maps.BattleSetupFactory
import com.ironfront.maps.LobbySettings
import com.ironfront.maps.MapDef
import com.ironfront.maps.MapRegistry
import com.ironfront.nations.Nation
import com.ironfront.tanks.TankDatabase
import com.ironfront.teams.Team

/**
 * Pre-play screen: pick a map, how many bots join each side (blue = friend, red = enemy),
 * random sides, difficulty and which nations the bots come from.
 */
class BattleSetupScreen(game: IronFront) : UiScreen(game) {
    private val lobby = GameManager.lobby
    private val maps = MapRegistry.all()

    private val cardW = 232f
    private val cardH = 230f
    private val cardY = 385f
    private val cardGap = 10f
    private val cardX0 = 40f

    private fun cardX(i: Int): Float = cardX0 + i * (cardW + cardGap)

    private fun cycleNation(n: Nation?): Nation? {
        if (n == null) return Nation.values().first()
        return if (n.ordinal == Nation.values().size - 1) null else n.next()
    }

    private fun nationLabel(n: Nation?): String = n?.label?.uppercase() ?: "ANY"

    override fun draw(b: SpriteBatch) {
        UiDraw.tacticalBackdrop(b)
        val tank = TankDatabase.get(GameManager.selectedTankId)

        UiDraw.fillRect(b, 0f, 630f, 1280f, 90f, Theme.header)
        UiDraw.fillRect(b, 0f, 628f, 1280f, 2f, Theme.border)
        UiDraw.smallButton(b, 20f, 662f, 120f, 46f, Theme.darkRed, "< BACK")
        UiDraw.big(b, "BATTLE SETUP", 165f, 703f, Theme.gold)
        UiDraw.small(b, "YOUR TANK: " + tank.name, 780f, 696f, Theme.text)
        UiDraw.tankIcon(b, tank, 1170f, 672f, UiDraw.iconScale(tank, 110f).coerceAtMost(1.6f))
        UiDraw.small(b, "SELECT MAP", 40f, 622f, Theme.textDim)

        maps.forEachIndexed { i, map ->
            val x = cardX(i)
            val selected = lobby.mapId == map.id
            UiDraw.fillRect(b, x, cardY, cardW, cardH, if (selected) Theme.darkGreen else Theme.panel)
            UiDraw.small(b, map.name, x + 12f, cardY + cardH - 10f, Theme.text)
            drawPreview(b, map, x + 56f, cardY + 50f, 120f)
            UiDraw.small(b, if (selected) "SELECTED" else "TAP TO SELECT", x + 12f, cardY + 30f, if (selected) Theme.gold else Theme.textDim)
            UiDraw.outlineRect(b, x, cardY, cardW, cardH, if (selected) 4f else 2f, if (selected) Theme.gold else Theme.grey)
        }
        val current = MapRegistry.get(lobby.mapId)
        UiDraw.small(b, current.description, 40f, 378f, Theme.textDim)

        drawBotPanel(b)

        val range = BattleSetupFactory.tierRange(tank.tier, lobby.difficulty)
        UiDraw.small(b, "Matchmaking: enemy tiers " + range.first + " - " + range.last, 40f, 90f, Theme.textDim)
        UiDraw.button(b, 860f, 25f, 380f, 80f, Color(0.20f, 0.52f, 0.25f, 1f), "DEPLOY!")
    }

    /** Mini map: obstacles, blue square = your start, red box = enemy start zone. */
    private fun drawPreview(b: SpriteBatch, map: MapDef, px: Float, py: Float, size: Float) {
        val s = size / GameConfig.MAP_WIDTH
        val pixel = AssetManager.getTexture("pixel")

        UiDraw.fillRect(b, px, py, size, size, map.groundColor)

        for (o in map.obstacles) {
            when (o.kind) {
                com.ironfront.maps.ObstacleKind.DECOR, com.ironfront.maps.ObstacleKind.BUSH -> continue
                com.ironfront.maps.ObstacleKind.TRUNK -> b.color = Color(0.12f, 0.35f, 0.15f, 1f)
                com.ironfront.maps.ObstacleKind.SWAMP -> b.color = Color(0.40f, 0.55f, 0.65f, 0.8f)
                com.ironfront.maps.ObstacleKind.WRECK -> b.color = Color(0.20f, 0.18f, 0.16f, 1f)
                else -> b.color = map.obstacleColor
            }
            val w = maxOf(o.w * s, 2f)
            val h = maxOf(o.h * s, 2f)
            b.draw(pixel, px + (o.x - o.w / 2f) * s, py + (o.y - o.h / 2f) * s, w, h)
        }
        b.color = Color.WHITE

        val z = map.enemyZone
        UiDraw.outlineRect(
            b,
            px + z.minX * s,
            py + z.minY * s,
            (z.maxX - z.minX) * s,
            (z.maxY - z.minY) * s,
            2f,
            Team.ENEMY.outline
        )
        UiDraw.fillRect(b, px + map.playerSpawnX * s - 4f, py + map.playerSpawnY * s - 4f, 8f, 8f, Team.FRIEND.outline)
        UiDraw.outlineRect(b, px, py, size, size, 2f, Color.LIGHT_GRAY)
    }

    private fun drawStepper(b: SpriteBatch, x: Float, y: Float, value: String) {
        UiDraw.button(b, x, y, 60f, 50f, Theme.panelLight, "-")
        UiDraw.centeredText(b, value, x + 105f, y + 25f)
        UiDraw.button(b, x + 150f, y, 60f, 50f, Theme.panelLight, "+")
    }

    private fun drawBotPanel(b: SpriteBatch) {
        UiDraw.panel(b, 40f, 125f, 1200f, 240f)

        UiDraw.coloredText(b, "ALLIES (BLUE)", 70f, 340f, Team.FRIEND.outline)
        drawStepper(b, 360f, 300f, lobby.allies.toString())

        UiDraw.coloredText(b, "ENEMIES (RED)", 70f, 262f, Team.ENEMY.outline)
        drawStepper(b, 360f, 222f, lobby.enemies.toString())

        // legend
        UiDraw.outlineRect(b, 70f, 140f, 22f, 22f, 4f, Team.FRIEND.outline)
        UiDraw.small(b, "BLUE = FRIEND", 102f, 158f, Theme.text)
        UiDraw.outlineRect(b, 260f, 140f, 22f, 22f, 4f, Team.ENEMY.outline)
        UiDraw.small(b, "RED = ENEMY", 292f, 158f, Theme.text)

        // option grid
        UiDraw.button(b, 640f, 300f, 270f, 55f, Color(0.30f, 0.24f, 0.40f, 1f), if (lobby.randomSides) "SIDES: RANDOM" else "SIDES: FIXED")
        UiDraw.button(b, 930f, 300f, 290f, 55f, Color(0.40f, 0.30f, 0.15f, 1f), "LEVEL: " + lobby.difficulty.label)
        UiDraw.button(b, 640f, 232f, 270f, 55f, Theme.darkRed, "ENEMY: " + nationLabel(lobby.enemyNation))
        UiDraw.button(b, 930f, 232f, 290f, 55f, Color(0.15f, 0.30f, 0.50f, 1f), "ALLY: " + nationLabel(lobby.allyNation))

        val hint = if (lobby.randomSides) {
            "Each bot flips a coin and becomes a friend (blue) or an enemy (red). Total bots = allies + enemies."
        } else {
            "Allies (blue) fight for you. Enemies (red) hunt you. Bots join exactly as set."
        }
        UiDraw.button(b, 640f, 164f, 270f, 55f, if (lobby.visionEnabled) Color(0.14f, 0.32f, 0.40f, 1f) else Theme.dark, if (lobby.visionEnabled) "VISION: SPOTLIGHT" else "VISION: OFF")
        UiDraw.button(b, 930f, 164f, 290f, 55f, if (GameManager.view3d) Color(0.20f, 0.36f, 0.20f, 1f) else Theme.dark, when (GameManager.gfxMode) { 0 -> "VIEW: 2D (light)"; 1 -> "VIEW: 3D LOW"; 2 -> "VIEW: 3D MEDIUM"; else -> "VIEW: 3D HIGH" })
        UiDraw.smallWrapped(b, "Spotlight cone: you only see enemies in the beam [tank]<  or close by. Walls block sight, bushes hide tanks.", 70f, 205f, 530f)
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 20f, 662f, 120f, 46f)) {
            AudioManager.playClick()
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }
        if (UiDraw.hit(x, y, 860f, 25f, 380f, 80f)) {
            AudioManager.playClick()
            val setup = BattleSetupFactory.create(lobby)
            ScreenManager.setScreen(BattleScreen(game, setup))
            return
        }

        for (i in maps.indices) {
            if (UiDraw.hit(x, y, cardX(i), cardY, cardW, cardH)) {
                lobby.mapId = maps[i].id
                AudioManager.playClick()
                return
            }
        }

        if (UiDraw.hit(x, y, 360f, 300f, 60f, 50f)) {
            lobby.allies = (lobby.allies - 1).coerceAtLeast(0)
        }
        if (UiDraw.hit(x, y, 510f, 300f, 60f, 50f)) {
            lobby.allies = (lobby.allies + 1).coerceAtMost(LobbySettings.MAX_ALLIES)
        }
        if (UiDraw.hit(x, y, 360f, 222f, 60f, 50f)) {
            lobby.enemies = (lobby.enemies - 1).coerceAtLeast(LobbySettings.MIN_ENEMIES)
        }
        if (UiDraw.hit(x, y, 510f, 222f, 60f, 50f)) {
            lobby.enemies = (lobby.enemies + 1).coerceAtMost(LobbySettings.MAX_ENEMIES)
        }
        if (UiDraw.hit(x, y, 640f, 300f, 270f, 55f)) {
            lobby.randomSides = !lobby.randomSides
        }
        if (UiDraw.hit(x, y, 930f, 300f, 290f, 55f)) {
            lobby.difficulty = lobby.difficulty.next()
        }
        if (UiDraw.hit(x, y, 640f, 232f, 270f, 55f)) {
            lobby.enemyNation = cycleNation(lobby.enemyNation)
        }
        if (UiDraw.hit(x, y, 930f, 232f, 290f, 55f)) {
            lobby.allyNation = cycleNation(lobby.allyNation)
        }
        if (UiDraw.hit(x, y, 640f, 164f, 270f, 55f)) {
            lobby.visionEnabled = !lobby.visionEnabled
        }
        if (UiDraw.hit(x, y, 930f, 164f, 290f, 55f)) {
            GameManager.gfxMode = (GameManager.gfxMode + 1) % 4
            com.ironfront.save.SaveManager.save()
        }
    }
}
