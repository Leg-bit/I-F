package com.ironfront.ui

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.ScreenAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.FitViewport
import com.ironfront.IronFront
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.maps.BattleSetupFactory
import com.ironfront.maps.LobbySettings
import com.ironfront.maps.MapDef
import com.ironfront.maps.MapRegistry
import com.ironfront.tanks.TankDatabase
import com.ironfront.teams.Team

/**
 * Pre-play screen: pick a map, how many bots join each side
 * (blue = friend, red = enemy), random sides and difficulty.
 */
class BattleSetupScreen(private val game: IronFront) : ScreenAdapter() {
    private val camera = OrthographicCamera()
    private val viewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, camera)
    private val touchPos = Vector3()

    private val lobby = GameManager.lobby
    private val maps = MapRegistry.all()

    private val bgColor = Color(0.09f, 0.11f, 0.10f, 1f)
    private val headerColor = Color(0.18f, 0.22f, 0.18f, 1f)
    private val cardNormal = Color(0.15f, 0.18f, 0.16f, 1f)
    private val cardSelected = Color(0.20f, 0.30f, 0.22f, 1f)
    private val panelColor = Color(0.13f, 0.15f, 0.15f, 1f)
    private val stepperColor = Color(0.25f, 0.28f, 0.30f, 1f)
    private val toggleColor = Color(0.30f, 0.24f, 0.40f, 1f)
    private val levelColor = Color(0.40f, 0.30f, 0.15f, 1f)
    private val backColor = Color(0.40f, 0.20f, 0.20f, 1f)
    private val deployColor = Color(0.20f, 0.50f, 0.25f, 1f)
    private val gold = Color(1f, 0.85f, 0.25f, 1f)
    private val grey = Color(0.45f, 0.48f, 0.48f, 1f)

    private val cardW = 390f
    private val cardH = 240f
    private val cardY = 330f
    private val cardGap = 20f
    private val cardX0 = 40f

    private fun cardX(i: Int): Float = cardX0 + i * (cardW + cardGap)

    override fun render(delta: Float) {
        Gdx.gl.glClearColor(bgColor.r, bgColor.g, bgColor.b, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)

        viewport.apply()
        game.batch.projectionMatrix = camera.combined

        val b = game.batch
        b.begin()
        drawHeader(b)
        drawMapCards(b)
        drawBotPanel(b)
        drawButtons(b)
        b.end()

        handleInput()
    }

    // ------------------------------------------------------------- drawing

    private fun drawHeader(b: com.badlogic.gdx.graphics.g2d.SpriteBatch) {
        UiDraw.fillRect(b, 0f, 620f, 1280f, 100f, headerColor)
        UiDraw.text(b, "BATTLE SETUP", 40f, 685f)
        val tank = TankDatabase.get(GameManager.selectedTankId)
        UiDraw.text(b, "YOUR TANK: ${tank.name}", 640f, 685f)
        UiDraw.text(b, "SELECT MAP", 40f, 605f)
    }

    private fun drawMapCards(b: com.badlogic.gdx.graphics.g2d.SpriteBatch) {
        maps.forEachIndexed { i, map ->
            val x = cardX(i)
            val y = cardY
            val selected = lobby.mapId == map.id

            UiDraw.fillRect(b, x, y, cardW, cardH, if (selected) cardSelected else cardNormal)
            drawPreview(b, map, x + 12f, y + 60f, 150f)
            UiDraw.text(b, map.name, x + 180f, y + 226f)
            UiDraw.wrapped(b, map.description, x + 180f, y + 190f, 195f)
            UiDraw.text(b, if (selected) "SELECTED" else "TAP TO SELECT", x + 15f, y + 40f)

            if (selected) {
                UiDraw.outlineRect(b, x, y, cardW, cardH, 4f, gold)
            } else {
                UiDraw.outlineRect(b, x, y, cardW, cardH, 2f, grey)
            }
        }
    }

    /** Mini map: obstacles, blue square = your start, red box = enemy start zone. */
    private fun drawPreview(b: com.badlogic.gdx.graphics.g2d.SpriteBatch, map: MapDef, px: Float, py: Float, size: Float) {
        val s = size / GameConfig.MAP_WIDTH
        val pixel = AssetManager.getTexture("pixel")

        UiDraw.fillRect(b, px, py, size, size, map.groundColor)

        b.color = map.obstacleColor
        for (o in map.obstacles) {
            val w = maxOf(o.w * s, 2f)
            val h = maxOf(o.h * s, 2f)
            b.draw(pixel, px + (o.x - o.w / 2f) * s, py + (o.y - o.h / 2f) * s, w, h)
        }
        b.color = Color.WHITE

        val z = map.enemyZone
        UiDraw.outlineRect(
            b,
            px + z.minX * s,
            py + z.minY * s,
            (z.maxX - z.minX) * s,
            (z.maxY - z.minY) * s,
            2f,
            Team.ENEMY.outline
        )
        UiDraw.fillRect(b, px + map.playerSpawnX * s - 4f, py + map.playerSpawnY * s - 4f, 8f, 8f, Team.FRIEND.outline)
        UiDraw.outlineRect(b, px, py, size, size, 2f, Color.LIGHT_GRAY)
    }

    private fun drawStepper(b: com.badlogic.gdx.graphics.g2d.SpriteBatch, x: Float, y: Float, value: String) {
        UiDraw.button(b, x, y, 60f, 50f, stepperColor, "-")
        UiDraw.centeredText(b, value, x + 105f, y + 25f)
        UiDraw.button(b, x + 150f, y, 60f, 50f, stepperColor, "+")
    }

    private fun drawBotPanel(b: com.badlogic.gdx.graphics.g2d.SpriteBatch) {
        UiDraw.fillRect(b, 40f, 120f, 1200f, 190f, panelColor)
        UiDraw.outlineRect(b, 40f, 120f, 1200f, 190f, 2f, grey)

        UiDraw.coloredText(b, "ALLIES (BLUE)", 70f, 284f, Team.FRIEND.outline)
        drawStepper(b, 360f, 250f, lobby.allies.toString())

        UiDraw.coloredText(b, "ENEMIES (RED)", 70f, 214f, Team.ENEMY.outline)
        drawStepper(b, 360f, 180f, lobby.enemies.toString())

        // Legend
        UiDraw.outlineRect(b, 70f, 130f, 26f, 26f, 4f, Team.FRIEND.outline)
        UiDraw.text(b, "BLUE = FRIEND", 106f, 153f)
        UiDraw.outlineRect(b, 300f, 130f, 26f, 26f, 4f, Team.ENEMY.outline)
        UiDraw.text(b, "RED = ENEMY", 336f, 153f)

        // Options
        UiDraw.button(b, 640f, 235f, 270f, 65f, toggleColor, if (lobby.randomSides) "SIDES: RANDOM" else "SIDES: FIXED")
        UiDraw.button(b, 930f, 235f, 280f, 65f, levelColor, "LEVEL: ${lobby.difficulty.label}")

        val hint = if (lobby.randomSides) {
            "Each bot flips a coin and becomes a friend (blue) or an enemy (red). Total bots = allies + enemies."
        } else {
            "Allies (blue) fight for you. Enemies (red) hunt you. Bots join exactly as set."
        }
        UiDraw.wrapped(b, hint, 640f, 215f, 570f)
    }

    private fun drawButtons(b: com.badlogic.gdx.graphics.g2d.SpriteBatch) {
        UiDraw.button(b, 40f, 25f, 220f, 70f, backColor, "< BACK")
        UiDraw.button(b, 860f, 25f, 380f, 80f, deployColor, "DEPLOY!")
    }

    // --------------------------------------------------------------- input

    private fun handleInput() {
        if (!Gdx.input.justTouched()) return
        touchPos.set(Gdx.input.x.toFloat(), Gdx.input.y.toFloat(), 0f)
        viewport.unproject(touchPos)
        val tx = touchPos.x
        val ty = touchPos.y

        if (UiDraw.hit(tx, ty, 40f, 25f, 220f, 70f)) {
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }
        if (UiDraw.hit(tx, ty, 860f, 25f, 380f, 80f)) {
            val setup = BattleSetupFactory.create(lobby)
            ScreenManager.setScreen(BattleScreen(game, setup))
            return
        }

        for (i in maps.indices) {
            if (UiDraw.hit(tx, ty, cardX(i), cardY, cardW, cardH)) {
                lobby.mapId = maps[i].id
            }
        }

        if (UiDraw.hit(tx, ty, 360f, 250f, 60f, 50f)) {
            lobby.allies = (lobby.allies - 1).coerceAtLeast(0)
        }
        if (UiDraw.hit(tx, ty, 510f, 250f, 60f, 50f)) {
            lobby.allies = (lobby.allies + 1).coerceAtMost(LobbySettings.MAX_ALLIES)
        }
        if (UiDraw.hit(tx, ty, 360f, 180f, 60f, 50f)) {
            lobby.enemies = (lobby.enemies - 1).coerceAtLeast(LobbySettings.MIN_ENEMIES)
        }
        if (UiDraw.hit(tx, ty, 510f, 180f, 60f, 50f)) {
            lobby.enemies = (lobby.enemies + 1).coerceAtMost(LobbySettings.MAX_ENEMIES)
        }
        if (UiDraw.hit(tx, ty, 640f, 235f, 270f, 65f)) {
            lobby.randomSides = !lobby.randomSides
        }
        if (UiDraw.hit(tx, ty, 930f, 235f, 280f, 65f)) {
            lobby.difficulty = lobby.difficulty.next()
        }
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }
}
