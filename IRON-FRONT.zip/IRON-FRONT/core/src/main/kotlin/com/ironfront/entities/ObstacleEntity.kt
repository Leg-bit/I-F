package com.ironfront.entities

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.ironfront.core.AssetManager

class ObstacleEntity(
    id: String,
    x: Float,
    y: Float,
    width: Float = 64f,
    height: Float = 64f,
    val destructible: Boolean = false,
    val textureKey: String = "obstacle_rock"
) : Entity(id, x, y, width, height) {

    var hp: Float = 200f

    override fun update(delta: Float) {
        if (destructible && hp <= 0f) {
            isAlive = false
        }
    }

    override fun render(batch: SpriteBatch) {
        val tex = AssetManager.getTexture(textureKey)
        batch.draw(tex, position.x - width / 2f, position.y - height / 2f, width, height)
    }
}
