package com.ironfront.entities

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.ironfront.core.AssetManager
import com.ironfront.maps.ObstacleDef
import com.ironfront.maps.ObstacleKind
import kotlin.math.abs
import kotlin.math.max

/** Anything lying on the map: walls, trees, rocks, bushes, craters, swamps and wrecks. */
class ObstacleEntity(id: String, val def: ObstacleDef) :
    Entity(id, def.x, def.y, def.w, def.h) {

    val kind: ObstacleKind = def.kind
    val destructible: Boolean = def.destructible
    val textureKey: String = def.texture
    val rotationDeg: Float = def.rotation

    var hp: Float = when {
        kind == ObstacleKind.TRUNK -> 140f
        textureKey.startsWith("obstacle_wall") -> 260f
        textureKey.startsWith("obstacle_sandbag") -> 180f
        else -> 220f
    }

    /** Radius used for round solids. */
    val radius: Float = when (kind) {
        ObstacleKind.TRUNK -> 13f
        ObstacleKind.ROCK -> max(10f, def.w * 0.40f)
        ObstacleKind.WRECK -> 22f
        ObstacleKind.SWAMP -> def.w * 0.5f
        else -> 0f
    }

    val solid: Boolean get() = kind.solid
    val blocksSight: Boolean get() = kind.blocksSight

    override fun update(delta: Float) {
        if (destructible && hp <= 0f) isAlive = false
    }

    /** Does this world point hit the solid part of the object? */
    fun containsPoint(px: Float, py: Float): Boolean {
        if (!solid) return false
        return when (kind) {
            ObstacleKind.BOX -> abs(px - position.x) <= width / 2f && abs(py - position.y) <= height / 2f
            else -> {
                val dx = px - position.x
                val dy = py - position.y
                dx * dx + dy * dy <= radius * radius
            }
        }
    }

    /** Is the point inside the footprint (used for bushes and swamps). */
    fun overlapsPoint(px: Float, py: Float): Boolean {
        val dx = px - position.x
        val dy = py - position.y
        val r = max(width, height) * 0.4f
        return dx * dx + dy * dy <= r * r
    }

    fun isFlat(): Boolean = kind == ObstacleKind.DECOR || kind == ObstacleKind.SWAMP

    /** Ground level drawing: flat decor first, solids, trunks. */
    fun renderBase(batch: SpriteBatch) {
        when (kind) {
            ObstacleKind.DECOR, ObstacleKind.SWAMP -> drawRotated(batch, 1f)
            ObstacleKind.BOX, ObstacleKind.ROCK -> {
                if (kind == ObstacleKind.ROCK) drawRotated(batch, 1f)
                else batch.draw(AssetManager.getTexture(textureKey), position.x - width / 2f, position.y - height / 2f, width, height)
            }
            ObstacleKind.TRUNK -> {
                batch.setColor(0f, 0f, 0f, 0.28f)
                batch.draw(AssetManager.getRegion("circle"), position.x - 12f, position.y - 16f, 28f, 22f)
                batch.setColor(0.30f, 0.20f, 0.12f, 1f)
                batch.draw(AssetManager.getRegion("circle"), position.x - 8f, position.y - 8f, 16f, 16f)
                batch.setColor(1f, 1f, 1f, 1f)
            }
            ObstacleKind.WRECK -> renderWreck(batch)
            ObstacleKind.BUSH -> {}
        }
    }

    /** Drawn above tanks: tree canopies and bushes. */
    fun renderTop(batch: SpriteBatch) {
        when (kind) {
            ObstacleKind.TRUNK -> drawRotated(batch, 0.94f)
            ObstacleKind.BUSH -> drawRotated(batch, 0.90f)
            else -> {}
        }
    }

    private fun drawRotated(batch: SpriteBatch, alpha: Float) {
        val region = AssetManager.getRegion(textureKey)
        batch.setColor(1f, 1f, 1f, alpha)
        batch.draw(
            region, position.x - width / 2f, position.y - height / 2f,
            width / 2f, height / 2f, width, height, 1f, 1f, rotationDeg
        )
        batch.setColor(1f, 1f, 1f, 1f)
    }

    private fun renderWreck(batch: SpriteBatch) {
        val hullKey = "hull_" + def.tankId
        if (!AssetManager.hasTexture(hullKey)) return
        val hull = AssetManager.getRegion(hullKey)
        val turret = AssetManager.getRegion("turret_" + def.tankId)
        val hw = hull.regionWidth.toFloat()
        val hh = hull.regionHeight.toFloat()
        val tw = turret.regionWidth.toFloat()
        val th = turret.regionHeight.toFloat()
        val pivot = AssetManager.pivotX(def.tankId)
        batch.setColor(0.16f, 0.14f, 0.13f, 1f)
        batch.draw(hull, position.x - hw / 2f, position.y - hh / 2f, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotationDeg)
        batch.draw(turret, position.x - pivot, position.y - th / 2f, pivot, th / 2f, tw, th, 1f, 1f, rotationDeg + 40f)
        batch.setColor(1f, 1f, 1f, 1f)
    }

    override fun render(batch: SpriteBatch) {
        renderBase(batch)
        renderTop(batch)
    }

    val minimapColor: Color
        get() = when (kind) {
            ObstacleKind.TRUNK -> Color(0.15f, 0.40f, 0.18f, 1f)
            ObstacleKind.SWAMP -> Color(0.35f, 0.50f, 0.60f, 1f)
            ObstacleKind.WRECK -> Color(0.25f, 0.22f, 0.20f, 1f)
            else -> Color(0.55f, 0.52f, 0.48f, 1f)
        }
}
