package com.ironfront.nations

import com.badlogic.gdx.graphics.Color

/** The five armies you can research tanks for. */
enum class Nation(
    val label: String,
    val code: String,
    val primary: Color,
    val secondary: Color
) {
    GERMANY("Germany", "GER", Color(0.80f, 0.80f, 0.80f, 1f), Color(0.20f, 0.20f, 0.22f, 1f)),
    USSR("USSR", "URS", Color(0.85f, 0.14f, 0.12f, 1f), Color(0.98f, 0.82f, 0.20f, 1f)),
    USA("USA", "USA", Color(0.30f, 0.50f, 0.92f, 1f), Color(0.92f, 0.92f, 0.96f, 1f)),
    UK("United Kingdom", "GBR", Color(0.20f, 0.32f, 0.70f, 1f), Color(0.84f, 0.14f, 0.18f, 1f)),
    JAPAN("Japan", "JPN", Color(0.94f, 0.94f, 0.94f, 1f), Color(0.80f, 0.10f, 0.12f, 1f));

    fun next(): Nation {
        val v = values()
        return v[(ordinal + 1) % v.size]
    }
}
