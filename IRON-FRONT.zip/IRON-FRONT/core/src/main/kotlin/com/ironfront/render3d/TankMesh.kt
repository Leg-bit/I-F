package com.ironfront.render3d

import com.ironfront.tanks.Muzzle
import com.ironfront.tanks.TankSpec
import com.ironfront.tanks.TurretShape
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

private typealias P = FloatArray
private typealias UvFn = ((FloatArray) -> FloatArray)?

/** Triangle mesh: 8 floats per vertex (position, normal, uv). */
class Mesh3 {
    private val vs = ArrayList<Float>()
    private val ts = ArrayList<Int>()
    val count: Int get() = vs.size / 8

    fun add(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, u: Float, v: Float): Int {
        vs.add(x); vs.add(y); vs.add(z)
        vs.add(nx); vs.add(ny); vs.add(nz)
        vs.add(u); vs.add(v)
        return count - 1
    }

    fun tri(a: Int, b: Int, c: Int) {
        ts.add(a); ts.add(b); ts.add(c)
    }

    fun vertices(): FloatArray = vs.toFloatArray()
    fun triangles(): IntArray = ts.toIntArray()
}

/**
 * Builds real 3D tank models (not boxes) from a [TankSpec]:
 *  - hull with a sloped glacis plate whose angle is the real front armour slope, tapered nose, rear plate
 *  - rounded track runs with road wheels, sprocket and idler, fenders, side skirts
 *  - cast (domed) or angular (faceted) turret with front slope, cupola, hatches, bustle, mantlet
 *  - tapered gun barrel, bore evacuator and muzzle brake
 * The model faces +X, up is +Y and the right side of the tank is +Z.
 */
object TankMesh {
    const val PAINT = 0
    const val DARK = 1
    const val STEEL = 2
    const val WHEEL = 3
    const val DETAIL = 4
    const val DECK = 5

    class Part(val id: String, val kind: Int, val r: Float, val g: Float, val b: Float, val mesh: Mesh3)

    class Result(val hull: List<Part>, val turret: List<Part>, val turretBase: Float)

    // ------------------------------------------------------------------ vector helpers

    private fun p(x: Float, y: Float, z: Float): P = floatArrayOf(x, y, z)
    private fun sub(a: P, b: P): P = p(a[0] - b[0], a[1] - b[1], a[2] - b[2])
    private fun neg(a: P): P = p(-a[0], -a[1], -a[2])
    private fun dot(a: P, b: P): Float = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    private fun cross(a: P, b: P): P =
        p(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])

    private fun norm(a: P): P {
        val l = sqrt(dot(a, a))
        return if (l < 1e-6f) p(0f, 1f, 0f) else p(a[0] / l, a[1] / l, a[2] / l)
    }

    private fun mid(a: P, b: P): P = p((a[0] + b[0]) / 2f, (a[1] + b[1]) / 2f, (a[2] + b[2]) / 2f)

    private fun rad(deg: Float): Float = deg * (PI.toFloat() / 180f)

    private fun shade(c: FloatArray, f: Float): FloatArray =
        floatArrayOf((c[0] * f).coerceIn(0f, 1f), (c[1] * f).coerceIn(0f, 1f), (c[2] * f).coerceIn(0f, 1f))

    // ------------------------------------------------------------------ primitives

    /** One flat quad; vertices are re-ordered so that it faces away from [inside]. */
    private fun quad(m: Mesh3, a: P, b: P, c: P, d: P, inside: P, uv: UvFn = null) {
        var n = norm(cross(sub(b, a), sub(d, a)))
        val centre = p((a[0] + b[0] + c[0] + d[0]) / 4f, (a[1] + b[1] + c[1] + d[1]) / 4f, (a[2] + b[2] + c[2] + d[2]) / 4f)
        var q = arrayOf(a, b, c, d)
        if (dot(n, sub(centre, inside)) < 0f) {
            q = arrayOf(a, d, c, b)
            n = neg(n)
        }
        val idx = IntArray(4)
        for (i in 0 until 4) {
            val t = uv?.invoke(q[i])
            idx[i] = m.add(q[i][0], q[i][1], q[i][2], n[0], n[1], n[2], t?.get(0) ?: 0f, t?.get(1) ?: 0f)
        }
        m.tri(idx[0], idx[1], idx[2])
        m.tri(idx[0], idx[2], idx[3])
    }

    /** Flat convex polygon (fan), facing away from [inside]. */
    private fun polyFlat(m: Mesh3, pts: List<P>, inside: P, uv: UvFn = null) {
        // Newell normal
        var nx = 0f
        var ny = 0f
        var nz = 0f
        for (i in pts.indices) {
            val c = pts[i]
            val nxt = pts[(i + 1) % pts.size]
            nx += (c[1] - nxt[1]) * (c[2] + nxt[2])
            ny += (c[2] - nxt[2]) * (c[0] + nxt[0])
            nz += (c[0] - nxt[0]) * (c[1] + nxt[1])
        }
        var n = norm(p(nx, ny, nz))
        var cx = 0f
        var cy = 0f
        var cz = 0f
        for (q in pts) {
            cx += q[0]; cy += q[1]; cz += q[2]
        }
        val centre = p(cx / pts.size, cy / pts.size, cz / pts.size)
        var list = pts
        if (dot(n, sub(centre, inside)) < 0f) {
            list = pts.reversed()
            n = neg(n)
        }
        val idx = IntArray(list.size)
        for (i in list.indices) {
            val t = uv?.invoke(list[i])
            idx[i] = m.add(list[i][0], list[i][1], list[i][2], n[0], n[1], n[2], t?.get(0) ?: 0f, t?.get(1) ?: 0f)
        }
        for (i in 1 until list.size - 1) m.tri(idx[0], idx[i], idx[i + 1])
    }

    /** Skins a stack of rings (same point count in each). Smooth = rounded normals, otherwise faceted. */
    private fun loft(m: Mesh3, rings: List<List<P>>, centers: List<P>, smooth: Boolean, uv: UvFn = null) {
        val levels = rings.size
        val n = rings[0].size
        if (!smooth) {
            for (i in 0 until levels - 1) {
                for (j in 0 until n) {
                    val j2 = (j + 1) % n
                    quad(m, rings[i][j], rings[i][j2], rings[i + 1][j2], rings[i + 1][j], mid(centers[i], centers[i + 1]), uv)
                }
            }
            return
        }
        val idx = Array(levels) { IntArray(n) }
        val nrm = Array(levels) { Array(n) { p(0f, 1f, 0f) } }
        for (i in 0 until levels) {
            for (j in 0 until n) {
                val a = sub(rings[i][(j + 1) % n], rings[i][(j + n - 1) % n])
                val lo = max(0, i - 1)
                val hi = min(levels - 1, i + 1)
                val b = if (hi == lo) p(0f, 1f, 0f) else sub(rings[hi][j], rings[lo][j])
                var nn = norm(cross(a, b))
                if (dot(nn, sub(rings[i][j], centers[i])) < 0f) nn = neg(nn)
                nrm[i][j] = nn
                val t = uv?.invoke(rings[i][j])
                idx[i][j] = m.add(rings[i][j][0], rings[i][j][1], rings[i][j][2], nn[0], nn[1], nn[2], t?.get(0) ?: 0f, t?.get(1) ?: 0f)
            }
        }
        for (i in 0 until levels - 1) {
            for (j in 0 until n) {
                val j2 = (j + 1) % n
                val p00 = rings[i][j]
                val g = cross(sub(rings[i][j2], p00), sub(rings[i + 1][j2], p00))
                if (dot(g, nrm[i][j]) >= 0f) {
                    m.tri(idx[i][j], idx[i][j2], idx[i + 1][j2])
                    m.tri(idx[i][j], idx[i + 1][j2], idx[i + 1][j])
                } else {
                    m.tri(idx[i][j], idx[i + 1][j2], idx[i][j2])
                    m.tri(idx[i][j], idx[i + 1][j], idx[i + 1][j2])
                }
            }
        }
    }

    /** Flat cap over a ring. */
    private fun cap(m: Mesh3, ring: List<P>, centre: P, normal: P) {
        val ci = m.add(centre[0], centre[1], centre[2], normal[0], normal[1], normal[2], 0f, 0f)
        val idx = IntArray(ring.size)
        for (i in ring.indices) idx[i] = m.add(ring[i][0], ring[i][1], ring[i][2], normal[0], normal[1], normal[2], 0f, 0f)
        for (i in ring.indices) {
            val j = (i + 1) % ring.size
            val g = cross(sub(ring[i], centre), sub(ring[j], centre))
            if (dot(g, normal) >= 0f) m.tri(ci, idx[i], idx[j]) else m.tri(ci, idx[j], idx[i])
        }
    }

    private fun box(m: Mesh3, cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, uv: UvFn = null) {
        val hx = sx / 2f
        val hy = sy / 2f
        val hz = sz / 2f
        val c = p(cx, cy, cz)
        val v = Array(8) { i ->
            p(cx + (if (i and 1 == 0) -hx else hx), cy + (if (i and 2 == 0) -hy else hy), cz + (if (i and 4 == 0) -hz else hz))
        }
        quad(m, v[0], v[1], v[3], v[2], c, uv)
        quad(m, v[4], v[5], v[7], v[6], c, uv)
        quad(m, v[0], v[1], v[5], v[4], c, uv)
        quad(m, v[2], v[3], v[7], v[6], c, uv)
        quad(m, v[0], v[2], v[6], v[4], c, uv)
        quad(m, v[1], v[3], v[7], v[5], c, uv)
    }

    /** Cylinder along X (barrels, exhaust pipes). r0 at the rear end, r1 at the front end. */
    private fun cylX(m: Mesh3, x0: Float, x1: Float, cy: Float, cz: Float, r0: Float, r1: Float, n: Int = 12) {
        val rings = ArrayList<List<P>>()
        val centres = ArrayList<P>()
        for (k in 0..1) {
            val x = if (k == 0) x0 else x1
            val r = if (k == 0) r0 else r1
            rings.add((0 until n).map { j ->
                val a = 2f * PI.toFloat() * j / n
                p(x, cy + r * cos(a), cz + r * sin(a))
            })
            centres.add(p(x, cy, cz))
        }
        loft(m, rings, centres, true)
        cap(m, rings[0], centres[0], p(-1f, 0f, 0f))
        cap(m, rings[1], centres[1], p(1f, 0f, 0f))
    }

    /** Upright cylinder (cupolas, drums, turret ring). */
    private fun cylY(m: Mesh3, cx: Float, y0: Float, y1: Float, cz: Float, rx: Float, rz: Float, n: Int = 10) {
        val rings = ArrayList<List<P>>()
        val centres = ArrayList<P>()
        for (k in 0..1) {
            val y = if (k == 0) y0 else y1
            rings.add((0 until n).map { j ->
                val a = 2f * PI.toFloat() * j / n
                p(cx + rx * cos(a), y, cz + rz * sin(a))
            })
            centres.add(p(cx, y, cz))
        }
        loft(m, rings, centres, true)
        cap(m, rings[0], centres[0], p(0f, -1f, 0f))
        cap(m, rings[1], centres[1], p(0f, 1f, 0f))
    }

    /** Cylinder lying along Z (road wheels, drums on their side). */
    private fun cylZ(m: Mesh3, cx: Float, cy: Float, z0: Float, z1: Float, r: Float, n: Int = 12) {
        val rings = ArrayList<List<P>>()
        val centres = ArrayList<P>()
        for (k in 0..1) {
            val z = if (k == 0) z0 else z1
            rings.add((0 until n).map { j ->
                val a = 2f * PI.toFloat() * j / n
                p(cx + r * cos(a), cy + r * sin(a), z)
            })
            centres.add(p(cx, cy, z))
        }
        loft(m, rings, centres, true)
        cap(m, rings[0], centres[0], p(0f, 0f, -1f))
        cap(m, rings[1], centres[1], p(0f, 0f, 1f))
    }

    private fun sphere(m: Mesh3, cx: Float, cy: Float, cz: Float, r: Float, nu: Int = 10, nv: Int = 6) {
        val rings = ArrayList<List<P>>()
        val centres = ArrayList<P>()
        for (k in 0..nv) {
            val lat = -PI.toFloat() / 2f + PI.toFloat() * k / nv
            val rr = max(0.001f, r * cos(lat))
            val y = cy + r * sin(lat)
            rings.add((0 until nu).map { j ->
                val a = 2f * PI.toFloat() * j / nu
                p(cx + rr * cos(a), y, cz + rr * sin(a))
            })
            centres.add(p(cx, y, cz))
        }
        loft(m, rings, centres, true)
    }

    // ------------------------------------------------------------------ the tank

    fun build(spec: TankSpec, deckW: Int, deckH: Int): Result {
        val d = spec.design
        val paint = floatArrayOf(d.paint.body.r, d.paint.body.g, d.paint.body.b)
        val hull = ArrayList<Part>()
        val turret = ArrayList<Part>()
        val turretBase = buildHull(spec, paint, deckW, deckH, hull)
        buildTurret(spec, paint, turret)
        return Result(hull, turret, turretBase)
    }

    private fun part(list: MutableList<Part>, id: String, kind: Int, c: FloatArray): Mesh3 {
        val m = Mesh3()
        list.add(Part(id, kind, c[0], c[1], c[2], m))
        return m
    }

    /** Returns the height of the turret base above the ground. */
    private fun buildHull(spec: TankSpec, paint: FloatArray, deckW: Int, deckH: Int, out: MutableList<Part>): Float {
        val d = spec.design
        val len = d.hullLenPx.toFloat()
        val wid = d.hullWidPx.toFloat()
        val tw = d.trackWidPx.toFloat()
        val hullH = (wid * 0.42f).coerceIn(15f, 26f)
        val trackH = hullH * 0.95f
        val gc = max(2.5f, trackH * 0.16f)
        val bodyB = (wid - 2f * tw) / 2f
        val sideSlope = spec.armor.hullSide.slopeDeg.coerceIn(0f, 50f)
        val inset = hullH * 0.10f + hullH * tan(rad(sideSlope)) * 0.4f
        val bodyT = bodyB - inset

        // glacis: the real front armour slope decides how flat the plate is
        val slopeF = spec.armor.hullFront.slopeDeg.coerceIn(8f, 62f)
        val drop = hullH * 0.55f
        val run = (drop * tan(rad(slopeF))).coerceIn(2.5f, d.nosePx * 1.1f)
        val lowerRun = 3f
        val xFront = len / 2f
        val x2 = xFront - lowerRun
        val x1 = x2 - run
        val yG = hullH - drop
        val xRear = -len / 2f
        val taper = bodyT * d.noseTaper * 2.2f
        val inside = p(0f, hullH * 0.4f, 0f)

        // stations: x, top height, half width on top, half width at the bottom
        val sx = floatArrayOf(xRear, xRear + len * 0.05f, x1, x2)
        val sy = floatArrayOf(hullH * 0.86f, hullH, hullH, yG)
        val swt = floatArrayOf(bodyT * 0.98f, bodyT, bodyT, bodyT - taper)
        val swb = floatArrayOf(bodyB * 0.98f, bodyB, bodyB, bodyB - taper)

        val uvDeck: UvFn = { q -> floatArrayOf((q[0] + deckW / 2f) / deckW, (q[2] + deckH / 2f) / deckH) }

        // painted body
        val body = part(out, "body", PAINT, shade(paint, 0.92f))
        for (i in 0 until 3) {
            for (side in intArrayOf(-1, 1)) {
                quad(
                    body,
                    p(sx[i], gc, side * swb[i]), p(sx[i + 1], gc, side * swb[i + 1]),
                    p(sx[i + 1], sy[i + 1], side * swt[i + 1]), p(sx[i], sy[i], side * swt[i]), inside
                )
            }
        }
        quad(body, p(xRear, gc, -swb[0]), p(xRear, gc, swb[0]), p(xRear, sy[0], swt[0]), p(xRear, sy[0], -swt[0]), inside)
        val wbF = swb[3] * 0.95f
        quad(body, p(x2, yG, -swt[3]), p(x2, yG, swt[3]), p(xFront, gc, wbF), p(xFront, gc, -wbF), inside)

        // casemate of tank destroyers
        var base = hullH + 1.4f
        if (d.casemate) {
            val cH = wid * 0.30f
            val xc0 = -len * 0.28f
            val xc1 = len * 0.38f
            val slopeC = spec.armor.turretFront.slopeDeg.coerceIn(8f, 60f)
            val pull = min(cH * tan(rad(slopeC)), (xc1 - xc0) * 0.4f)
            val wb = bodyT - 1f
            val wt = wb - cH * 0.22f
            val cm = part(out, "casemate", PAINT, shade(paint, 0.97f))
            val ci = p((xc0 + xc1) / 2f, hullH + cH / 2f, 0f)
            val b0 = p(xc0, hullH, -wb); val b1 = p(xc1, hullH, -wb); val b2 = p(xc1, hullH, wb); val b3 = p(xc0, hullH, wb)
            val t0 = p(xc0 + 2f, hullH + cH, -wt); val t1 = p(xc1 - pull, hullH + cH, -wt)
            val t2 = p(xc1 - pull, hullH + cH, wt); val t3 = p(xc0 + 2f, hullH + cH, wt)
            quad(cm, b0, b1, t1, t0, ci)
            quad(cm, b3, b2, t2, t3, ci)
            quad(cm, b1, b2, t2, t1, ci)
            quad(cm, b0, b3, t3, t0, ci)
            quad(cm, t0, t1, t2, t3, ci)
            val hatch = part(out, "casemate_hatch", DETAIL, shade(paint, 0.6f))
            box(hatch, xc0 + (xc1 - xc0) * 0.35f, hullH + cH + 1.2f, -wt * 0.45f, 6f, 2.4f, 7f)
            cylY(hatch, xc0 + (xc1 - xc0) * 0.45f, hullH + cH, hullH + cH + 3.2f, wt * 0.45f, 3.2f, 3.2f, 10)
            base = hullH + cH * 0.35f
        }

        // roof: the painted top-down sprite lies on the deck and the glacis (grille, insignia, camouflage)
        val deck = part(out, "deck", DECK, floatArrayOf(1f, 1f, 1f))
        for (i in 0 until 3) {
            quad(
                deck,
                p(sx[i], sy[i] + 0.15f, -swt[i]), p(sx[i + 1], sy[i + 1] + 0.15f, -swt[i + 1]),
                p(sx[i + 1], sy[i + 1] + 0.15f, swt[i + 1]), p(sx[i], sy[i] + 0.15f, swt[i]), inside, uvDeck
            )
        }

        // tracks: rounded runs, wheels
        val tracks = part(out, "tracks", DARK, floatArrayOf(0.10f, 0.10f, 0.11f))
        val wheels = part(out, "wheels", WHEEL, floatArrayOf(0.19f, 0.19f, 0.20f))
        val rT = trackH / 2f
        val steps = 8
        val outline = ArrayList<FloatArray>()   // x, y pairs of the stadium shape
        for (k in 0..steps) {
            val a = rad(90f - 180f * k / steps)
            outline.add(floatArrayOf((len / 2f - rT) + rT * cos(a), rT + rT * sin(a)))
        }
        for (k in 0..steps) {
            val a = rad(-90f - 180f * k / steps)
            outline.add(floatArrayOf(-(len / 2f - rT) + rT * cos(a), rT + rT * sin(a)))
        }
        for (side in intArrayOf(-1, 1)) {
            val zc = side * (wid / 2f - tw / 2f)
            val zIn = zc - tw / 2f
            val zOut = zc + tw / 2f
            val centre = p(0f, rT, zc)
            polyFlat(tracks, outline.map { p(it[0], it[1], zIn) }, centre)
            polyFlat(tracks, outline.map { p(it[0], it[1], zOut) }, centre)
            for (i in outline.indices) {
                val j = (i + 1) % outline.size
                quad(
                    tracks,
                    p(outline[i][0], outline[i][1], zIn), p(outline[j][0], outline[j][1], zIn),
                    p(outline[j][0], outline[j][1], zOut), p(outline[i][0], outline[i][1], zOut), centre
                )
            }
            // road wheels, sprocket and idler on the outer face
            val wr = trackH * 0.50f
            val n = max(4, (len / (wr * 2.15f)).toInt())
            val faceZ = if (side > 0) zOut else zIn
            val z0 = if (side > 0) faceZ else faceZ - 2.4f
            val z1 = if (side > 0) faceZ + 2.4f else faceZ
            for (i in 0 until n) {
                val cx = -len / 2f + rT + (len - 2f * rT) * i / (n - 1)
                val r = if (i == 0 || i == n - 1) rT * 0.98f else wr
                cylZ(wheels, cx, rT, z0, z1, r, 12)
                cylZ(tracks, cx, rT, z0 - 0.4f * side.toFloat().coerceAtLeast(0f), z1 + 0.4f * (-side.toFloat()).coerceAtLeast(0f), r * 0.38f, 8)
            }
        }

        // fenders, skirts and fittings
        val fit = part(out, "fittings", DETAIL, shade(paint, 0.72f))
        if (d.fenders) {
            for (side in intArrayOf(-1, 1)) {
                box(fit, -len * 0.04f, trackH + 0.9f, side * (wid / 2f - tw / 2f), len * 0.78f, 1.3f, tw + 2.5f)
            }
        }
        if (d.skirts) {
            val plates = 7
            val span = len * 0.68f
            val pl = span / plates - 0.9f
            val ph = trackH * 0.82f
            for (side in intArrayOf(-1, 1)) {
                for (k in 0 until plates) {
                    val cx = -span / 2f + span * (k + 0.5f) / plates + len * 0.03f
                    box(fit, cx, 1.4f + ph / 2f, side * (wid / 2f + 1.1f), pl, ph, 1.2f)
                }
            }
        }
        if (!d.casemate) {
            // driver hatch, tool boxes
            box(fit, x1 - 4f, hullH + 1.6f, -bodyT * 0.42f, 6f, 2.8f, 7f)
            box(fit, -len * 0.18f, hullH + 2.1f, wid * 0.30f, len * 0.12f, 3.6f, 6f)
        }
        box(fit, -len * 0.26f, hullH + 1.8f, -wid * 0.30f, len * 0.10f, 3f, 6f)
        box(fit, x1 + 1f, hullH + 1.2f, bodyT * 0.8f, 2.6f, 2.4f, 2.6f)
        box(fit, x1 + 1f, hullH + 1.2f, -bodyT * 0.8f, 2.6f, 2.4f, 2.6f)
        if (spec.nation.name == "USSR") {
            val drums = part(out, "drums", DETAIL, floatArrayOf(0.34f, 0.30f, 0.20f))
            for (side in intArrayOf(-1, 1)) cylZ(drums, -len * 0.36f, hullH + 3.3f, side * wid * 0.20f - 4f, side * wid * 0.20f + 4f, 3.2f, 10)
        }
        val ex = part(out, "exhaust", DARK, floatArrayOf(0.25f, 0.22f, 0.20f))
        cylX(ex, xRear - 5f, xRear + 1f, hullH * 0.55f, wid * 0.24f, 2.4f, 2.1f, 8)
        cylX(ex, xRear - 5f, xRear + 1f, hullH * 0.55f, -wid * 0.24f, 2.4f, 2.1f, 8)

        // turret ring
        if (!d.casemate) {
            val ring = part(out, "turret_ring", DETAIL, shade(paint, 0.55f))
            val rr = min(d.turretRxPx, d.turretRyPx) * 1.04f
            cylY(ring, d.turretOffsetPx.toFloat(), hullH + 0.2f, hullH + 1.4f, 0f, rr, rr, 16)
        }
        return base
    }

    private fun ringPoints(shape: TurretShape, rx: Float, ry: Float): List<FloatArray> {
        fun poly(f: FloatArray): List<FloatArray> = (0 until f.size / 2).map { floatArrayOf(f[it * 2] * rx, f[it * 2 + 1] * ry) }
        fun superEllipse(e: Double, n: Int): List<FloatArray> = (0 until n).map { i ->
            val t = 2.0 * PI * i / n
            val c = cos(t)
            val s = sin(t)
            val x = sign(c) * abs(c).pow(2.0 / e)
            val y = sign(s) * abs(s).pow(2.0 / e)
            floatArrayOf((x * rx).toFloat(), (y * ry).toFloat())
        }
        return when (shape) {
            TurretShape.ROUND, TurretShape.MOUNT -> superEllipse(2.0, 20)
            TurretShape.CAST -> superEllipse(2.3, 20)
            TurretShape.FLAT_CAST -> superEllipse(2.0, 24)
            TurretShape.BOX -> superEllipse(5.0, 24)
            TurretShape.OCTAGON -> poly(
                floatArrayOf(-1f, -0.55f, -0.55f, -1f, 0.45f, -0.95f, 1f, -0.45f, 1f, 0.45f, 0.45f, 0.95f, -0.55f, 1f, -1f, 0.55f)
            )
            TurretShape.ANGULAR -> poly(
                floatArrayOf(-1f, -0.70f, -0.75f, -1f, 0.55f, -0.85f, 1f, -0.45f, 1f, 0.45f, 0.55f, 0.85f, -0.75f, 1f, -1f, 0.70f)
            )
        }
    }

    private fun buildTurret(spec: TankSpec, paint: FloatArray, out: MutableList<Part>) {
        val d = spec.design
        val rx = d.turretRxPx.toFloat()
        val ry = d.turretRyPx.toFloat()
        val mount = d.turretShape == TurretShape.MOUNT
        val tH = if (mount) 8f else (ry * 0.80f).coerceIn(9f, 22f)
        val cast = d.turretShape == TurretShape.ROUND || d.turretShape == TurretShape.CAST || d.turretShape == TurretShape.FLAT_CAST
        val body = part(out, "turret", PAINT, shade(paint, 1.05f))

        if (!mount) {
            val frontSlope = tan(rad(spec.armor.turretFront.slopeDeg.coerceIn(0f, 50f)))
            val sideSlope = tan(rad(spec.armor.turretSide.slopeDeg.coerceIn(0f, 40f)))
            val profile = if (cast) {
                listOf(0f to 1.0f, 0.22f to 1.03f, 0.50f to 0.98f, 0.76f to 0.87f, 0.93f to 0.68f, 1.0f to 0.52f)
            } else {
                listOf(0f to 1.0f, 0.65f to 0.96f, 1.0f to 0.92f)
            }
            val base = ringPoints(d.turretShape, rx, ry)
            val rings = ArrayList<List<P>>()
            val centres = ArrayList<P>()
            for ((yf, sc) in profile) {
                val y = yf * tH
                rings.add(base.map { b ->
                    var x = b[0] * sc
                    val z = b[1] * (sc - sideSlope * yf * 0.2f)
                    if (!cast && b[0] > 0.3f * rx) x -= yf * tH * frontSlope * 0.55f * (b[0] / rx)
                    p(x, y, z)
                })
                centres.add(p(0f, y, 0f))
            }
            loft(body, rings, centres, cast)
            cap(body, rings[rings.size - 1], centres[centres.size - 1], p(0f, 1f, 0f))
            cap(body, rings[0], centres[0], p(0f, -1f, 0f))

            if (d.bustlePx > 0) {
                val bl = d.bustlePx.toFloat()
                val bh = ry * 1.25f
                val lo = listOf(p(-rx * 0.6f, 0f, -bh / 2f), p(-rx * 0.6f - bl - 2f, 0f, -bh / 2f), p(-rx * 0.6f - bl - 2f, 0f, bh / 2f), p(-rx * 0.6f, 0f, bh / 2f))
                val hi = listOf(p(-rx * 0.6f, tH * 0.78f, -bh * 0.42f), p(-rx * 0.6f - bl - 2f, tH * 0.72f, -bh * 0.42f), p(-rx * 0.6f - bl - 2f, tH * 0.72f, bh * 0.42f), p(-rx * 0.6f, tH * 0.78f, bh * 0.42f))
                loft(body, listOf(lo, hi), listOf(p(-rx * 0.6f - bl / 2f, 0f, 0f), p(-rx * 0.6f - bl / 2f, tH * 0.75f, 0f)), false)
                cap(body, hi, p(-rx * 0.6f - bl / 2f, tH * 0.75f, 0f), p(0f, 1f, 0f))
            }

            val det = part(out, "turret_detail", DETAIL, shade(paint, 0.6f))
            if (d.openTop) {
                // open-topped turret: dark interior
                val inner = ringPoints(d.turretShape, rx * 0.62f, ry * 0.62f).map { p(it[0], tH + 0.2f, it[1]) }
                polyFlat(det, inner, p(0f, 0f, 0f))
            } else {
                if (d.cupola) {
                    val cr = max(3f, ry * 0.27f)
                    cylY(det, -rx * 0.25f, tH, tH + 4.5f, ry * 0.45f, cr, cr, 10)
                    cylY(det, -rx * 0.25f, tH + 4.5f, tH + 5.4f, ry * 0.45f, cr * 0.7f, cr * 0.7f, 8)
                }
                box(det, -rx * 0.30f, tH + 1.0f, -ry * 0.5f, max(5f, rx * 0.30f), 2.2f, max(5f, ry * 0.30f))
            }
        } else {
            val ball = part(out, "mount", DETAIL, shade(paint, 0.62f))
            sphere(ball, 0f, tH * 0.5f, 0f, 4.6f, 10, 6)
        }

        // gun: mantlet, tapered barrel, bore evacuator, muzzle brake
        val steel = part(out, "steel", STEEL, floatArrayOf(0.22f, 0.22f, 0.24f))
        val by = if (mount) tH * 0.5f else tH * 0.62f
        val length = d.barrelPx.toFloat()
        val r0 = max(1.7f, d.barrelThickPx / 2f + 0.9f)
        val r1 = r0 * 0.82f
        val start = if (mount) 3f else rx - 2f
        if (!mount) {
            val mh = min(tH * 0.95f, d.mantletPx * 0.72f)
            box(steel, rx - 1.2f, by, 0f, 5.5f, mh, d.mantletPx.toFloat())
        }
        cylX(steel, start, rx + length, by, 0f, r0, r1, 12)
        if (d.barrelThickPx >= 4) cylX(steel, rx + length * 0.55f - 4f, rx + length * 0.55f + 4f, by, 0f, r0 * 1.5f, r0 * 1.5f, 10)
        val tip = rx + length
        when (d.muzzle) {
            Muzzle.NONE -> {}
            Muzzle.SINGLE -> cylX(steel, tip - 3.5f, tip + 0.5f, by, 0f, r1 * 1.55f, r1 * 1.55f, 10)
            Muzzle.DOUBLE -> {
                cylX(steel, tip - 5.5f, tip - 3.0f, by, 0f, r1 * 1.55f, r1 * 1.55f, 10)
                cylX(steel, tip - 2.2f, tip + 0.4f, by, 0f, r1 * 1.55f, r1 * 1.55f, 10)
            }
            Muzzle.PEPPERPOT -> cylX(steel, tip - 5.5f, tip + 0.4f, by, 0f, r1 * 1.85f, r1 * 1.85f, 12)
            Muzzle.FLASH -> cylX(steel, tip - 3.5f, tip + 0.6f, by, 0f, r1 * 1.1f, r1 * 1.9f, 10)
        }
    }
}
