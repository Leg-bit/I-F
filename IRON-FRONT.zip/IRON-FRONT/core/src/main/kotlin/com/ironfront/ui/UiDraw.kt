package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.utils.Align
import com.ironfront.core.AssetManager

/** Small drawing helpers shared by the menu screens. */
object UiDraw {
    private val layout = GlyphLayout()

    fun fillRect(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, color: Color) {
        b.color = color
        b.draw(AssetManager.getTexture("pixel"), x, y, w, h)
        b.color = Color.WHITE
    }

    fun outlineRect(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, t: Float, color: Color) {
        val pixel = AssetManager.getTexture("pixel")
        b.color = color
        b.draw(pixel, x, y, w, t)
        b.draw(pixel, x, y + h - t, w, t)
        b.draw(pixel, x, y, t, h)
        b.draw(pixel, x + w - t, y, t, h)
        b.color = Color.WHITE
    }

    fun text(b: SpriteBatch, text: String, x: Float, y: Float) {
        AssetManager.font.draw(b, text, x, y)
    }

    fun coloredText(b: SpriteBatch, text: String, x: Float, y: Float, color: Color) {
        val font = AssetManager.font
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun wrapped(b: SpriteBatch, text: String, x: Float, y: Float, width: Float) {
        AssetManager.font.draw(b, text, x, y, width, Align.left, true)
    }

    fun centeredText(b: SpriteBatch, text: String, cx: Float, cy: Float) {
        val font = AssetManager.font
        layout.setText(font, text)
        font.draw(b, layout, cx - layout.width / 2f, cy + layout.height / 2f)
    }

    fun button(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, fill: Color, label: String) {
        fillRect(b, x, y, w, h, fill)
        outlineRect(b, x, y, w, h, 2f, Color.LIGHT_GRAY)
        centeredText(b, label, x + w / 2f, y + h / 2f)
    }

    fun hit(px: Float, py: Float, x: Float, y: Float, w: Float, h: Float): Boolean =
        px >= x && px <= x + w && py >= y && py <= y + h
}
