package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.utils.Align
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.Shaders
import com.ironfront.tanks.TankSpec
import kotlin.math.max
import kotlin.math.sqrt

/** Small drawing helpers shared by every screen. Text y is the TOP of the text; screen y points up. */
object UiDraw {
    private val layout = GlyphLayout()

    fun fillRect(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, color: Color) {
        b.color = color
        b.draw(AssetManager.getTexture("pixel"), x, y, w, h)
        b.color = Color.WHITE
    }

    fun outlineRect(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, t: Float, color: Color) {
        val pixel = AssetManager.getTexture("pixel")
        b.color = color
        b.draw(pixel, x, y, w, t)
        b.draw(pixel, x, y + h - t, w, t)
        b.draw(pixel, x, y, t, h)
        b.draw(pixel, x + w - t, y, t, h)
        b.color = Color.WHITE
    }

    fun panel(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, fill: Color = Theme.panel, border: Color = Theme.border) {
        fillRect(b, x, y, w, h, fill)
        outlineRect(b, x, y, w, h, 2f, border)
    }

    fun text(b: SpriteBatch, text: String, x: Float, y: Float) {
        AssetManager.font.draw(b, text, x, y)
    }

    fun coloredText(b: SpriteBatch, text: String, x: Float, y: Float, color: Color) {
        val font = AssetManager.font
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun small(b: SpriteBatch, text: String, x: Float, y: Float, color: Color = Theme.text) {
        val font = AssetManager.fontSmall
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun big(b: SpriteBatch, text: String, x: Float, y: Float, color: Color = Theme.text) {
        val font = AssetManager.fontBig
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun wrapped(b: SpriteBatch, text: String, x: Float, y: Float, width: Float) {
        AssetManager.font.draw(b, text, x, y, width, Align.left, true)
    }

    fun smallWrapped(b: SpriteBatch, text: String, x: Float, y: Float, width: Float, color: Color = Theme.textDim) {
        val font = AssetManager.fontSmall
        font.color = color
        font.draw(b, text, x, y, width, Align.left, true)
        font.color = Color.WHITE
    }

    fun centeredText(b: SpriteBatch, text: String, cx: Float, cy: Float) {
        val font = AssetManager.font
        layout.setText(font, text)
        font.draw(b, layout, cx - layout.width / 2f, cy + layout.height / 2f)
    }

    fun centered(b: SpriteBatch, font: BitmapFont, text: String, cx: Float, cy: Float, color: Color = Theme.text) {
        layout.setText(font, text)
        font.color = color
        font.draw(b, layout, cx - layout.width / 2f, cy + layout.height / 2f)
        font.color = Color.WHITE
    }

    fun rightText(b: SpriteBatch, font: BitmapFont, text: String, rx: Float, y: Float, color: Color = Theme.text) {
        layout.setText(font, text)
        font.color = color
        font.draw(b, layout, rx - layout.width, y)
        font.color = Color.WHITE
    }

    fun textWidth(font: BitmapFont, text: String): Float {
        layout.setText(font, text)
        return layout.width
    }

    fun button(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, fill: Color, label: String) {
        fillRect(b, x, y, w, h, fill)
        fillRect(b, x, y + h - 3f, w, 3f, Color(1f, 1f, 1f, 0.12f))
        outlineRect(b, x, y, w, h, 2f, Color.LIGHT_GRAY)
        centeredText(b, label, x + w / 2f, y + h / 2f)
    }

    fun smallButton(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, fill: Color, label: String) {
        fillRect(b, x, y, w, h, fill)
        outlineRect(b, x, y, w, h, 2f, Color.LIGHT_GRAY)
        centered(b, AssetManager.fontSmall, label, x + w / 2f, y + h / 2f)
    }

    fun bar(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, ratio: Float, fill: Color) {
        fillRect(b, x, y, w, h, Theme.barBack)
        fillRect(b, x + 1f, y + 1f, (w - 2f) * ratio.coerceIn(0f, 1f), h - 2f, fill)
        outlineRect(b, x, y, w, h, 1f, Theme.border)
    }

    fun line(b: SpriteBatch, x1: Float, y1: Float, x2: Float, y2: Float, t: Float, color: Color) {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        val ang = MathUtils.atan2(dy, dx) * MathUtils.radiansToDegrees
        b.color = color
        b.draw(AssetManager.getRegion("pixel"), x1, y1 - t / 2f, 0f, t / 2f, len, t, 1f, 1f, ang)
        b.color = Color.WHITE
    }

    fun hit(px: Float, py: Float, x: Float, y: Float, w: Float, h: Float): Boolean =
        px >= x && px <= x + w && py >= y && py <= y + h

    /** Scale that makes the whole tank (hull + gun) fit into [targetWidth] pixels. */
    fun iconScale(spec: TankSpec, targetWidth: Float): Float {
        val total = spec.design.hullLenPx + spec.design.overhangPx
        return targetWidth / max(1, total)
    }

    /**
     * Draws a tank (hull and turret) centred around [cx],[cy]. The gun overhang is taken into account
     * so the whole vehicle looks centred.
     */
    fun tankIcon(
        b: SpriteBatch,
        spec: TankSpec,
        cx: Float,
        cy: Float,
        scale: Float,
        hullRot: Float = 0f,
        turretRot: Float = 0f,
        tint: Color = Color.WHITE,
        lit: Boolean = false
    ) {
        val id = spec.id
        val hull = AssetManager.getRegion("hull_$id")
        val turret = AssetManager.getRegion("turret_$id")
        val hw = hull.regionWidth.toFloat()
        val hh = hull.regionHeight.toFloat()
        val tw = turret.regionWidth.toFloat()
        val th = turret.regionHeight.toFloat()
        val pivot = AssetManager.pivotX(id)
        val d = spec.design

        val centerX = cx - d.overhangPx * scale / 2f
        val cos = MathUtils.cosDeg(hullRot)
        val sin = MathUtils.sinDeg(hullRot)
        // shift so the group is centred even when the hull is rotated
        val ox = centerX
        b.color = tint
        val tx = ox + cos * d.turretOffsetPx * scale
        val ty = cy + sin * d.turretOffsetPx * scale
        if (lit && Shaders.beginLit(b)) {
            Shaders.drawLit(b, hull, ox - hw / 2f, cy - hh / 2f, hw / 2f, hh / 2f, hw, hh, scale, scale, hullRot)
            Shaders.drawLit(b, turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, scale, scale, hullRot + turretRot)
            Shaders.endLit(b)
        } else {
            b.draw(hull, ox - hw / 2f, cy - hh / 2f, hw / 2f, hh / 2f, hw, hh, scale, scale, hullRot)
            b.draw(turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, scale, scale, hullRot + turretRot)
        }
        b.color = Color.WHITE
    }

    /** The three currency chips shown in every header. */
    fun currencyBar(b: SpriteBatch, rightX: Float, y: Float) {
        val w = GameManager.wallet
        val p = GameManager.playerProfile
        val f = AssetManager.font
        var x = rightX
        val items = listOf(
            Pair("XP " + p.freeXp, Theme.xpColor),
            Pair("GOLD " + w.gold, Theme.goldCoin),
            Pair("CR " + w.credits, Theme.credits)
        )
        for (item in items) {
            val tw = textWidth(f, item.first)
            fillRect(b, x - tw - 24f, y - 8f, tw + 24f, 36f, Theme.panelLight)
            outlineRect(b, x - tw - 24f, y - 8f, tw + 24f, 36f, 1f, Theme.border)
            rightText(b, f, item.first, x - 12f, y + 22f, item.second)
            x -= tw + 36f
        }
    }
}
