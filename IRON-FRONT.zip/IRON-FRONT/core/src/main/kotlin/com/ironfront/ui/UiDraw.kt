package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.utils.Align
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.Shaders
import com.ironfront.tanks.TankSpec
import kotlin.math.max
import kotlin.math.sqrt

object UiDraw {
    private val layout = GlyphLayout()

    fun fillRect(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, color: Color) {
        b.color = color
        b.draw(AssetManager.getTexture("pixel"), x, y, w, h)
        b.color = Color.WHITE
    }

    fun outlineRect(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, t: Float, color: Color) {
        val pixel = AssetManager.getTexture("pixel")
        b.color = color
        b.draw(pixel, x, y, w, t)
        b.draw(pixel, x, y + h - t, w, t)
        b.draw(pixel, x, y, t, h)
        b.draw(pixel, x + w - t, y, t, h)
        b.color = Color.WHITE
    }

    fun tacticalBackdrop(b: SpriteBatch, time: Float = 0f) {
        fillRect(b, 0f, 0f, 1280f, 720f, Theme.bg)
        fillRect(b, 0f, 440f, 1280f, 280f, Color(0.08f, 0.11f, 0.15f, 0.55f))
        fillRect(b, 0f, 580f, 1280f, 140f, Color(0.10f, 0.14f, 0.19f, 0.45f))

        val gridColor = Color(0.14f, 0.18f, 0.24f, 0.35f)
        var gx = 0f
        while (gx <= 1280f) {
            fillRect(b, gx, 0f, 1f, 720f, gridColor)
            gx += 64f
        }
        var gy = 0f
        while (gy <= 720f) {
            fillRect(b, 0f, gy, 1280f, 1f, gridColor)
            gy += 64f
        }

        if (time > 0f) {
            val scanX = (time * 90f) % 1400f - 60f
            fillRect(b, scanX, 0f, 2f, 720f, Color(0.25f, 0.75f, 0.95f, 0.08f))
            fillRect(b, scanX - 24f, 0f, 24f, 720f, Color(0.25f, 0.75f, 0.95f, 0.03f))
        }
    }

    fun panel(
        b: SpriteBatch,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        fill: Color = Theme.panel,
        border: Color = Theme.border,
        accentTop: Color? = null
    ) {
        fillRect(b, x + 4f, y - 4f, w, h, Color(0f, 0f, 0f, 0.42f))
        fillRect(b, x, y, w, h, fill)
        fillRect(b, x, y + h - 2f, w, 2f, Color(1f, 1f, 1f, 0.08f))
        outlineRect(b, x, y, w, h, 1.5f, border)

        if (accentTop != null) {
            fillRect(b, x, y + h - 4f, w, 4f, accentTop)
        }

        val tick = 8f
        val tc = Color(border.r * 1.35f, border.g * 1.35f, border.b * 1.35f, 0.9f)
        fillRect(b, x, y + h - tick, 2f, tick, tc)
        fillRect(b, x, y + h - 2f, tick, 2f, tc)
        fillRect(b, x + w - 2f, y, 2f, tick, tc)
        fillRect(b, x + w - tick, y, tick, 2f, tc)
    }

    fun text(b: SpriteBatch, text: String, x: Float, y: Float) {
        AssetManager.font.draw(b, text, x, y)
    }

    fun coloredText(b: SpriteBatch, text: String, x: Float, y: Float, color: Color) {
        val font = AssetManager.font
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun small(b: SpriteBatch, text: String, x: Float, y: Float, color: Color = Theme.text) {
        val font = AssetManager.fontSmall
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun big(b: SpriteBatch, text: String, x: Float, y: Float, color: Color = Theme.text) {
        val font = AssetManager.fontBig
        font.color = color
        font.draw(b, text, x, y)
        font.color = Color.WHITE
    }

    fun wrapped(b: SpriteBatch, text: String, x: Float, y: Float, width: Float) {
        AssetManager.font.draw(b, text, x, y, width, Align.left, true)
    }

    fun smallWrapped(b: SpriteBatch, text: String, x: Float, y: Float, width: Float, color: Color = Theme.textDim) {
        val font = AssetManager.fontSmall
        font.color = color
        font.draw(b, text, x, y, width, Align.left, true)
        font.color = Color.WHITE
    }

    fun centeredText(b: SpriteBatch, text: String, cx: Float, cy: Float, color: Color = Theme.text) {
        val font = AssetManager.font
        layout.setText(font, text)
        font.color = color
        font.draw(b, layout, cx - layout.width / 2f, cy + layout.height / 2f)
        font.color = Color.WHITE
    }

    fun centered(b: SpriteBatch, font: BitmapFont, text: String, cx: Float, cy: Float, color: Color = Theme.text) {
        layout.setText(font, text)
        font.color = color
        font.draw(b, layout, cx - layout.width / 2f, cy + layout.height / 2f)
        font.color = Color.WHITE
    }

    fun rightText(b: SpriteBatch, font: BitmapFont, text: String, rx: Float, y: Float, color: Color = Theme.text) {
        layout.setText(font, text)
        font.color = color
        font.draw(b, layout, rx - layout.width, y)
        font.color = Color.WHITE
    }

    fun textWidth(font: BitmapFont, text: String): Float {
        layout.setText(font, text)
        return layout.width
    }

    fun button(
        b: SpriteBatch,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        fill: Color,
        label: String,
        subLabel: String? = null,
        enabled: Boolean = true
    ) {
        val base = if (enabled) fill else Color(0.14f, 0.16f, 0.19f, 1f)
        fillRect(b, x + 3f, y - 3f, w, h, Color(0f, 0f, 0f, 0.45f))
        fillRect(b, x, y, w, h, base)
        fillRect(b, x, y, w, 4f, Color(0f, 0f, 0f, 0.30f))
        fillRect(b, x, y + h - 3f, w, 3f, Color(1f, 1f, 1f, if (enabled) 0.22f else 0.05f))
        outlineRect(
            b, x, y, w, h, 1.5f,
            if (enabled) Color(base.r * 1.45f + 0.12f, base.g * 1.45f + 0.12f, base.b * 1.45f + 0.12f, 0.9f)
            else Theme.border
        )

        val txtColor = if (enabled) Theme.text else Theme.textDim
        if (subLabel == null) {
            centeredText(b, label, x + w / 2f, y + h / 2f, txtColor)
        } else {
            centeredText(b, label, x + w / 2f, y + h * 0.62f, txtColor)
            centered(b, AssetManager.fontSmall, subLabel, x + w / 2f, y + h * 0.28f, Color(1f, 1f, 1f, 0.72f))
        }
    }

    fun smallButton(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, fill: Color, label: String, activeBorder: Color? = null) {
        fillRect(b, x + 2f, y - 2f, w, h, Color(0f, 0f, 0f, 0.38f))
        fillRect(b, x, y, w, h, fill)
        fillRect(b, x, y + h - 2f, w, 2f, Color(1f, 1f, 1f, 0.16f))
        outlineRect(b, x, y, w, h, 1.5f, activeBorder ?: Theme.borderBright)
        centered(b, AssetManager.fontSmall, label, x + w / 2f, y + h / 2f, Theme.text)
    }

    fun badge(b: SpriteBatch, x: Float, y: Float, text: String, bg: Color, fg: Color = Theme.text) {
        val w = textWidth(AssetManager.fontSmall, text) + 16f
        val h = 22f
        fillRect(b, x, y, w, h, bg)
        outlineRect(b, x, y, w, h, 1f, Color(fg.r, fg.g, fg.b, 0.55f))
        centered(b, AssetManager.fontSmall, text, x + w / 2f, y + h / 2f, fg)
    }

    fun bar(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, ratio: Float, fill: Color) {
        fillRect(b, x, y, w, h, Theme.barBack)
        val clamped = ratio.coerceIn(0f, 1f)
        val fw = (w - 2f) * clamped
        if (fw > 0f) {
            fillRect(b, x + 1f, y + 1f, fw, h - 2f, fill)
            fillRect(b, x + 1f, y + h / 2f, fw, (h - 2f) / 2f, Color(1f, 1f, 1f, 0.18f))
        }
        outlineRect(b, x, y, w, h, 1f, Theme.border)
    }

    fun segmentedBar(b: SpriteBatch, x: Float, y: Float, w: Float, h: Float, ratio: Float, fill: Color, segments: Int = 10) {
        val gap = 3f
        val segW = (w - gap * (segments - 1)) / segments
        val litCount = MathUtils.round(ratio.coerceIn(0f, 1f) * segments)
        for (i in 0 until segments) {
            val sx = x + i * (segW + gap)
            val active = i < litCount
            fillRect(b, sx, y, segW, h, if (active) fill else Theme.barBack)
            if (active) {
                fillRect(b, sx, y + h * 0.55f, segW, h * 0.45f, Color(1f, 1f, 1f, 0.20f))
            }
            outlineRect(b, sx, y, segW, h, 1f, if (active) Color(fill.r, fill.g, fill.b, 0.8f) else Theme.border)
        }
    }

    fun line(b: SpriteBatch, x1: Float, y1: Float, x2: Float, y2: Float, t: Float, color: Color) {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        val ang = MathUtils.atan2(dy, dx) * MathUtils.radiansToDegrees
        b.color = color
        b.draw(AssetManager.getRegion("pixel"), x1, y1 - t / 2f, 0f, t / 2f, len, t, 1f, 1f, ang)
        b.color = Color.WHITE
    }

    fun hit(px: Float, py: Float, x: Float, y: Float, w: Float, h: Float): Boolean =
        px >= x && px <= x + w && py >= y && py <= y + h

    fun iconScale(spec: TankSpec, targetWidth: Float): Float {
        val total = spec.design.hullLenPx + spec.design.overhangPx
        return targetWidth / max(1, total)
    }

    fun tankIcon(
        b: SpriteBatch,
        spec: TankSpec,
        cx: Float,
        cy: Float,
        scale: Float,
        hullRot: Float = 0f,
        turretRot: Float = 0f,
        tint: Color = Color.WHITE,
        lit: Boolean = false
    ) {
        val id = spec.id
        val hull = AssetManager.getRegion("hull_$id")
        val turret = AssetManager.getRegion("turret_$id")
        val hw = hull.regionWidth.toFloat()
        val hh = hull.regionHeight.toFloat()
        val tw = turret.regionWidth.toFloat()
        val th = turret.regionHeight.toFloat()
        val pivot = AssetManager.pivotX(id)
        val d = spec.design

        val centerX = cx - d.overhangPx * scale / 2f
        val cos = MathUtils.cosDeg(hullRot)
        val sin = MathUtils.sinDeg(hullRot)
        val ox = centerX
        val tx = ox + cos * d.turretOffsetPx * scale
        val ty = cy + sin * d.turretOffsetPx * scale

        if (tint.a > 0.7f) {
            b.setColor(0f, 0f, 0f, 0.35f)
            b.draw(hull, ox - hw / 2f + 6f, cy - hh / 2f - 8f, hw / 2f, hh / 2f, hw, hh, scale, scale, hullRot)
            b.draw(turret, tx - pivot + 6f, ty - th / 2f - 8f, pivot, th / 2f, tw, th, scale, scale, hullRot + turretRot)
        }

        b.color = tint
        if (lit && Shaders.beginLit(b)) {
            Shaders.drawLit(b, hull, ox - hw / 2f, cy - hh / 2f, hw / 2f, hh / 2f, hw, hh, scale, scale, hullRot)
            Shaders.drawLit(b, turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, scale, scale, hullRot + turretRot)
            Shaders.endLit(b)
        } else {
            b.draw(hull, ox - hw / 2f, cy - hh / 2f, hw / 2f, hh / 2f, hw, hh, scale, scale, hullRot)
            b.draw(turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, scale, scale, hullRot + turretRot)
        }
        b.color = Color.WHITE
    }

    fun currencyBar(b: SpriteBatch, rightX: Float, y: Float) {
        val w = GameManager.wallet
        val p = GameManager.playerProfile
        val f = AssetManager.fontSmall
        var x = rightX
        val items = listOf(
            Triple("WAR BONDS", w.warBonds.toString(), Theme.warBonds),
            Triple("FREE XP", p.freeXp.toString(), Theme.xpColor),
            Triple("GOLD", w.gold.toString(), Theme.goldCoin),
            Triple("CREDITS", formatNumber(w.credits), Theme.credits)
        )
        for (item in items) {
            val labelText = item.first + ": " + item.second
            val tw = textWidth(f, labelText)
            val boxW = tw + 26f
            fillRect(b, x - boxW, y - 6f, boxW, 34f, Theme.panelLight)
            fillRect(b, x - boxW, y - 6f, 4f, 34f, item.third)
            outlineRect(b, x - boxW, y - 6f, boxW, 34f, 1f, Theme.border)
            rightText(b, f, labelText, x - 10f, y + 17f, item.third)
            x -= boxW + 10f
        }
    }

    fun formatNumber(n: Int): String = String.format("%,d", n)

    fun romanTier(tier: Int): String = when (tier) {
        1 -> "I"
        2 -> "II"
        3 -> "III"
        4 -> "IV"
        5 -> "V"
        6 -> "VI"
        else -> tier.toString()
    }
}
