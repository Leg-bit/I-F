package com.ironfront.core

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.graphics.glutils.ShaderProgram

/**
 * GLSL shaders. If a shader fails to compile on a device the game keeps working without it
 * (the matching property stays null and the plain drawing path is used).
 *
 *  - fog:  one full-screen quad that draws the spotlight vision cone, dynamic light from gun flashes
 *          and explosions, a warm/cold map tint, a vignette and soft ground variation.
 *  - tank: bump-lit tank sprites. Plates, hatches and edges are lit from a fixed sun direction.
 */
object Shaders {
    var fog: ShaderProgram? = null
        private set
    var tank: ShaderProgram? = null
        private set

    /** Same fog / spotlight as the 2D version, but for the tilted 3D camera: it works out where each pixel hits the ground. */
    var fog3d: ShaderProgram? = null
        private set

    private const val DEG2RAD = 0.017453292f

    private const val FOG_VERT = """
attribute vec4 a_position;
attribute vec2 a_texCoord0;
uniform mat4 u_projTrans;
uniform vec2 u_origin;
varying vec2 v_rel;
varying vec2 v_world;
varying vec2 v_screen;
void main() {
    v_rel = a_position.xy - u_origin;
    v_world = a_position.xy * 0.004;
    v_screen = a_texCoord0;
    gl_Position = u_projTrans * a_position;
}
"""

    private const val FOG_FRAG = """
#ifdef GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif
varying vec2 v_rel;
varying vec2 v_world;
varying vec2 v_screen;
uniform sampler2D u_rays;
uniform float u_dir;
uniform float u_half;
uniform float u_cone;
uniform float u_circle;
uniform float u_maxR;
uniform float u_fogOn;
uniform vec3 u_allies[6];
uniform vec4 u_lights[6];
uniform vec3 u_tint;
uniform float u_tintAmt;

const float PI = 3.14159265;

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.x, p.y, p.x) * 0.1031);
    p3 += dot(p3, vec3(p3.y, p3.z, p3.x) + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
    float d = length(v_rel);
    float lit = 1.0;
    float warm = 0.0;

    for (int i = 0; i < 6; i++) {
        vec4 l = u_lights[i];
        float ld = length(v_rel - l.xy);
        float fall = clamp(1.0 - ld / max(l.z, 1.0), 0.0, 1.0);
        warm = max(warm, l.w * fall * fall);
    }

    if (u_fogOn > 0.5) {
        float ang = atan(v_rel.y, v_rel.x);
        float u = fract(ang / (2.0 * PI));
        vec4 rayInfo = texture2D(u_rays, vec2(u, 0.5));
        float rd = rayInfo.r * u_maxR;
        float coneR = u_cone * rayInfo.g;
        float vis = clamp((rd + 30.0 - d) / 30.0, 0.0, 1.0);
        float circleLit = clamp((u_circle + 40.0 - d) / 40.0, 0.0, 1.0);
        float da = abs(mod(ang - u_dir + PI, 2.0 * PI) - PI);
        float angFade = clamp((u_half + 0.08 - da) / 0.08, 0.0, 1.0);
        float distFade = clamp((coneR - d) / 90.0, 0.0, 1.0);
        lit = max(circleLit, angFade * distFade) * vis;
        for (int i = 0; i < 6; i++) {
            vec3 a = u_allies[i];
            float ad = length(v_rel - a.xy);
            lit = max(lit, a.z * clamp((190.0 - ad) / 40.0, 0.0, 1.0));
        }
        lit = max(lit, clamp(warm * 1.6, 0.0, 0.9));
    }

    float aFog = (1.0 - lit) * 0.74 * u_fogOn;
    // thin blue rim along the edge of the light, like the beam outlines of a spotlight
    float rim = smoothstep(0.30, 0.50, lit) * (1.0 - smoothstep(0.50, 0.70, lit)) * u_fogOn;
    vec2 sc = (v_screen - 0.5) * vec2(1.25, 1.0);
    float vig = smoothstep(0.30, 0.95, length(sc)) * 0.45;
    float aDark = 1.0 - (1.0 - aFog) * (1.0 - vig);
    vec3 darkCol = vec3(0.02, 0.03, 0.05);

    float mv = (noise(v_world * 3.0) - 0.5) * 0.10;
    float white = mv > 0.0 ? 1.0 : 0.0;
    vec3 warmCol = vec3(1.0, 0.72, 0.35);
    float rimA = 0.0;
    vec3 rimCol = vec3(0.25, 0.60, 1.0);
    float a2 = u_tintAmt + abs(mv) + warm * 0.28 + rimA;
    vec3 c2n = u_tint * u_tintAmt + vec3(white) * abs(mv) + warmCol * warm * 0.28 + rimCol * rimA;
    vec3 c2 = c2n / max(a2, 0.0001);

    float aOut = aDark + a2 * (1.0 - aDark);
    vec3 cOut = (darkCol * aDark + c2 * a2 * (1.0 - aDark)) / max(aOut, 0.0001);
    gl_FragColor = vec4(cOut, aOut);
}
"""

    private const val FOG3D_VERT = """
attribute vec4 a_position;
attribute vec2 a_texCoord0;
uniform mat4 u_projTrans;
uniform vec3 u_forward;
uniform vec3 u_right;
uniform vec3 u_up;
varying vec3 v_dir;
varying vec2 v_screen;
void main() {
    vec2 ndc = vec2(a_position.x / 1280.0 * 2.0 - 1.0, a_position.y / 720.0 * 2.0 - 1.0);
    v_dir = u_forward + u_right * ndc.x + u_up * ndc.y;
    v_screen = a_texCoord0;
    gl_Position = u_projTrans * a_position;
}
"""

    // the 3D fragment shader is the 2D one with the ground position computed from the camera ray
    private val FOG3D_FRAG: String = FOG_FRAG
        .replace(
            "varying vec2 v_rel;\nvarying vec2 v_world;\nvarying vec2 v_screen;",
            "varying vec3 v_dir;\nvarying vec2 v_screen;\nuniform vec3 u_camRel;\nuniform vec2 u_originW;"
        )
        .replace(
            "void main() {\n    float d = length(v_rel);",
            "void main() {\n    float tt = u_camRel.y / max(-v_dir.y, 0.02);\n    vec2 v_rel = vec2(u_camRel.x + v_dir.x * tt, u_camRel.z - v_dir.z * tt);\n    vec2 v_world = (v_rel + u_originW) * 0.004;\n    float skyMask = step(-0.02, v_dir.y);\n    float d = length(v_rel);"
        )
        .replace(
            "float aFog = (1.0 - lit) * 0.74 * u_fogOn;",
            "float aFog = (1.0 - max(lit, skyMask)) * 0.74 * u_fogOn;"
        )

    fun fog3dVertexSource(): String = FOG3D_VERT
    fun fog3dFragmentSource(): String = FOG3D_FRAG

    private const val TANK_VERT = """
attribute vec4 a_position;
attribute vec4 a_color;
attribute vec2 a_texCoord0;
uniform mat4 u_projTrans;
varying vec4 v_color;
varying vec2 v_texCoords;
void main() {
    v_color = a_color;
    v_texCoords = a_texCoord0;
    gl_Position = u_projTrans * a_position;
}
"""

    private const val TANK_FRAG = """
#ifdef GL_ES
precision mediump float;
#endif
varying vec4 v_color;
varying vec2 v_texCoords;
uniform sampler2D u_texture;
uniform vec2 u_texel;
uniform vec2 u_light;

float height(vec2 uv) {
    vec4 c = texture2D(u_texture, uv);
    return (dot(c.rgb, vec3(0.30, 0.59, 0.11)) * 0.7 + 0.3) * c.a;
}

void main() {
    vec4 c = texture2D(u_texture, v_texCoords);
    float hx = height(v_texCoords + vec2(u_texel.x, 0.0)) - height(v_texCoords - vec2(u_texel.x, 0.0));
    float hy = height(v_texCoords + vec2(0.0, u_texel.y)) - height(v_texCoords - vec2(0.0, u_texel.y));
    float slope = hx * u_light.x + hy * u_light.y;
    float shade = clamp(1.0 - slope * 1.6, 0.5, 1.5);
    float spec = max(0.0, -slope - 0.45) * 0.6;
    vec3 rgb = c.rgb * shade + vec3(spec) * c.a;
    gl_FragColor = vec4(rgb, c.a) * v_color;
}
"""

    fun init() {
        ShaderProgram.pedantic = false
        fog = compile("fog", FOG_VERT, FOG_FRAG)
        tank = compile("tank", TANK_VERT, TANK_FRAG)
        fog3d = compile("fog3d", FOG3D_VERT, FOG3D_FRAG)
    }

    private fun compile(name: String, vert: String, frag: String): ShaderProgram? {
        return try {
            val sp = ShaderProgram(vert, frag)
            if (!sp.isCompiled) {
                Gdx.app.log("IronFront", "Shader $name failed: " + sp.log)
                sp.dispose()
                null
            } else {
                sp
            }
        } catch (e: Exception) {
            Gdx.app.log("IronFront", "Shader $name error: " + e.message)
            null
        }
    }

    /** Switches the batch to the bump-lit tank shader. Returns false when it is not available. */
    fun beginLit(batch: SpriteBatch): Boolean {
        val s = tank ?: return false
        batch.shader = s
        return true
    }

    fun endLit(batch: SpriteBatch) {
        batch.flush()
        batch.shader = null
    }

    /** Draws one sprite with the sun direction rotated to match the sprite's own rotation. */
    fun drawLit(
        batch: SpriteBatch, region: TextureRegion,
        x: Float, y: Float, ox: Float, oy: Float, w: Float, h: Float, sx: Float, sy: Float, rotDeg: Float
    ) {
        val s = tank
        if (s != null) {
            batch.flush()
            val r = rotDeg * DEG2RAD
            val c = kotlin.math.cos(r)
            val sn = kotlin.math.sin(r)
            val wx = -0.55f
            val wy = 0.83f
            val lx = wx * c + wy * sn
            val lyUp = -wx * sn + wy * c
            s.setUniformf("u_light", lx, -lyUp)
            s.setUniformf("u_texel", 1f / region.texture.width, 1f / region.texture.height)
        }
        batch.draw(region, x, y, ox, oy, w, h, sx, sy, rotDeg)
    }

    fun dispose() {
        fog?.dispose()
        tank?.dispose()
        fog3d?.dispose()
        fog = null
        tank = null
        fog3d = null
    }
}
