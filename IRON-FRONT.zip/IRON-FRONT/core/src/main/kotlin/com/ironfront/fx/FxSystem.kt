package com.ironfront.fx

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager

class Particle(
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    var life: Float,
    val maxLife: Float,
    val sizeStart: Float,
    val sizeEnd: Float,
    val r: Float,
    val g: Float,
    val b: Float,
    val alpha: Float,
    val additive: Boolean = false
)

/** Tread print left on the ground by a moving tank. */
class TrackMark(val x: Float, val y: Float, val angle: Float, var life: Float)

/** Particle system: glowing sparks and flashes (additive), smoke and dust, tread marks on the ground. */
class FxSystem {
    private val particles = ArrayList<Particle>()
    private val marks = ArrayList<TrackMark>()

    private fun add(p: Particle) {
        if (particles.size < MAX_PARTICLES) particles.add(p)
    }

    fun sparks(x: Float, y: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            val a = MathUtils.random(0f, 360f)
            val s = MathUtils.random(60f, 240f)
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.35f, 0.35f, 6f, 1f, color.r, color.g, color.b, 1f, true))
        }
    }

    fun explosion(x: Float, y: Float, scale: Float) {
        add(Particle(x, y, 0f, 0f, 0.45f, 0.45f, 36f * scale, 110f * scale, 1f, 0.70f, 0.22f, 0.95f, true))
        add(Particle(x, y, 0f, 0f, 0.30f, 0.30f, 24f * scale, 64f * scale, 1f, 1f, 0.85f, 1f, true))
        for (i in 0 until (8 * scale).toInt() + 3) {
            val a = MathUtils.random(0f, 360f)
            val s = MathUtils.random(40f, 160f) * scale
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.8f, 0.8f, 14f * scale, 38f * scale, 0.22f, 0.20f, 0.18f, 0.6f))
        }
        for (i in 0 until (5 * scale).toInt() + 2) {
            val a = MathUtils.random(0f, 360f)
            val s = MathUtils.random(80f, 260f) * scale
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.5f, 0.5f, 7f, 1f, 1f, 0.6f, 0.2f, 1f, true))
        }
    }

    fun smoke(x: Float, y: Float) {
        add(Particle(x + MathUtils.random(-8f, 8f), y + MathUtils.random(-8f, 8f), MathUtils.random(-6f, 6f), MathUtils.random(12f, 26f), 1.8f, 1.8f, 14f, 42f, 0.15f, 0.15f, 0.15f, 0.55f))
    }

    /** Light exhaust puff from a moving engine. */
    fun exhaust(x: Float, y: Float, angleDeg: Float, strength: Float) {
        val a = angleDeg + 180f + MathUtils.random(-25f, 25f)
        val s = MathUtils.random(15f, 35f)
        add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.9f, 0.9f, 5f, 12f + 8f * strength, 0.30f, 0.30f, 0.30f, 0.28f))
    }

    fun muzzleFlash(x: Float, y: Float, angleDeg: Float) {
        add(Particle(x, y, MathUtils.cosDeg(angleDeg) * 40f, MathUtils.sinDeg(angleDeg) * 40f, 0.14f, 0.14f, 34f, 10f, 1f, 0.88f, 0.5f, 1f, true))
        add(Particle(x, y, 0f, 0f, 0.10f, 0.10f, 60f, 20f, 1f, 0.7f, 0.3f, 0.7f, true))
        for (i in 0 until 4) {
            val a = angleDeg + MathUtils.random(-25f, 25f)
            val s = MathUtils.random(90f, 200f)
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.5f, 0.5f, 8f, 18f, 0.55f, 0.55f, 0.55f, 0.5f))
        }
    }

    /** Dust kicked up by the blast of a gun, thrown sideways from the barrel. */
    fun dust(x: Float, y: Float, angleDeg: Float, strength: Float) {
        for (i in 0 until 5) {
            val a = angleDeg + (if (i % 2 == 0) 90f else -90f) + MathUtils.random(-35f, 35f)
            val s = MathUtils.random(25f, 70f) * strength
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.9f, 0.9f, 10f, 34f * strength, 0.55f, 0.48f, 0.38f, 0.45f))
        }
    }

    /** Chunks flying out of a broken wall or tree. */
    fun debris(x: Float, y: Float, r: Float, g: Float, b: Float) {
        for (i in 0 until 9) {
            val a = MathUtils.random(0f, 360f)
            val s = MathUtils.random(50f, 190f)
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.6f, 0.6f, 9f, 3f, r, g, b, 1f))
        }
        add(Particle(x, y, 0f, 0f, 0.8f, 0.8f, 20f, 60f, 0.5f, 0.45f, 0.4f, 0.5f))
    }

    fun trackMark(x: Float, y: Float, angleDeg: Float) {
        if (marks.size >= MAX_MARKS) marks.removeAt(0)
        marks.add(TrackMark(x, y, angleDeg, 9f))
    }

    fun update(delta: Float) {
        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= delta
            if (p.life <= 0f) {
                it.remove()
                continue
            }
            p.x += p.vx * delta
            p.y += p.vy * delta
        }
        val mi = marks.iterator()
        while (mi.hasNext()) {
            val m = mi.next()
            m.life -= delta
            if (m.life <= 0f) mi.remove()
        }
    }

    /** Tread marks lie on the ground, under the tanks. */
    fun renderGround(batch: SpriteBatch) {
        val px = AssetManager.getRegion("pixel")
        for (m in marks) {
            val a = (m.life / 9f).coerceIn(0f, 1f) * 0.32f
            batch.setColor(0.06f, 0.05f, 0.04f, a)
            batch.draw(px, m.x - 5f, m.y - 3f, 5f, 3f, 10f, 6f, 1f, 1f, m.angle)
        }
        batch.setColor(1f, 1f, 1f, 1f)
    }

    fun render(batch: SpriteBatch) {
        val glow = AssetManager.getRegion("glow")
        for (p in particles) {
            if (p.additive) continue
            val t = (p.life / p.maxLife).coerceIn(0f, 1f)
            val size = p.sizeEnd + (p.sizeStart - p.sizeEnd) * t
            batch.setColor(p.r, p.g, p.b, p.alpha * t)
            batch.draw(glow, p.x - size / 2f, p.y - size / 2f, size, size)
        }
        // bright effects add up to the picture, so flashes really glow
        batch.setBlendFunction(GL20.GL_SRC_ALPHA, GL20.GL_ONE)
        for (p in particles) {
            if (!p.additive) continue
            val t = (p.life / p.maxLife).coerceIn(0f, 1f)
            val size = p.sizeEnd + (p.sizeStart - p.sizeEnd) * t
            batch.setColor(p.r, p.g, p.b, p.alpha * t)
            batch.draw(glow, p.x - size / 2f, p.y - size / 2f, size, size)
        }
        batch.setBlendFunction(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        batch.setColor(1f, 1f, 1f, 1f)
    }

    companion object {
        private const val MAX_PARTICLES = 500
        private const val MAX_MARKS = 420
    }
}
