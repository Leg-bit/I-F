package com.ironfront.fx

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager

class Particle(
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    var life: Float,
    val maxLife: Float,
    val sizeStart: Float,
    val sizeEnd: Float,
    val r: Float,
    val g: Float,
    val b: Float,
    val alpha: Float
)

/** Small particle system: sparks, explosions, smoke and muzzle flashes. */
class FxSystem {
    private val particles = ArrayList<Particle>()

    private fun add(p: Particle) {
        if (particles.size < MAX_PARTICLES) particles.add(p)
    }

    fun sparks(x: Float, y: Float, color: Color, count: Int) {
        for (i in 0 until count) {
            val a = MathUtils.random(0f, 360f)
            val s = MathUtils.random(60f, 220f)
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.35f, 0.35f, 5f, 1f, color.r, color.g, color.b, 1f))
        }
    }

    fun explosion(x: Float, y: Float, scale: Float) {
        add(Particle(x, y, 0f, 0f, 0.45f, 0.45f, 30f * scale, 90f * scale, 1f, 0.75f, 0.25f, 0.9f))
        add(Particle(x, y, 0f, 0f, 0.30f, 0.30f, 20f * scale, 55f * scale, 1f, 1f, 0.8f, 1f))
        for (i in 0 until (8 * scale).toInt() + 3) {
            val a = MathUtils.random(0f, 360f)
            val s = MathUtils.random(40f, 160f) * scale
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.7f, 0.7f, 14f * scale, 34f * scale, 0.25f, 0.22f, 0.20f, 0.6f))
        }
    }

    fun smoke(x: Float, y: Float) {
        add(Particle(x + MathUtils.random(-8f, 8f), y + MathUtils.random(-8f, 8f), MathUtils.random(-6f, 6f), MathUtils.random(12f, 26f), 1.8f, 1.8f, 14f, 40f, 0.15f, 0.15f, 0.15f, 0.55f))
    }

    fun muzzleFlash(x: Float, y: Float, angleDeg: Float) {
        add(Particle(x, y, MathUtils.cosDeg(angleDeg) * 40f, MathUtils.sinDeg(angleDeg) * 40f, 0.14f, 0.14f, 26f, 8f, 1f, 0.9f, 0.5f, 1f))
        for (i in 0 until 4) {
            val a = angleDeg + MathUtils.random(-25f, 25f)
            val s = MathUtils.random(90f, 200f)
            add(Particle(x, y, MathUtils.cosDeg(a) * s, MathUtils.sinDeg(a) * s, 0.5f, 0.5f, 8f, 18f, 0.55f, 0.55f, 0.55f, 0.5f))
        }
    }

    fun update(delta: Float) {
        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= delta
            if (p.life <= 0f) {
                it.remove()
                continue
            }
            p.x += p.vx * delta
            p.y += p.vy * delta
        }
    }

    fun render(batch: SpriteBatch) {
        val glow = AssetManager.getRegion("glow")
        for (p in particles) {
            val t = (p.life / p.maxLife).coerceIn(0f, 1f)
            val size = p.sizeEnd + (p.sizeStart - p.sizeEnd) * t
            batch.setColor(p.r, p.g, p.b, p.alpha * t)
            batch.draw(glow, p.x - size / 2f, p.y - size / 2f, size, size)
        }
        batch.setColor(1f, 1f, 1f, 1f)
    }

    companion object {
        private const val MAX_PARTICLES = 500
    }
}
