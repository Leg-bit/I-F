package com.ironfront.ui

import com.badlogic.gdx.graphics.Color

object Theme {
    val bg = Color(0.06f, 0.08f, 0.07f, 1f)
    val header = Color(0.11f, 0.15f, 0.12f, 1f)
    val panel = Color(0.10f, 0.13f, 0.12f, 1f)
    val panelLight = Color(0.15f, 0.19f, 0.17f, 1f)
    val border = Color(0.30f, 0.37f, 0.32f, 1f)
    val gold = Color(1.00f, 0.82f, 0.25f, 1f)
    val green = Color(0.30f, 0.75f, 0.35f, 1f)
    val darkGreen = Color(0.16f, 0.40f, 0.22f, 1f)
    val red = Color(0.85f, 0.25f, 0.20f, 1f)
    val darkRed = Color(0.45f, 0.17f, 0.16f, 1f)
    val blue = Color(0.25f, 0.50f, 0.90f, 1f)
    val orange = Color(0.90f, 0.50f, 0.15f, 1f)
    val grey = Color(0.45f, 0.48f, 0.48f, 1f)
    val dark = Color(0.04f, 0.05f, 0.05f, 1f)
    val text = Color(0.92f, 0.94f, 0.92f, 1f)
    val textDim = Color(0.62f, 0.68f, 0.65f, 1f)
    val barBack = Color(0.04f, 0.05f, 0.05f, 1f)
    val credits = Color(0.85f, 0.88f, 0.92f, 1f)
    val goldCoin = Color(1.00f, 0.78f, 0.20f, 1f)
    val xpColor = Color(0.55f, 0.85f, 1.00f, 1f)
}
