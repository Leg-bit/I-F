package com.ironfront.ui

import com.badlogic.gdx.graphics.Color

object Theme {
    val bg = Color(0.05f, 0.06f, 0.08f, 1f)
    val bgTop = Color(0.08f, 0.11f, 0.14f, 1f)
    val header = Color(0.07f, 0.09f, 0.12f, 0.96f)
    val panel = Color(0.10f, 0.13f, 0.17f, 0.94f)
    val panelLight = Color(0.14f, 0.18f, 0.23f, 0.96f)
    val panelGlass = Color(0.06f, 0.08f, 0.11f, 0.78f)
    val border = Color(0.24f, 0.30f, 0.38f, 1f)
    val borderBright = Color(0.42f, 0.50f, 0.60f, 1f)

    // Accents
    val gold = Color(1.00f, 0.78f, 0.22f, 1f)
    val goldDark = Color(0.58f, 0.41f, 0.08f, 1f)
    val amber = Color(0.95f, 0.55f, 0.15f, 1f)
    val primary = Color(0.86f, 0.30f, 0.16f, 1f)
    val primaryDark = Color(0.55f, 0.17f, 0.09f, 1f)

    val green = Color(0.22f, 0.80f, 0.45f, 1f)
    val darkGreen = Color(0.12f, 0.38f, 0.24f, 1f)
    val red = Color(0.90f, 0.26f, 0.24f, 1f)
    val darkRed = Color(0.45f, 0.15f, 0.16f, 1f)
    val blue = Color(0.26f, 0.58f, 0.96f, 1f)
    val cyan = Color(0.25f, 0.85f, 0.95f, 1f)
    val orange = Color(0.94f, 0.54f, 0.18f, 1f)
    val grey = Color(0.42f, 0.47f, 0.54f, 1f)
    val dark = Color(0.05f, 0.06f, 0.08f, 1f)

    // Typography
    val text = Color(0.95f, 0.96f, 0.98f, 1f)
    val textDim = Color(0.60f, 0.66f, 0.74f, 1f)
    val barBack = Color(0.04f, 0.05f, 0.07f, 1f)

    // Currencies
    val credits = Color(0.88f, 0.92f, 0.98f, 1f)
    val goldCoin = Color(1.00f, 0.80f, 0.24f, 1f)
    val xpColor = Color(0.35f, 0.82f, 1.00f, 1f)
    val warBonds = Color(0.85f, 0.45f, 1.00f, 1f)
}
