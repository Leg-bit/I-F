package com.ironfront.tanks

import com.ironfront.armor.ArmorScheme
import com.ironfront.core.GameConfig
import com.ironfront.weapons.GunSpec

/** One real tank: dimensions, armor, gun, performance and its place in the tech tree. */
data class TankSpec(
    val id: String,
    val shortName: String,
    val name: String,
    val nation: Nation,
    val tier: Int,
    val tankClass: TankClass,
    val year: Int,
    val massT: Float,
    val hullLengthM: Float,
    val hullWidthM: Float,
    val hullHeightM: Float,
    val crew: Int,
    val enginePowerHp: Int,
    val maxSpeedKmh: Float,
    val armor: ArmorScheme,
    val gun: GunSpec,
    val turretDiameterM: Float,
    val turretTraverseDegS: Float,
    val hasTurret: Boolean = true,
    val traverseLimitDeg: Float = 360f,
    val parents: List<String> = emptyList(),
    val treeRow: Int = 1,
    val researchCostXp: Int = 0,
    val purchaseCostCredits: Int = 0
) {
    /** Hit points scale with mass (a heavier tank survives more hits). */
    val maxHp: Float get() = 150f + massT * 18f

    /** px/s, from real road speed and a cross-country factor. */
    val moveSpeed: Float get() = maxSpeedKmh / 3.6f * GameConfig.PX_PER_M * GameConfig.TERRAIN_SPEED_FACTOR

    /** Better power-to-weight turns faster. */
    val hullTurnSpeedDeg: Float get() = (25f + 2.2f * enginePowerHp / massT).coerceIn(30f, 80f)

    val turretTurnSpeedDeg: Float get() = turretTraverseDegS * GameConfig.ARCADE_TRAVERSE

    val limitedTraverse: Boolean get() = traverseLimitDeg < 180f
}
