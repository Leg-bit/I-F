package com.ironfront.tanks

import com.ironfront.armor.ArmorProfile
import com.ironfront.nations.Nation
import com.ironfront.weapons.GunSpec

enum class TankClass(val label: String) {
    LIGHT("Light"),
    MEDIUM("Medium"),
    HEAVY("Heavy"),
    TANK_DESTROYER("Tank Destroyer")
}

data class TankSpec(
    val id: String,
    val name: String,
    val shortName: String,
    val nation: Nation,
    val tier: Int,
    val tankClass: TankClass,
    val weightTons: Float,
    val crew: Int,
    val enginePowerHp: Int,
    val maxSpeedKmh: Float,
    val maxHp: Float,
    val moveSpeed: Float,
    val hullTurnSpeedDeg: Float,
    val turretTurnSpeedDeg: Float,
    val armor: ArmorProfile,
    val gun: GunSpec,
    val design: TankDesign,
    val parents: List<String>,
    val researchCostXp: Int,
    val purchaseCostCredits: Int,
    val description: String,
    val casemateArcDeg: Float = 0f
) {
    val powerToWeight: Float get() = enginePowerHp / weightTons

    /** Acceleration in pixels per second squared. */
    val accel: Float get() = (powerToWeight * 7f).coerceIn(30f, 200f)

    val isCasemate: Boolean get() = casemateArcDeg > 0f

    /** How far the vision cone reaches (pixels). Lighter tanks see further. */
    val viewRangePx: Float
        get() = when (tankClass) {
            TankClass.LIGHT -> 800f
            TankClass.MEDIUM -> 730f
            TankClass.HEAVY -> 670f
            TankClass.TANK_DESTROYER -> 760f
        }

    /** Radius of the all-round awareness circle around the hull. */
    val awarenessPx: Float get() = if (tankClass == TankClass.LIGHT) 210f else 175f
}
