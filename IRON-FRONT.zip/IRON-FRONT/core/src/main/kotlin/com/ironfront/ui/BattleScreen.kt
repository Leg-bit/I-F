package com.ironfront.ui

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.ScreenAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.FitViewport
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.battlefield.BattlefieldWorld
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.input.TouchControls
import com.ironfront.maps.BattleSetup
import com.ironfront.save.SaveManager
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankEntity
import com.ironfront.teams.Team

class BattleScreen(
    private val game: IronFront,
    private val setup: BattleSetup
) : ScreenAdapter() {
    private val worldCamera = OrthographicCamera()
    private val worldViewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, worldCamera)

    private val hudCamera = OrthographicCamera()
    private val hudViewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, hudCamera)

    private val playerTank = TankEntity(
        id = "player",
        spec = TankDatabase.get(GameManager.selectedTankId),
        x = setup.map.playerSpawnX,
        y = setup.map.playerSpawnY,
        playerControlled = true,
        team = Team.FRIEND
    )
    private val world = BattlefieldWorld(playerTank, setup)
    private val controls = TouchControls(hudViewport)
    private val touch = Vector3()
    private val exitColor = Color(0.45f, 0.18f, 0.18f, 0.85f)

    private var battleEnded = false
    private var victory = false
    private var endTimer = 3f

    override fun render(delta: Float) {
        val dt = delta.coerceAtMost(GameConfig.MAX_DT)

        if (Gdx.input.justTouched()) {
            touch.set(Gdx.input.x.toFloat(), Gdx.input.y.toFloat(), 0f)
            hudViewport.unproject(touch)
            if (UiDraw.hit(touch.x, touch.y, EXIT_X, EXIT_Y, EXIT_W, EXIT_H)) {
                ScreenManager.setScreen(MainMenuScreen(game))
                return
            }
        }

        if (!battleEnded) {
            controls.update(playerTank)
            if (controls.switchAmmoRequested) {
                playerTank.weapon.cycleAmmo()
            }
            if (controls.fireRequested) {
                val shell = playerTank.fire()
                if (shell != null) {
                    world.projectiles.add(shell)
                    AudioManager.playCannonFire()
                }
            }

            world.update(dt)

            if (!playerTank.isAlive || world.enemiesAlive() == 0) {
                battleEnded = true
                victory = playerTank.isAlive
                if (victory) {
                    GameManager.wallet.addCredits(setup.rewardCredits)
                    GameManager.playerProfile.recordBattleResult(world.enemiesDestroyed, setup.rewardXp)
                } else {
                    GameManager.playerProfile.recordBattleResult(world.enemiesDestroyed, 50)
                }
                SaveManager.save()
            }
        } else {
            endTimer -= dt
            if (endTimer <= 0f) {
                ScreenManager.setScreen(MainMenuScreen(game))
                return
            }
        }

        worldCamera.position.x = MathUtils.clamp(
            playerTank.position.x,
            GameConfig.VIRTUAL_WIDTH / 2f,
            GameConfig.MAP_WIDTH - GameConfig.VIRTUAL_WIDTH / 2f
        )
        worldCamera.position.y = MathUtils.clamp(
            playerTank.position.y,
            GameConfig.VIRTUAL_HEIGHT / 2f,
            GameConfig.MAP_HEIGHT - GameConfig.VIRTUAL_HEIGHT / 2f
        )
        worldCamera.update()

        Gdx.gl.glClearColor(0.08f, 0.08f, 0.08f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)

        worldViewport.apply()
        game.batch.projectionMatrix = worldCamera.combined
        game.batch.begin()
        world.render(game.batch, worldCamera.position.x, worldCamera.position.y)
        game.batch.end()

        hudViewport.apply()
        game.batch.projectionMatrix = hudCamera.combined
        game.batch.begin()
        controls.render(game.batch)

        AssetManager.font.color = Color.WHITE
        AssetManager.font.draw(
            game.batch,
            "HP: ${playerTank.currentHp.toInt()}/${playerTank.spec.maxHp.toInt()}  |  ${playerTank.weapon.currentAmmo.kind.code} x${playerTank.weapon.currentRounds}  |  RELOAD: ${(playerTank.weapon.reloadProgress * 100).toInt()}%",
            30f,
            690f
        )
        UiDraw.coloredText(
            game.batch,
            "ENEMIES (RED): ${world.enemiesAlive()}/${world.totalEnemies}",
            760f,
            690f,
            Team.ENEMY.outline
        )
        UiDraw.coloredText(
            game.batch,
            "ALLIES (BLUE): ${world.friendsAlive()}/${world.totalFriends}",
            760f,
            660f,
            Team.FRIEND.outline
        )
        UiDraw.button(game.batch, EXIT_X, EXIT_Y, EXIT_W, EXIT_H, exitColor, "EXIT")

        if (battleEnded) {
            val resultText = if (victory) "VICTORY! +${setup.rewardCredits} CR" else "TANK DESTROYED!"
            AssetManager.font.draw(game.batch, resultText, 520f, 380f)
        }
        game.batch.end()
    }

    override fun resize(width: Int, height: Int) {
        worldViewport.update(width, height, false)
        hudViewport.update(width, height, true)
    }

    companion object {
        private const val EXIT_X = 1100f
        private const val EXIT_Y = 640f
        private const val EXIT_W = 150f
        private const val EXIT_H = 65f
    }
}
