package com.ironfront.ui

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.ScreenAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.FitViewport
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.battlefield.BattlefieldWorld
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.input.TouchControls
import com.ironfront.maps.BattleSetup
import com.ironfront.render3d.Scene3D
import com.ironfront.save.SaveManager
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankEntity
import com.ironfront.teams.Team

class BattleScreen(
    private val game: IronFront,
    private val setup: BattleSetup
) : ScreenAdapter() {
    private val worldCamera = OrthographicCamera()
    private val worldViewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, worldCamera)

    private val hudCamera = OrthographicCamera()
    private val hudViewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, hudCamera)

    private val playerTank = TankEntity(
        id = "player",
        spec = TankDatabase.get(GameManager.selectedTankId),
        x = setup.map.playerSpawnX,
        y = setup.map.playerSpawnY,
        playerControlled = true,
        team = Team.FRIEND
    )
    private val world: BattlefieldWorld
    private val controls = TouchControls(hudViewport)
    private val touch = Vector3()
    private val exitColor = Color(0.45f, 0.18f, 0.18f, 0.85f)

    private var battleEnded = false
    private var victory = false
    private var endTimer = 1.6f
    private var resultShown = false
    private var earnedCredits = 0
    private var earnedXp = 0
    private var earnedBonds = 0
    private var time = 0f
    private var wasReady = true
    private var camX = 0f
    private var camY = 0f
    private var camReady = false
    private var scene3D: Scene3D? = null

    init {
        for (e in GameManager.equippedEquipment) playerTank.loadout.equip(e)
        playerTank.rotation = 45f
        playerTank.turretRotation = 45f
        playerTank.desiredTurretRotation = 45f
        world = BattlefieldWorld(playerTank, setup)
        if (GameManager.view3d) {
            try {
                scene3D = Scene3D(world)
            } catch (e: Exception) {
                Gdx.app.log("IronFront", "3D view disabled: " + e.message)
                scene3D = null
            }
        }
        AudioManager.startEngine()
    }

    override fun render(delta: Float) {
        val dt = delta.coerceAtMost(GameConfig.MAX_DT)
        time += dt

        if (Gdx.input.justTouched()) {
            touch.set(Gdx.input.x.toFloat(), Gdx.input.y.toFloat(), 0f)
            hudViewport.unproject(touch)
            if (resultShown) {
                if (UiDraw.hit(touch.x, touch.y, 490f, 140f, 300f, 70f)) {
                    AudioManager.playClick()
                    AudioManager.stopEngine()
                    ScreenManager.setScreen(MainMenuScreen(game))
                    return
                }
            } else if (UiDraw.hit(touch.x, touch.y, EXIT_X, EXIT_Y, EXIT_W, EXIT_H)) {
                AudioManager.stopEngine()
                ScreenManager.setScreen(MainMenuScreen(game))
                return
            } else if (UiDraw.hit(touch.x, touch.y, EXIT_X, FOG_Y, EXIT_W, FOG_H)) {
                world.vision.enabled = !world.vision.enabled
                AudioManager.playClick()
            }
        }

        if (!battleEnded) {
            controls.cameraX = camX
            controls.cameraY = camY
            controls.update(playerTank, dt)
            if (controls.switchAmmoRequested) {
                playerTank.weapon.cycleAmmo()
            }
            val picked = controls.selectedAmmo
            if (picked != null) playerTank.weapon.selectAmmo(picked)
            if (controls.repairRequested) {
                playerTank.useRepairKit()
            }
            if (controls.fireRequested) {
                val shell = playerTank.fire()
                if (shell != null) {
                    world.fireShell(shell, playerTank)
                }
            }

            world.update(dt)

            val readyNow = playerTank.weapon.isReady
            if (readyNow && !wasReady) AudioManager.playReload()
            wasReady = readyNow
            AudioManager.updateEngine(playerTank.speedNow / maxOf(1f, playerTank.spec.moveSpeed))

            if (!playerTank.isAlive || world.enemiesAlive() == 0) {
                finishBattle()
            }
        } else {
            // the world keeps running for a moment so explosions play out
            world.update(dt)
            endTimer -= dt
            if (endTimer <= 0f) resultShown = true
        }

        // the camera glides after the tank and peeks a little in the direction the turret points
        val look = 70f
        val targetX = MathUtils.clamp(
            playerTank.position.x + MathUtils.cosDeg(playerTank.turretRotation) * look,
            GameConfig.VIRTUAL_WIDTH / 2f,
            GameConfig.MAP_WIDTH - GameConfig.VIRTUAL_WIDTH / 2f
        )
        val targetY = MathUtils.clamp(
            playerTank.position.y + MathUtils.sinDeg(playerTank.turretRotation) * look,
            GameConfig.VIRTUAL_HEIGHT / 2f,
            GameConfig.MAP_HEIGHT - GameConfig.VIRTUAL_HEIGHT / 2f
        )
        if (!camReady) {
            camX = targetX
            camY = targetY
            camReady = true
        }
        val follow = 1f - kotlin.math.exp(-6f * dt)
        camX += (targetX - camX) * follow
        camY += (targetY - camY) * follow
        worldCamera.position.x = camX
        worldCamera.position.y = camY
        if (world.shake > 0.2f) {
            worldCamera.position.x += MathUtils.random(-world.shake, world.shake)
            worldCamera.position.y += MathUtils.random(-world.shake, world.shake)
        }
        worldCamera.update()

        val scene = scene3D
        if (scene != null) {
            Gdx.gl.glClearColor(0.04f, 0.05f, 0.06f, 1f)
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)
            worldViewport.apply()
            scene.render(camX, camY, world.shake)
        } else {
            Gdx.gl.glClearColor(0.08f, 0.08f, 0.08f, 1f)
            Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)

            worldViewport.apply()
            game.batch.projectionMatrix = worldCamera.combined
            game.batch.begin()
            world.render(game.batch, worldCamera.position.x, worldCamera.position.y)
            game.batch.end()
        }

        hudViewport.apply()
        game.batch.projectionMatrix = hudCamera.combined
        game.batch.begin()
        if (scene != null) scene.drawOverlays(game.batch)
        if (!resultShown) {
            if (!battleEnded) controls.render(game.batch, playerTank)
            drawHud()
        } else {
            drawResult()
        }
        game.batch.end()
    }

    private fun finishBattle() {
        battleEnded = true
        victory = playerTank.isAlive
        val kills = world.playerKills
        if (victory) {
            earnedCredits = setup.rewardCredits
            earnedXp = setup.rewardXp
        } else {
            val perKillCredits = if (world.totalEnemies > 0) setup.rewardCredits / world.totalEnemies else 0
            val perKillXp = if (world.totalEnemies > 0) setup.rewardXp / world.totalEnemies else 0
            earnedCredits = (perKillCredits * kills * 0.6f).toInt()
            earnedXp = (perKillXp * kills * 0.6f).toInt() + 50
        }
        // Battle XP goes to the tank's Mastery XP (spent first when researching its successors);
        // a quarter also becomes Free XP, and all of it raises the commander level.
        val tankId = playerTank.spec.id
        GameManager.techTree.addTankXp(tankId, earnedXp)
        GameManager.playerProfile.recordBattleResult(kills, 0, victory)
        GameManager.playerProfile.addLevelXp(earnedXp)
        GameManager.playerProfile.freeXp += earnedXp / 4
        GameManager.wallet.addCredits(earnedCredits)
        if (victory) {
            earnedBonds = when (setup.difficulty) {
                com.ironfront.maps.Difficulty.EASY -> 3
                com.ironfront.maps.Difficulty.NORMAL -> 6
                com.ironfront.maps.Difficulty.HARD -> 12
            }
            GameManager.wallet.addWarBonds(earnedBonds)
        }
        GameManager.refreshDailyContract()
        GameManager.dailyContractKills += kills
        SaveManager.save()
        AudioManager.stopEngine()
        if (victory) AudioManager.playVictory() else AudioManager.playDefeat()
    }

    // ------------------------------------------------------------------ HUD

    private fun drawHud() {
        val b = game.batch
        val spec = playerTank.spec
        val gun = spec.gun
        val ammo = playerTank.weapon.currentAmmo

        // status panel
        UiDraw.fillRect(b, 15f, 590f, 430f, 120f, Color(0f, 0f, 0f, 0.55f))
        UiDraw.outlineRect(b, 15f, 590f, 430f, 120f, 2f, spec.nation.primary)
        UiDraw.small(b, spec.name, 28f, 704f, Theme.text)
        val hpRatio = playerTank.currentHp / playerTank.maxHealth
        val hpColor = if (hpRatio > 0.5f) Theme.green else if (hpRatio > 0.25f) Theme.orange else Theme.red
        UiDraw.bar(b, 28f, 650f, 400f, 18f, hpRatio, hpColor)
        UiDraw.centered(b, AssetManager.fontSmall, "HP " + playerTank.currentHp.toInt() + " / " + playerTank.maxHealth.toInt(), 228f, 659f)
        UiDraw.bar(b, 28f, 624f, 400f, 12f, playerTank.weapon.reloadProgress, Theme.gold)
        val ready = if (playerTank.weapon.isReady) "READY" else "RELOADING"
        UiDraw.small(b, ready + "   " + ammo.shortName + "  Pen " + gun.penFor(ammo).toInt() + " mm  Dmg " + (gun.baseDamage * ammo.dmgMultiplier).toInt(), 28f, 612f, ammo.color)

        UiDraw.coloredText(b, "ENEMIES (RED): " + world.enemiesAlive() + "/" + world.totalEnemies, 480f, 706f, Team.ENEMY.outline)
        UiDraw.coloredText(b, "ALLIES (BLUE): " + world.friendsAlive() + "/" + world.totalFriends, 480f, 676f, Team.FRIEND.outline)

        drawMinimap()
        UiDraw.button(b, EXIT_X, EXIT_Y, EXIT_W, EXIT_H, exitColor, "EXIT")
        UiDraw.smallButton(b, EXIT_X, FOG_Y, EXIT_W, FOG_H, Color(0.12f, 0.18f, 0.28f, 0.9f), if (world.vision.enabled) "VISION: ON" else "VISION: OFF")
    }

    private fun drawMinimap() {
        val b = game.batch
        val mx = 1105f
        val my = 438f
        val size = 160f
        val s = size / GameConfig.MAP_WIDTH
        UiDraw.fillRect(b, mx - 2f, my - 2f, size + 4f, size + 4f, Color(0f, 0f, 0f, 0.6f))
        UiDraw.fillRect(b, mx, my, size, size, Color(setup.map.groundColor.r, setup.map.groundColor.g, setup.map.groundColor.b, 0.75f))

        val pixel = AssetManager.getTexture("pixel")
        b.color = setup.map.obstacleColor
        for (o in world.obstacles) {
            if (!o.solid) continue
            b.color = o.minimapColor
            val sz = maxOf(maxOf(o.width, o.height) * s, 2f)
            b.draw(pixel, mx + o.position.x * s - sz / 2f, my + o.position.y * s - sz / 2f, sz, sz)
        }
        b.color = Color.WHITE

        for (t in world.tanks) {
            if (!t.isAlive) continue
            if (!world.vision.isSpotted(t)) continue
            val c = if (t === playerTank) Color.WHITE else t.team.outline
            val sz = if (t === playerTank) 7f else 5f
            UiDraw.fillRect(b, mx + t.position.x * s - sz / 2f, my + t.position.y * s - sz / 2f, sz, sz, c)
        }
        val vw = GameConfig.VIRTUAL_WIDTH * s
        val vh = GameConfig.VIRTUAL_HEIGHT * s
        UiDraw.outlineRect(
            b,
            mx + (worldCamera.position.x - GameConfig.VIRTUAL_WIDTH / 2f) * s,
            my + (worldCamera.position.y - GameConfig.VIRTUAL_HEIGHT / 2f) * s,
            vw, vh, 1f, Color(1f, 1f, 1f, 0.6f)
        )
        UiDraw.outlineRect(b, mx, my, size, size, 2f, Theme.border)
    }

    private fun drawResult() {
        val b = game.batch
        UiDraw.fillRect(b, 0f, 0f, 1280f, 720f, Color(0f, 0f, 0f, 0.62f))
        UiDraw.panel(b, 290f, 120f, 700f, 500f, Theme.panel, if (victory) Theme.gold else Theme.red)
        UiDraw.centered(b, AssetManager.fontBig, if (victory) "VICTORY!" else "TANK DESTROYED", 640f, 575f, if (victory) Theme.gold else Theme.red)
        UiDraw.centered(b, AssetManager.fontSmall, playerTank.spec.name + "  |  " + setup.map.name, 640f, 530f, Theme.textDim)

        val accuracy = if (world.playerShots > 0) world.playerHits * 100 / world.playerShots else 0
        val x1 = 340f
        var y = 490f
        val lines = listOf(
            "Enemies destroyed (you)" to world.playerKills.toString(),
            "Damage dealt" to world.playerDamage.toInt().toString(),
            "Shots fired / hits" to world.playerShots.toString() + " / " + world.playerHits,
            "Accuracy" to "$accuracy %",
            "Ricochets caused" to world.playerRicochets.toString()
        )
        for (line in lines) {
            UiDraw.small(b, line.first, x1, y, Theme.textDim)
            UiDraw.rightText(b, AssetManager.fontSmall, line.second, 940f, y, Theme.text)
            y -= 30f
        }
        UiDraw.fillRect(b, 340f, 318f, 600f, 2f, Theme.border)
        UiDraw.text(b, "REWARD", 340f, 305f)
        UiDraw.coloredText(b, "+" + earnedCredits + " CR", 340f, 268f, Theme.credits)
        UiDraw.coloredText(b, "+" + earnedXp + " XP", 560f, 268f, Theme.xpColor)
        if (earnedBonds > 0) UiDraw.coloredText(b, "+" + earnedBonds + " WAR BONDS", 740f, 268f, Theme.warBonds)
        UiDraw.small(b, "Level " + GameManager.playerProfile.level + "   |   Mastery XP goes to " + playerTank.spec.shortName + " (25% also Free XP)", 340f, 228f, Theme.textDim)
        UiDraw.button(b, 490f, 140f, 300f, 70f, Color(0.20f, 0.50f, 0.25f, 1f), "CONTINUE")
    }

    override fun hide() {
        AudioManager.stopEngine()
    }

    override fun dispose() {
        AudioManager.stopEngine()
        scene3D?.dispose()
        scene3D = null
        world.dispose()
    }

    override fun resize(width: Int, height: Int) {
        worldViewport.update(width, height, false)
        hudViewport.update(width, height, true)
    }

    companion object {
        private const val EXIT_X = 1130f
        private const val EXIT_Y = 665f
        private const val EXIT_W = 135f
        private const val EXIT_H = 45f
        private const val FOG_Y = 620f
        private const val FOG_H = 40f
    }
}
