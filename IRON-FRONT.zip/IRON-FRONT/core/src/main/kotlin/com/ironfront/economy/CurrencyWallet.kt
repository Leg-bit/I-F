package com.ironfront.economy

class CurrencyWallet(
    var credits: Int = 10000,
    var gold: Int = 100
) {
    fun spendCredits(amount: Int): Boolean {
        if (credits < amount) return false
        credits -= amount
        return true
    }

    fun addCredits(amount: Int) {
        credits += amount.coerceAtLeast(0)
    }

    fun spendGold(amount: Int): Boolean {
        if (gold < amount) return false
        gold -= amount
        return true
    }
}
