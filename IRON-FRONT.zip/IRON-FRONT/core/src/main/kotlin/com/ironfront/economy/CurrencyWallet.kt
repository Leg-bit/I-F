package com.ironfront.economy

/**
 * Credits = soft currency earned in battle. Gold = premium currency (free in this game,
 * earned from the daily supply and exchangeable for credits or XP).
 */
class CurrencyWallet(
    var credits: Int = 10000,
    var gold: Int = 100
) {
    fun spendCredits(amount: Int): Boolean {
        if (credits < amount) return false
        credits -= amount
        return true
    }

    fun addCredits(amount: Int) {
        credits += amount.coerceAtLeast(0)
    }

    fun spendGold(amount: Int): Boolean {
        if (gold < amount) return false
        gold -= amount
        return true
    }

    fun addGold(amount: Int) {
        gold += amount.coerceAtLeast(0)
    }

    /** Spends [goldCost] gold and gives [creditsGain] credits. */
    fun exchangeGoldForCredits(goldCost: Int, creditsGain: Int): Boolean {
        if (!spendGold(goldCost)) return false
        addCredits(creditsGain)
        return true
    }

    fun canAffordCredits(amount: Int): Boolean = credits >= amount
}
