package com.ironfront.economy

/**
 * Credits = soft currency earned in battle. Gold = premium currency (free in this game, earned from the
 * daily supply). War Bonds = elite currency from victories and daily contracts, used for Elite Field Modifications.
 */
class CurrencyWallet(
    var credits: Int = 15000,
    var gold: Int = 150,
    var warBonds: Int = 30
) {
    fun spendCredits(amount: Int): Boolean {
        if (credits < amount) return false
        credits -= amount
        return true
    }

    fun addCredits(amount: Int) {
        credits += amount.coerceAtLeast(0)
    }

    fun spendGold(amount: Int): Boolean {
        if (gold < amount) return false
        gold -= amount
        return true
    }

    fun addGold(amount: Int) {
        gold += amount.coerceAtLeast(0)
    }

    fun spendWarBonds(amount: Int): Boolean {
        if (warBonds < amount) return false
        warBonds -= amount
        return true
    }

    fun addWarBonds(amount: Int) {
        warBonds += amount.coerceAtLeast(0)
    }

    fun exchangeGoldForCredits(goldCost: Int, creditsGain: Int): Boolean {
        if (!spendGold(goldCost)) return false
        addCredits(creditsGain)
        return true
    }

    fun canAffordCredits(amount: Int): Boolean = credits >= amount
    fun canAffordWarBonds(amount: Int): Boolean = warBonds >= amount
}
