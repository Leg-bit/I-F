package com.ironfront.weapons

import com.badlogic.gdx.graphics.Color

/**
 * Ammunition families.
 * [ricochetAngleDeg]: shells that hit a plate at this angle (slope + deviation) or more bounce off.
 * [normalizationDeg]: degrees the shell "bites" into the plate, lowering the effective angle.
 */
enum class AmmoType(
    val displayName: String,
    val shortName: String,
    val dmgMultiplier: Float,
    val ricochetAngleDeg: Float,
    val normalizationDeg: Float,
    val speedMultiplier: Float,
    val color: Color
) {
    AP("Armor-Piercing (APCBC)", "AP", 1.00f, 70f, 5f, 1.00f, Color(1.00f, 0.85f, 0.20f, 1f)),
    APCR("Sub-caliber (APCR/APDS)", "APCR", 0.80f, 68f, 2f, 1.15f, Color(0.55f, 0.90f, 1.00f, 1f)),
    HE("High-Explosive", "HE", 1.35f, 90f, 0f, 0.85f, Color(1.00f, 0.45f, 0.12f, 1f))
}

data class GunSpec(
    val name: String,
    val caliberMm: Int,
    val lengthCal: Int,
    val baseDamage: Float,
    val apPen: Float,
    val apcrPen: Float,
    val reloadTimeSec: Float,
    val shellSpeed: Float
) {
    /** Kept for older screens: AP penetration. */
    val basePenetrationMm: Float get() = apPen

    val hePen: Float get() = caliberMm * 0.55f

    val availableAmmo: List<AmmoType> = run {
        val list = mutableListOf(AmmoType.AP)
        if (apcrPen > 0f) list.add(AmmoType.APCR)
        if (caliberMm >= 37) list.add(AmmoType.HE)
        list
    }

    fun penFor(ammo: AmmoType): Float = when (ammo) {
        AmmoType.AP -> apPen
        AmmoType.APCR -> apcrPen
        AmmoType.HE -> hePen
    }

    val damagePerSecond: Float get() = if (reloadTimeSec <= 0f) baseDamage else baseDamage / reloadTimeSec
}

class WeaponSystem(val gunSpec: GunSpec) {
    var currentAmmo: AmmoType = AmmoType.AP
    var reloadTimer: Float = 0f

    val isReady: Boolean
        get() = reloadTimer <= 0f

    val reloadProgress: Float
        get() = if (gunSpec.reloadTimeSec <= 0f) 1f else 1f - (reloadTimer / gunSpec.reloadTimeSec).coerceIn(0f, 1f)

    fun update(delta: Float) {
        if (reloadTimer > 0f) {
            reloadTimer = (reloadTimer - delta).coerceAtLeast(0f)
        }
    }

    fun triggerFire(): Boolean {
        if (!isReady) return false
        reloadTimer = gunSpec.reloadTimeSec
        return true
    }

    fun cycleAmmo() {
        val list = gunSpec.availableAmmo
        val idx = list.indexOf(currentAmmo)
        currentAmmo = list[(idx + 1) % list.size]
    }

    fun selectAmmo(ammo: AmmoType) {
        if (gunSpec.availableAmmo.contains(ammo)) currentAmmo = ammo
    }
}
