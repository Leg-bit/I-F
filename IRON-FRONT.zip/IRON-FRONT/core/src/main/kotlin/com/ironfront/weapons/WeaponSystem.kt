package com.ironfront.weapons

import com.ironfront.core.GameConfig
import kotlin.math.pow

/**
 * Real shell families and how they behave against armor:
 *  - normalizationDeg: how much the shell turns toward the plate normal on impact
 *  - ricochetDeg: obliquity above which the shell tends to glance off
 *  - overmatchRule: shell diameter >= 2x plate thickness ignores angle effects
 *  - flatPenetration: penetration does not fall with range (chemical energy)
 */
enum class AmmoKind(
    val code: String,
    val fullName: String,
    val normalizationDeg: Float,
    val ricochetDeg: Float,
    val overmatchRule: Boolean,
    val flatPenetration: Boolean,
    val damageMult: Float
) {
    AP("AP", "Solid armor-piercing", 2f, 68f, true, false, 1.0f),
    APCBC("APCBC", "AP, capped, ballistic cap", 5f, 70f, true, false, 1.0f),
    APCR("APCR", "Sub-caliber tungsten core", 0f, 66f, true, false, 0.8f),
    HEAT("HEAT", "Shaped charge", 0f, 80f, false, true, 1.0f),
    HE("HE", "High explosive", 0f, 90f, false, true, 1.3f)
}

/**
 * penetration is for a flat plate at 0 degrees obliquity, at 100 m and 1000 m
 * (rounded values from commonly published firing tables), interpolated in between.
 */
data class AmmoSpec(
    val kind: AmmoKind,
    val massKg: Float,
    val velocityMps: Float,
    val pen100Mm: Float,
    val pen1000Mm: Float,
    val stock: Int,
    val coreCaliberMm: Float,
    val damageOverride: Float = 0f
) {
    val damage: Float
        get() = if (damageOverride > 0f) damageOverride else 28.8f * massKg.pow(0.8f) * kind.damageMult

    fun penetrationAt(distanceM: Float): Float {
        if (kind.flatPenetration) return pen100Mm
        val d = distanceM.coerceIn(0f, 3000f)
        val t = (d - 100f) / 900f
        return pen100Mm * (pen1000Mm / pen100Mm).pow(t)
    }
}

data class GunSpec(
    val name: String,
    val caliberMm: Int,
    val lengthCalibers: Float,
    val reloadSec: Float,
    val ammo: List<AmmoSpec>
) {
    val barrelLengthM: Float get() = caliberMm * lengthCalibers / 1000f
    val mainAmmo: AmmoSpec get() = ammo.first()
}

class WeaponSystem(val gun: GunSpec) {
    private val stock = IntArray(gun.ammo.size) { gun.ammo[it].stock }
    var ammoIndex = 0
        private set
    private var reloadTimer = 0f

    val currentAmmo: AmmoSpec get() = gun.ammo[ammoIndex]
    val currentRounds: Int get() = stock[ammoIndex]
    val totalReload: Float get() = gun.reloadSec * GameConfig.ARCADE_RELOAD
    val isReady: Boolean get() = reloadTimer <= 0f && stock[ammoIndex] > 0
    val reloadProgress: Float
        get() = if (reloadTimer <= 0f) 1f else (1f - reloadTimer / totalReload).coerceIn(0f, 1f)

    fun update(delta: Float) {
        if (reloadTimer > 0f) reloadTimer -= delta
    }

    /** Consumes a round and starts the reload. Returns the ammo that was fired, or null if not ready. */
    fun triggerFire(): AmmoSpec? {
        if (!isReady) return null
        val fired = currentAmmo
        stock[ammoIndex]--
        reloadTimer = totalReload
        return fired
    }

    fun cycleAmmo() {
        for (step in 1..gun.ammo.size) {
            val i = (ammoIndex + step) % gun.ammo.size
            if (stock[i] > 0) {
                ammoIndex = i
                return
            }
        }
    }

    /** Bot logic: pick the armor-piercing round that hits hardest at this range. */
    fun selectBest(distanceM: Float) {
        var best = -1
        var bestPen = -1f
        for (i in gun.ammo.indices) {
            if (stock[i] <= 0 || gun.ammo[i].kind == AmmoKind.HE) continue
            val p = gun.ammo[i].penetrationAt(distanceM)
            if (p > bestPen) {
                bestPen = p
                best = i
            }
        }
        if (best == -1) {
            for (i in gun.ammo.indices) {
                if (stock[i] > 0) {
                    best = i
                    break
                }
            }
        }
        if (best != -1) ammoIndex = best
    }
}
