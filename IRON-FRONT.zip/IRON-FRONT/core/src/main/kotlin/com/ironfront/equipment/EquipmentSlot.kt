package com.ironfront.equipment

enum class EquipmentType(
    val title: String,
    val reloadBonus: Float = 0f,
    val speedBonus: Float = 0f,
    val armorBonus: Float = 0f,
    val costCredits: Int = 2500
) {
    GUN_RAMMER("Gun Rammer", reloadBonus = 0.12f, costCredits = 3000),
    TURBOCHARGER("Engine Turbo", speedBonus = 0.15f, costCredits = 3500),
    SPALL_LINER("Spall Liner", armorBonus = 0.10f, costCredits = 2800),
    REPAIR_KIT("Field Repair Kit", costCredits = 1000)
}

class EquipmentLoadout {
    val equipped = mutableListOf<EquipmentType>()

    fun equip(item: EquipmentType): Boolean {
        if (equipped.size >= 3 || equipped.contains(item)) return false
        equipped.add(item)
        return true
    }

    fun getTotalReloadMultiplier(): Float {
        var total = 0f
        for (item in equipped) total += item.reloadBonus
        return (1f - total).coerceAtLeast(0.5f)
    }

    fun getTotalSpeedMultiplier(): Float {
        var total = 0f
        for (item in equipped) total += item.speedBonus
        return 1f + total
    }

    fun getTotalArmorMultiplier(): Float {
        var total = 0f
        for (item in equipped) total += item.armorBonus
        return 1f + total
    }
}
