package com.ironfront.equipment

enum class EquipmentType(
    val title: String,
    val description: String,
    val reloadBonus: Float = 0f,
    val speedBonus: Float = 0f,
    val armorBonus: Float = 0f,
    val costCredits: Int = 2500
) {
    GUN_RAMMER("Gun Rammer", "Reload 12% faster", reloadBonus = 0.12f, costCredits = 3000),
    TURBOCHARGER("Engine Turbo", "Top speed +15%", speedBonus = 0.15f, costCredits = 3500),
    SPALL_LINER("Spall Liner", "Armour +10%", armorBonus = 0.10f, costCredits = 2800),
    REPAIR_KIT("Repair Kit", "Heals 30% HP once per battle", costCredits = 1000)
}

class EquipmentLoadout {
    val equipped = mutableListOf<EquipmentType>()

    fun equip(item: EquipmentType): Boolean {
        if (equipped.size >= MAX_SLOTS || equipped.contains(item)) return false
        equipped.add(item)
        return true
    }

    fun unequip(item: EquipmentType) {
        equipped.remove(item)
    }

    fun has(item: EquipmentType): Boolean = equipped.contains(item)

    fun getTotalReloadMultiplier(): Float {
        var total = 0f
        for (item in equipped) total += item.reloadBonus
        return (1f - total).coerceAtLeast(0.5f)
    }

    fun getTotalSpeedMultiplier(): Float {
        var total = 0f
        for (item in equipped) total += item.speedBonus
        return 1f + total
    }

    fun getTotalArmorMultiplier(): Float {
        var total = 0f
        for (item in equipped) total += item.armorBonus
        return 1f + total
    }

    companion object {
        const val MAX_SLOTS = 3
    }
}
