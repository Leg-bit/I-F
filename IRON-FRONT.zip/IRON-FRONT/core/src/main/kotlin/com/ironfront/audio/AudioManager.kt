package com.ironfront.audio

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.audio.Sound
import com.badlogic.gdx.files.FileHandle
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.exp
import kotlin.math.sin

/**
 * Sound effects are synthesised at start-up into small WAV files, so no audio assets are needed.
 * If anything goes wrong the game simply stays silent.
 */
object AudioManager {
    var sfxEnabled: Boolean = true
    var musicEnabled: Boolean = true

    private const val RATE = 22050
    private var cannon: Sound? = null
    private var explosion: Sound? = null
    private var ricochet: Sound? = null
    private var hit: Sound? = null
    private var click: Sound? = null

    fun init() {
        try {
            val rnd = Random(7L)
            cannon = load("cannon", synth(0.50f) { t ->
                val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 16f)
                val thump = sin(2.0 * Math.PI * (110.0 - 70.0 * t) * t).toFloat() * exp(-t * 7f)
                noise * 0.55f + thump * 0.95f
            })
            explosion = load("explosion", synth(0.95f) { t ->
                val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 4.5f)
                val rumble = sin(2.0 * Math.PI * (60.0 - 25.0 * t) * t).toFloat() * exp(-t * 3.5f)
                noise * 0.6f + rumble * 0.9f
            })
            ricochet = load("ricochet", synth(0.40f) { t ->
                val ping = sin(2.0 * Math.PI * (2300.0 - 1300.0 * t) * t).toFloat() * exp(-t * 9f)
                val tick = (rnd.nextFloat() * 2f - 1f) * exp(-t * 60f)
                ping * 0.6f + tick * 0.5f
            })
            hit = load("hit", synth(0.30f) { t ->
                val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 26f)
                val thud = sin(2.0 * Math.PI * (160.0 - 80.0 * t) * t).toFloat() * exp(-t * 14f)
                noise * 0.5f + thud * 0.9f
            })
            click = load("click", synth(0.06f) { t ->
                sin(2.0 * Math.PI * 900.0 * t).toFloat() * exp(-t * 70f) * 0.6f
            })
        } catch (e: Exception) {
            Gdx.app.log("IronFront", "Audio disabled: " + e.message)
        }
    }

    private fun synth(seconds: Float, gen: (Float) -> Float): ShortArray {
        val n = (seconds * RATE).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val v = (gen(t) * 0.9f).coerceIn(-1f, 1f)
            out[i] = (v * 32000f).toInt().toShort()
        }
        return out
    }

    private fun load(name: String, samples: ShortArray): Sound {
        val fh: FileHandle = Gdx.files.local("sfx/$name.wav")
        val dataLen = samples.size * 2
        val buf = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray())
        buf.putInt(36 + dataLen)
        buf.put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray())
        buf.putInt(16)
        buf.putShort(1.toShort())
        buf.putShort(1.toShort())
        buf.putInt(RATE)
        buf.putInt(RATE * 2)
        buf.putShort(2.toShort())
        buf.putShort(16.toShort())
        buf.put("data".toByteArray())
        buf.putInt(dataLen)
        for (s in samples) buf.putShort(s)
        fh.writeBytes(buf.array(), false)
        return Gdx.audio.newSound(fh)
    }

    private fun play(s: Sound?, volume: Float, pitch: Float) {
        if (!sfxEnabled || s == null) return
        try {
            s.play(volume.coerceIn(0f, 1f), pitch, 0f)
        } catch (e: Exception) {
            // ignore audio errors
        }
    }

    fun playCannonFire(volume: Float = 0.8f) = play(cannon, volume, 0.95f + (Math.random().toFloat() * 0.15f))
    fun playExplosion(volume: Float = 0.9f) = play(explosion, volume, 0.9f + (Math.random().toFloat() * 0.2f))
    fun playRicochet(volume: Float = 0.7f) = play(ricochet, volume, 0.9f + (Math.random().toFloat() * 0.3f))
    fun playHit(volume: Float = 0.8f) = play(hit, volume, 0.9f + (Math.random().toFloat() * 0.2f))
    fun playClick() = play(click, 0.5f, 1f)

    fun dispose() {
        cannon?.dispose()
        explosion?.dispose()
        ricochet?.dispose()
        hit?.dispose()
        click?.dispose()
        cannon = null
        explosion = null
        ricochet = null
        hit = null
        click = null
    }
}
