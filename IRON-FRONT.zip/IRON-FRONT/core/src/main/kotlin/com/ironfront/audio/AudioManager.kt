package com.ironfront.audio

object AudioManager {
    var sfxEnabled: Boolean = true
    var musicEnabled: Boolean = true

    fun playCannonFire() {
        if (!sfxEnabled) return
    }

    fun playExplosion() {
        if (!sfxEnabled) return
    }
}
