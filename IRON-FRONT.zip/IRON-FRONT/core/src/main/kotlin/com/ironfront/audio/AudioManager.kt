package com.ironfront.audio

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.audio.Sound
import com.badlogic.gdx.files.FileHandle
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Every sound effect is synthesised at start-up into a small WAV file, so no audio assets are needed.
 * If anything goes wrong the game simply stays silent.
 */
object AudioManager {
    var sfxEnabled: Boolean = true
    var musicEnabled: Boolean = true

    private const val RATE = 22050
    private var cannon: Sound? = null
    private var explosion: Sound? = null
    private var ricochet: Sound? = null
    private var hit: Sound? = null
    private var click: Sound? = null
    private var reload: Sound? = null
    private var engine: Sound? = null
    private var crash: Sound? = null
    private var victory: Sound? = null
    private var defeat: Sound? = null
    private var thud: Sound? = null

    private var engineId: Long = -1L

    fun init() {
        try {
            val rnd = Random(7L)
            cannon = load("cannon", synth(0.55f) { t ->
                val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 15f)
                val thump = sin(2.0 * PI * (110.0 - 70.0 * t) * t).toFloat() * exp(-t * 6.5f)
                val crack = (rnd.nextFloat() * 2f - 1f) * exp(-t * 60f)
                noise * 0.5f + thump * 0.95f + crack * 0.4f
            })
            explosion = load("explosion", synth(1.0f) { t ->
                val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 4.2f)
                val rumble = sin(2.0 * PI * (58.0 - 22.0 * t) * t).toFloat() * exp(-t * 3.2f)
                noise * 0.6f + rumble * 0.9f
            })
            ricochet = load("ricochet", synth(0.42f) { t ->
                val ping = sin(2.0 * PI * (2400.0 - 1300.0 * t) * t).toFloat() * exp(-t * 8f)
                val tick = (rnd.nextFloat() * 2f - 1f) * exp(-t * 60f)
                ping * 0.6f + tick * 0.5f
            })
            hit = load("hit", synth(0.32f) { t ->
                val noise = (rnd.nextFloat() * 2f - 1f) * exp(-t * 24f)
                val thud = sin(2.0 * PI * (160.0 - 80.0 * t) * t).toFloat() * exp(-t * 13f)
                noise * 0.5f + thud * 0.9f
            })
            thud = load("thud", synth(0.22f) { t ->
                sin(2.0 * PI * (90.0 - 40.0 * t) * t).toFloat() * exp(-t * 18f) * 0.9f +
                    (rnd.nextFloat() * 2f - 1f) * exp(-t * 40f) * 0.25f
            })
            click = load("click", synth(0.06f) { t ->
                sin(2.0 * PI * 900.0 * t).toFloat() * exp(-t * 70f) * 0.6f
            })
            // breech clunk: heavy metal click, then the lock closing
            reload = load("reload", synth(0.38f) { t ->
                val c1 = (rnd.nextFloat() * 2f - 1f) * exp(-t * 90f)
                val t2 = (t - 0.16f).coerceAtLeast(0f)
                val c2 = if (t >= 0.16f) (rnd.nextFloat() * 2f - 1f) * exp(-t2 * 70f) else 0f
                val metal = sin(2.0 * PI * 420.0 * t).toFloat() * (exp(-t * 28f) + (if (t >= 0.16f) exp(-t2 * 30f) else 0f))
                c1 * 0.7f + c2 * 0.8f + metal * 0.5f
            })
            // looping engine: only whole cycles of a 1 second wave, so it loops without a click
            engine = load("engine", synth(1.0f) { t ->
                val w = 2.0 * PI * t
                val body = sin(w * 38.0) * 0.55 + sin(w * 76.0) * 0.30 + sin(w * 114.0) * 0.18 + sin(w * 57.0) * 0.20
                val rattle = sin(w * 211.0) * 0.08 + sin(w * 317.0) * 0.05
                val pulse = 0.75 + 0.25 * sin(w * 19.0)
                ((body + rattle) * pulse * 0.6).toFloat()
            })
            // brick walls and trees breaking
            crash = load("crash", synth(0.65f) { t ->
                val n = (rnd.nextFloat() * 2f - 1f)
                val rattle = if (((t * 40f).toInt() % 3) != 0) n * exp(-t * 6f) else n * 0.2f * exp(-t * 6f)
                val low = sin(2.0 * PI * 70.0 * t).toFloat() * exp(-t * 7f)
                rattle * 0.7f + low * 0.7f
            })
            victory = load("victory", synth(1.3f) { t -> jingle(t, doubleArrayOf(392.0, 494.0, 587.0, 784.0)) })
            defeat = load("defeat", synth(1.3f) { t -> jingle(t, doubleArrayOf(330.0, 294.0, 247.0, 196.0)) })
        } catch (e: Exception) {
            Gdx.app.log("IronFront", "Audio disabled: " + e.message)
        }
    }

    private fun jingle(t: Float, notes: DoubleArray): Float {
        val idx = (t / 0.28f).toInt().coerceAtMost(notes.size - 1)
        val local = t - idx * 0.28f
        val f = notes[idx]
        val env = exp(-local * 4.5f) * (if (idx == notes.size - 1) exp(-(t - 0.84f).coerceAtLeast(0f) * 1.5f) else 1f)
        return (sin(2.0 * PI * f * t) * 0.6 + sin(2.0 * PI * f * 2.0 * t) * 0.2).toFloat() * env
    }

    private fun synth(seconds: Float, gen: (Float) -> Float): ShortArray {
        val n = (seconds * RATE).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toFloat() / RATE
            val v = (gen(t) * 0.9f).coerceIn(-1f, 1f)
            out[i] = (v * 32000f).toInt().toShort()
        }
        return out
    }

    private fun load(name: String, samples: ShortArray): Sound {
        val fh: FileHandle = Gdx.files.local("sfx/$name.wav")
        val dataLen = samples.size * 2
        val buf = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray())
        buf.putInt(36 + dataLen)
        buf.put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray())
        buf.putInt(16)
        buf.putShort(1.toShort())
        buf.putShort(1.toShort())
        buf.putInt(RATE)
        buf.putInt(RATE * 2)
        buf.putShort(2.toShort())
        buf.putShort(16.toShort())
        buf.put("data".toByteArray())
        buf.putInt(dataLen)
        for (s in samples) buf.putShort(s)
        fh.writeBytes(buf.array(), false)
        return Gdx.audio.newSound(fh)
    }

    private fun play(s: Sound?, volume: Float, pitch: Float, pan: Float = 0f) {
        if (!sfxEnabled || s == null) return
        try {
            s.play(volume.coerceIn(0f, 1f), pitch.coerceIn(0.5f, 2f), pan.coerceIn(-1f, 1f))
        } catch (e: Exception) {
            // ignore audio errors
        }
    }

    private fun jitter(range: Float): Float = (Math.random().toFloat() - 0.5f) * range

    /** Big guns boom low, small guns crack high. */
    fun playCannonFire(volume: Float = 0.8f, caliberMm: Int = 75, pan: Float = 0f) {
        val pitch = (1.45f - caliberMm / 150f).coerceIn(0.62f, 1.4f) + jitter(0.1f)
        play(cannon, volume, pitch, pan)
    }

    fun playExplosion(volume: Float = 0.9f, pan: Float = 0f) = play(explosion, volume, 0.9f + jitter(0.2f), pan)
    fun playRicochet(volume: Float = 0.7f, pan: Float = 0f) = play(ricochet, volume, 1.0f + jitter(0.4f), pan)
    fun playHit(volume: Float = 0.8f, pan: Float = 0f) = play(hit, volume, 0.95f + jitter(0.2f), pan)
    fun playThud(volume: Float = 0.6f, pan: Float = 0f) = play(thud, volume, 1f + jitter(0.3f), pan)
    fun playCrash(volume: Float = 0.8f, pan: Float = 0f) = play(crash, volume, 1f + jitter(0.3f), pan)
    fun playReload(volume: Float = 0.55f) = play(reload, volume, 1f)
    fun playClick() = play(click, 0.5f, 1f)
    fun playVictory() = play(victory, 0.7f, 1f)
    fun playDefeat() = play(defeat, 0.7f, 1f)

    // ------------------------------------------------------------ engine loop

    fun startEngine() {
        if (engineId != -1L) return
        val s = engine ?: return
        try {
            engineId = s.loop(if (sfxEnabled) 0.12f else 0f)
            s.setPitch(engineId, 0.7f)
        } catch (e: Exception) {
            engineId = -1L
        }
    }

    /** [speedRatio] 0..1 of the player's top speed: pitch and volume rise with it. */
    fun updateEngine(speedRatio: Float) {
        val s = engine ?: return
        if (engineId == -1L) return
        try {
            val r = speedRatio.coerceIn(0f, 1f)
            s.setPitch(engineId, 0.65f + r * 0.85f)
            s.setVolume(engineId, if (sfxEnabled) 0.10f + r * 0.22f else 0f)
        } catch (e: Exception) {
            // ignore audio errors
        }
    }

    fun stopEngine() {
        val s = engine ?: return
        if (engineId == -1L) return
        try {
            s.stop(engineId)
        } catch (e: Exception) {
            // ignore audio errors
        }
        engineId = -1L
    }

    fun dispose() {
        stopEngine()
        cannon?.dispose()
        explosion?.dispose()
        ricochet?.dispose()
        hit?.dispose()
        click?.dispose()
        reload?.dispose()
        engine?.dispose()
        crash?.dispose()
        victory?.dispose()
        defeat?.dispose()
        thud?.dispose()
        cannon = null
        explosion = null
        ricochet = null
        hit = null
        click = null
        reload = null
        engine = null
        crash = null
        victory = null
        defeat = null
        thud = null
    }
}
