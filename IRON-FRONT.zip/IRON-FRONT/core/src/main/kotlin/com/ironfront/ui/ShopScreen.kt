package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.save.SaveManager

/** Gold is the premium currency: exchange it for credits or XP, and claim the free daily supply. */
class ShopScreen(game: IronFront) : UiScreen(game) {
    private var toast = ""
    private var toastTimer = 0f

    private class Offer(
        val title: String,
        val subtitle: String,
        val goldCost: Int,
        val credits: Int,
        val xp: Int,
        val bonds: Int = 0
    )

    private val offers = listOf(
        Offer("Small Credit Pack", "10 GOLD  ->  5,000 CR", 10, 5000, 0),
        Offer("Large Credit Pack", "50 GOLD  ->  30,000 CR", 50, 30000, 0),
        Offer("Small XP Pack", "10 GOLD  ->  400 XP", 10, 0, 400),
        Offer("Large XP Pack", "50 GOLD  ->  2,500 XP", 50, 0, 2500),
        Offer("War Bond Pack", "20 GOLD  ->  10 WAR BONDS", 20, 0, 0, 10),
        Offer("War Bond Crate", "100 GOLD  ->  60 WAR BONDS", 100, 0, 0, 60)
    )

    private val dailyIntervalMs = 20L * 60L * 60L * 1000L

    private fun dailyRemainingMs(): Long {
        val next = GameManager.lastDailyClaimMs + dailyIntervalMs
        return (next - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    /** Day number the next claim would count as (1..7). */
    private fun nextStreakValue(): Int {
        val today = GameManager.today()
        return if (GameManager.lastLoginDay == today - 1L) (GameManager.loginStreak + 1).coerceAtMost(7)
        else if (GameManager.lastLoginDay == today) GameManager.loginStreak.coerceAtLeast(1)
        else 1
    }

    private fun offerX(i: Int): Float = 40f + (i % 2) * 400f
    private fun offerY(i: Int): Float = 430f - (i / 2) * 145f

    override fun update(delta: Float) {
        if (toastTimer > 0f) toastTimer -= delta
    }

    override fun draw(b: SpriteBatch) {
        UiDraw.tacticalBackdrop(b)
        UiDraw.fillRect(b, 0f, 650f, 1280f, 70f, Theme.header)
        UiDraw.fillRect(b, 0f, 648f, 1280f, 2f, Theme.border)
        UiDraw.smallButton(b, 20f, 662f, 120f, 46f, Theme.darkRed, "< BACK")
        UiDraw.big(b, "EXCHANGE", 165f, 703f, Theme.gold)
        UiDraw.currencyBar(b, 1250f, 668f)

        UiDraw.small(b, "CURRENCIES", 40f, 625f, Theme.gold)
        UiDraw.small(b, "Credits (CR): earned in battle, used to buy tanks and equipment.", 40f, 600f, Theme.textDim)
        UiDraw.small(b, "Gold: premium currency from the daily supply. XP: spent to research tanks.", 40f, 576f, Theme.textDim)

        offers.forEachIndexed { i, o ->
            val x = offerX(i)
            val y = offerY(i)
            val can = GameManager.wallet.gold >= o.goldCost
            UiDraw.panel(b, x, y, 380f, 130f)
            UiDraw.small(b, o.title, x + 14f, y + 112f, Theme.text)
            UiDraw.small(b, o.subtitle, x + 14f, y + 84f, Theme.goldCoin)
            UiDraw.button(b, x + 14f, y + 12f, 352f, 50f, if (can) Theme.darkGreen else Theme.dark, if (can) "EXCHANGE" else "NOT ENOUGH GOLD")
        }

        // daily supply
        UiDraw.panel(b, 850f, 270f, 390f, 280f, Theme.panel, Theme.gold)
        UiDraw.text(b, "DAILY SUPPLY", 870f, 535f)
        val nextStreak = nextStreakValue()
        UiDraw.small(b, "+" + UiDraw.formatNumber(5000 + 1500 * (nextStreak - 1)) + " CR   +120 XP   +5 GOLD", 870f, 500f, Theme.credits)
        UiDraw.small(b, if (nextStreak >= 7) "+10 WAR BONDS (streak bonus!)" else "+1 WAR BOND", 870f, 476f, Theme.warBonds)
        UiDraw.small(b, "LOGIN STREAK", 870f, 446f, Theme.textDim)
        for (d in 1..7) {
            val on = d <= GameManager.loginStreak
            val next = d == nextStreak
            UiDraw.fillRect(b, 870f + (d - 1) * 50f, 392f, 44f, 32f, if (on) Theme.darkGreen else Theme.dark)
            UiDraw.outlineRect(b, 870f + (d - 1) * 50f, 392f, 44f, 32f, if (next) 3f else 1f, if (next) Theme.gold else Theme.border)
            UiDraw.centered(b, AssetManager.fontSmall, d.toString(), 870f + (d - 1) * 50f + 22f, 408f, if (on) Theme.text else Theme.textDim)
        }
        val remain = dailyRemainingMs()
        if (remain <= 0L) {
            UiDraw.button(b, 870f, 290f, 350f, 80f, Color(0.70f, 0.50f, 0.10f, 1f), "CLAIM NOW")
        } else {
            val h = remain / 3600000L
            val m = (remain % 3600000L) / 60000L
            UiDraw.button(b, 870f, 290f, 350f, 80f, Theme.dark, "READY IN " + h + "h " + m + "m")
        }

        if (toastTimer > 0f) {
            UiDraw.centered(b, AssetManager.font, toast, 640f, 190f, Theme.gold)
        }
    }

    private fun say(text: String) {
        toast = text
        toastTimer = 2.4f
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 20f, 662f, 120f, 46f)) {
            SaveManager.save()
            AudioManager.playClick()
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }

        offers.forEachIndexed { i, o ->
            if (UiDraw.hit(x, y, offerX(i) + 14f, offerY(i) + 12f, 352f, 50f)) {
                AudioManager.playClick()
                if (GameManager.wallet.spendGold(o.goldCost)) {
                    GameManager.wallet.addCredits(o.credits)
                    GameManager.playerProfile.addXp(o.xp)
                    GameManager.wallet.addWarBonds(o.bonds)
                    SaveManager.save()
                    say("Exchanged " + o.goldCost + " gold")
                } else {
                    say("Not enough gold")
                }
                return
            }
        }

        if (UiDraw.hit(x, y, 870f, 290f, 350f, 80f)) {
            if (dailyRemainingMs() <= 0L) {
                val streak = nextStreakValue()
                GameManager.wallet.addCredits(5000 + 1500 * (streak - 1))
                GameManager.wallet.addGold(5)
                GameManager.wallet.addWarBonds(if (streak >= 7) 10 else 1)
                GameManager.playerProfile.addXp(120)
                GameManager.loginStreak = if (streak >= 7) 0 else streak
                GameManager.lastLoginDay = GameManager.today()
                GameManager.lastDailyClaimMs = System.currentTimeMillis()
                SaveManager.save()
                AudioManager.playClick()
                say("Daily supply claimed!")
            } else {
                say("Come back later for the next supply")
            }
        }
    }
}
