package com.ironfront.core

import com.badlogic.gdx.Screen
import com.ironfront.IronFront

object ScreenManager {
    private lateinit var game: IronFront
    private var currentScreen: Screen? = null

    fun init(gameInstance: IronFront) {
        game = gameInstance
    }

    fun setScreen(newScreen: Screen) {
        currentScreen?.dispose()
        currentScreen = newScreen
        game.setScreen(newScreen)
    }

    fun dispose() {
        currentScreen?.dispose()
        currentScreen = null
    }
}
