package com.ironfront.physics

import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.GameConfig
import com.ironfront.entities.ObstacleEntity
import com.ironfront.tanks.TankEntity
import kotlin.math.abs

object CollisionSystem {
    fun resolveTankWorldBounds(tank: TankEntity) {
        val hx = tank.halfExtentX
        val hy = tank.halfExtentY
        tank.position.x = MathUtils.clamp(tank.position.x, hx, GameConfig.MAP_WIDTH - hx)
        tank.position.y = MathUtils.clamp(tank.position.y, hy, GameConfig.MAP_HEIGHT - hy)
    }

    /** Uses the tank's rotated footprint, so a long Tiger II turning in place pushes off walls correctly. */
    fun resolveTankObstacle(tank: TankEntity, obstacle: ObstacleEntity) {
        val dx = tank.position.x - obstacle.position.x
        val dy = tank.position.y - obstacle.position.y
        val overlapX = tank.halfExtentX + obstacle.width / 2f - abs(dx)
        val overlapY = tank.halfExtentY + obstacle.height / 2f - abs(dy)
        if (overlapX <= 0f || overlapY <= 0f) return

        if (overlapX < overlapY) {
            tank.position.x += if (dx > 0f) overlapX else -overlapX
        } else {
            tank.position.y += if (dy > 0f) overlapY else -overlapY
        }
    }

    fun resolveTankVsTank(a: TankEntity, b: TankEntity) {
        if (!a.isAlive || !b.isAlive) return
        val dist = a.position.dst(b.position)
        val minDist = a.collisionRadius + b.collisionRadius
        if (dist < minDist && dist > 0.01f) {
            val push = (minDist - dist) * 0.5f
            val nx = (a.position.x - b.position.x) / dist
            val ny = (a.position.y - b.position.y) / dist
            a.position.add(nx * push, ny * push)
            b.position.sub(nx * push, ny * push)
        }
    }
}
