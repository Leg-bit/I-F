package com.ironfront.physics

import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.GameConfig
import com.ironfront.entities.ObstacleEntity
import com.ironfront.tanks.TankEntity
import kotlin.math.abs

object CollisionSystem {
    fun resolveTankWorldBounds(tank: TankEntity) {
        val halfW = tank.width / 2f
        val halfH = tank.height / 2f
        tank.position.x = MathUtils.clamp(tank.position.x, halfW, GameConfig.MAP_WIDTH - halfW)
        tank.position.y = MathUtils.clamp(tank.position.y, halfH, GameConfig.MAP_HEIGHT - halfH)
    }

    fun resolveTankObstacle(tank: TankEntity, obstacle: ObstacleEntity) {
        if (!obstacle.isAlive || !obstacle.solid) return
        if (obstacle.kind != com.ironfront.maps.ObstacleKind.BOX) {
            resolveTankCircle(tank, obstacle)
            return
        }
        if (abs(tank.position.x - obstacle.position.x) > 220f || abs(tank.position.y - obstacle.position.y) > 220f) return
        val dx = tank.position.x - obstacle.position.x
        val dy = tank.position.y - obstacle.position.y
        val overlapX = (tank.width + obstacle.width) / 2f - abs(dx)
        val overlapY = (tank.height + obstacle.height) / 2f - abs(dy)
        if (overlapX <= 0f || overlapY <= 0f) return

        if (overlapX < overlapY) {
            tank.position.x += if (dx > 0f) overlapX else -overlapX
        } else {
            tank.position.y += if (dy > 0f) overlapY else -overlapY
        }
        tank.onCollision()
    }

    /** Pushes the tank's collision box out of a round obstacle (rocks, trunks, wrecks). */
    private fun resolveTankCircle(tank: TankEntity, o: ObstacleEntity) {
        val r = o.radius
        val hw = tank.width / 2f
        val hh = tank.height / 2f
        val nearX = MathUtils.clamp(o.position.x, tank.position.x - hw, tank.position.x + hw)
        val nearY = MathUtils.clamp(o.position.y, tank.position.y - hh, tank.position.y + hh)
        val dx = o.position.x - nearX
        val dy = o.position.y - nearY
        val d2 = dx * dx + dy * dy
        if (d2 >= r * r) return
        if (d2 > 0.0001f) {
            val d = kotlin.math.sqrt(d2)
            val push = r - d
            tank.position.x -= dx / d * push
            tank.position.y -= dy / d * push
        } else {
            val ox = o.position.x - tank.position.x
            val oy = o.position.y - tank.position.y
            val penX = hw + r - abs(ox)
            val penY = hh + r - abs(oy)
            if (penX < penY) tank.position.x += if (ox > 0f) -penX else penX
            else tank.position.y += if (oy > 0f) -penY else penY
        }
        tank.onCollision()
    }

    fun resolveTankVsTank(a: TankEntity, b: TankEntity) {
        if (!a.isAlive || !b.isAlive) return
        val dist = a.position.dst(b.position)
        val minDist = (a.collisionRadius + b.collisionRadius)
        if (dist < minDist && dist > 0.01f) {
            val push = (minDist - dist) * 0.5f
            val nx = (a.position.x - b.position.x) / dist
            val ny = (a.position.y - b.position.y) / dist
            a.position.add(nx * push, ny * push)
            b.position.sub(nx * push, ny * push)
        }
    }
}
