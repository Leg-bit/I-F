package com.ironfront.vision

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.Shaders
import com.ironfront.entities.ObstacleEntity
import com.ironfront.maps.ObstacleKind
import com.ironfront.tanks.TankEntity
import com.ironfront.teams.Team
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Fog of war with a spotlight:  [tank]<
 *  - a cone in front of the turret (long range)
 *  - a circle around the hull (short range, all-round awareness)
 *  - solid objects (walls, rocks, trunks, wrecks) block the view
 *  - bushes hide tanks standing in them unless they are very close
 *  - a tank that fires is revealed for a moment
 * Allies share what they see with you.
 */
class VisionSystem(private val obstacles: List<ObstacleEntity>) {
    var enabled: Boolean = true

    private val rays = 256
    private val rayDist = FloatArray(rays)
    private val cell = 128f
    private val gridW = (GameConfig.MAP_WIDTH / cell).toInt() + 1
    private val grid = Array(gridW * gridW) { ArrayList<ObstacleEntity>() }
    private val bushes = obstacles.filter { it.kind == ObstacleKind.BUSH }

    private val spottedUntil = HashMap<String, Float>()
    private var clock = 0f

    private var originX = 0f
    private var originY = 0f
    private var coneDir = 0f
    private var coneRange = 700f
    private var circleR = 180f

    var halfAngle = 48f

    /** The far edge of the fan is uneven (some rays reach further than others), like the ragged beam edges of a lamp. */
    private val jagCtrl = FloatArray(24)

    private fun jagAt(angleDeg: Float): Float {
        var a = angleDeg % 360f
        if (a < 0f) a += 360f
        val f = a / 360f * jagCtrl.size
        val i0 = f.toInt() % jagCtrl.size
        val i1 = (i0 + 1) % jagCtrl.size
        val t = f - f.toInt()
        val k = (1f - kotlin.math.cos(t * 3.14159265f)) * 0.5f
        return jagCtrl[i0] * (1f - k) + jagCtrl[i1] * k
    }

    // the line-of-sight distances are uploaded to the GPU as a 256x1 texture for the fog shader
    private val rayPixmap = Pixmap(rays, 1, Pixmap.Format.RGBA8888)
    private val rayTexture: Texture
    private var maxRayRange = 800f
    private val allyData = FloatArray(18)

    // atmosphere of the map (colour tint over everything)
    private var tintR = 1f
    private var tintG = 1f
    private var tintB = 1f
    private var tintAmt = 0f

    init {
        val jr = java.util.Random(4242L)
        for (i in jagCtrl.indices) jagCtrl[i] = 1f + 0f * jr.nextFloat()
        rayPixmap.setBlending(Pixmap.Blending.None)
        rayTexture = Texture(rayPixmap)
        rayTexture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        rayTexture.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.ClampToEdge)
        for (o in obstacles) {
            if (!o.blocksSight) continue
            val r = (if (o.kind == ObstacleKind.BOX) kotlin.math.max(o.width, o.height) * 0.75f else o.radius) + 4f
            val minX = ((o.position.x - r) / cell).toInt().coerceIn(0, gridW - 1)
            val maxX = ((o.position.x + r) / cell).toInt().coerceIn(0, gridW - 1)
            val minY = ((o.position.y - r) / cell).toInt().coerceIn(0, gridW - 1)
            val maxY = ((o.position.y + r) / cell).toInt().coerceIn(0, gridW - 1)
            for (gx in minX..maxX) for (gy in minY..maxY) grid[gy * gridW + gx].add(o)
        }
    }

    fun setAtmosphere(r: Float, g: Float, b: Float, amount: Float) {
        tintR = r
        tintG = g
        tintB = b
        tintAmt = amount
    }

    fun dispose() {
        rayTexture.dispose()
        rayPixmap.dispose()
    }

    private fun blockedAt(x: Float, y: Float): Boolean {
        val gx = (x / cell).toInt()
        val gy = (y / cell).toInt()
        if (gx < 0 || gy < 0 || gx >= gridW || gy >= gridW) return true
        val list = grid[gy * gridW + gx]
        for (i in 0 until list.size) {
            val o = list[i]
            if (o.isAlive && o.containsPoint(x, y)) return true
        }
        return false
    }

    /** Free line of sight between two points (the end points themselves are ignored). */
    private fun lineClear(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < 30f) return true
        val steps = (dist / 14f).toInt()
        for (i in 1 until steps) {
            val t = i.toFloat() / steps
            if (blockedAt(x1 + dx * t, y1 + dy * t)) return false
        }
        return true
    }

    private fun inBush(x: Float, y: Float): Boolean {
        for (b in bushes) {
            if (b.overlapsPoint(x, y)) return true
        }
        return false
    }

    fun canSee(viewer: TankEntity, target: TankEntity): Boolean {
        val dx = target.position.x - viewer.turretX
        val dy = target.position.y - viewer.turretY
        val d = sqrt(dx * dx + dy * dy)
        val inCircle = d <= viewer.awareness
        var inCone = false
        if (!inCircle && d <= viewer.viewRange) {
            val ang = MathUtils.atan2(dy, dx) * MathUtils.radiansToDegrees
            inCone = abs(angleDiff(ang, viewer.turretRotation)) <= viewer.spec.viewHalfAngleDeg &&
                d <= viewer.viewRange * jagAt(ang)
        }
        if (!inCircle && !inCone) return false
        if (d > 150f && inBush(target.position.x, target.position.y)) return false
        return lineClear(viewer.turretX, viewer.turretY, target.position.x, target.position.y)
    }

    fun update(delta: Float, player: TankEntity, tanks: List<TankEntity>) {
        clock += delta
        originX = player.turretX
        originY = player.turretY
        coneDir = player.turretRotation
        coneRange = player.viewRange
        circleR = player.awareness
        halfAngle = player.spec.viewHalfAngleDeg

        val maxR = coneRange + 40f
        maxRayRange = maxR
        for (i in 0 until rays) {
            val ang = (i + 0.5f) * 360f / rays
            val cx = MathUtils.cosDeg(ang)
            val cy = MathUtils.sinDeg(ang)
            var d = 0f
            while (d < maxR) {
                d += 14f
                if (blockedAt(originX + cx * d, originY + cy * d)) break
            }
            rayDist[i] = d
            rayPixmap.setColor((d / maxR).coerceIn(0f, 1f), jagAt(ang), 0f, 1f)
            rayPixmap.drawPixel(i, 0)
        }
        rayTexture.draw(rayPixmap, 0, 0)

        for (t in tanks) {
            if (t.team != Team.ENEMY || !t.isAlive) continue
            var seen = false
            if (t.revealTimer > 0f) {
                val dx = t.position.x - player.position.x
                val dy = t.position.y - player.position.y
                if (dx * dx + dy * dy < 1100f * 1100f) seen = true
            }
            if (!seen) {
                for (v in tanks) {
                    if (!v.isAlive || v.team != Team.FRIEND) continue
                    if (canSee(v, t)) {
                        seen = true
                        break
                    }
                }
            }
            if (seen) spottedUntil[t.id] = clock + 0.7f
        }
    }

    /** Is this tank currently visible to the player? */
    fun isSpotted(t: TankEntity): Boolean {
        if (!enabled || t.team == Team.FRIEND) return true
        if (!t.isAlive) return lit(t.position.x, t.position.y, emptyList()) > 0.3f
        val until = spottedUntil[t.id] ?: return false
        return until > clock
    }

    /** 0 = dark, 1 = fully lit, for a world position (player's vision only). */
    fun lit(x: Float, y: Float, allies: List<TankEntity>): Float {
        if (!enabled) return 1f
        val dx = x - originX
        val dy = y - originY
        val d2 = dx * dx + dy * dy
        var best = 0f
        val reach = coneRange + 60f
        if (d2 <= reach * reach) {
            val d = sqrt(d2)
            val ang = MathUtils.atan2(dy, dx) * MathUtils.radiansToDegrees
            val rd = rayLength(ang)
            if (d <= rd + 26f) {
                val circleLit = ((circleR + 40f - d) / 40f).coerceIn(0f, 1f)
                val angFade = ((halfAngle + 4.5f - abs(angleDiff(ang, coneDir))) / 4.5f).coerceIn(0f, 1f)
                val distFade = ((coneRange * jagAt(ang) - d) / 90f).coerceIn(0f, 1f)
                best = kotlin.math.max(circleLit, angFade * distFade)
            }
        }
        for (a in allies) {
            val ax = x - a.position.x
            val ay = y - a.position.y
            val ad = sqrt(ax * ax + ay * ay)
            if (ad < 190f) best = kotlin.math.max(best, ((190f - ad) / 40f).coerceIn(0f, 1f))
        }
        return best
    }

    private fun rayLength(angleDeg: Float): Float {
        var a = angleDeg % 360f
        if (a < 0f) a += 360f
        var f = a / 360f * rays - 0.5f
        if (f < 0f) f += rays
        val i0 = f.toInt() % rays
        val i1 = (i0 + 1) % rays
        val t = f - f.toInt()
        return rayDist[i0] * (1f - t) + rayDist[i1] * t
    }

    private fun angleDiff(a: Float, b: Float): Float {
        var d = (a - b) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    /**
     * Draws the dark fog, spotlight cone, light glow, tint and vignette on top of the world.
     * [lights] holds up to 6 lights as x, y, radius, intensity (world coordinates).
     */
    fun render(batch: SpriteBatch, camX: Float, camY: Float, allies: List<TankEntity>, lights: FloatArray, lightCount: Int) {
        val sh = Shaders.fog
        if (sh == null) {
            renderFallback(batch, camX, camY, allies)
            return
        }
        val hw = GameConfig.VIRTUAL_WIDTH / 2f + 24f
        val hh = GameConfig.VIRTUAL_HEIGHT / 2f + 24f

        batch.shader = sh
        sh.setUniformf("u_origin", originX, originY)
        sh.setUniformf("u_dir", coneDir * 0.017453292f)
        sh.setUniformf("u_half", halfAngle * 0.017453292f)
        sh.setUniformf("u_cone", coneRange)
        sh.setUniformf("u_circle", circleR)
        sh.setUniformf("u_maxR", maxRayRange)
        sh.setUniformf("u_fogOn", if (enabled) 1f else 0f)
        sh.setUniformf("u_tint", tintR, tintG, tintB)
        sh.setUniformf("u_tintAmt", tintAmt)

        for (i in 0 until 6) {
            if (i < allies.size) {
                val a = allies[i]
                allyData[i * 3] = a.position.x - originX
                allyData[i * 3 + 1] = a.position.y - originY
                allyData[i * 3 + 2] = 1f
            } else {
                allyData[i * 3] = 0f
                allyData[i * 3 + 1] = 0f
                allyData[i * 3 + 2] = 0f
            }
        }
        sh.setUniform3fv("u_allies", allyData, 0, 18)

        val rel = FloatArray(24)
        for (i in 0 until lightCount.coerceAtMost(6)) {
            rel[i * 4] = lights[i * 4] - originX
            rel[i * 4 + 1] = lights[i * 4 + 1] - originY
            rel[i * 4 + 2] = lights[i * 4 + 2]
            rel[i * 4 + 3] = lights[i * 4 + 3]
        }
        sh.setUniform4fv("u_lights", rel, 0, 24)

        rayTexture.bind(1)
        Gdx.gl.glActiveTexture(GL20.GL_TEXTURE0)
        sh.setUniformi("u_rays", 1)

        batch.setColor(1f, 1f, 1f, 1f)
        batch.draw(AssetManager.getRegion("pixel"), camX - hw, camY - hh, hw * 2f, hh * 2f)
        batch.flush()
        batch.shader = null
    }

    private val tmpRight = com.badlogic.gdx.math.Vector3()
    private val relLights = FloatArray(24)

    /**
     * Fog, spotlight, light glow, tint and vignette for the tilted 3D camera. Drawn as one full-screen quad in
     * HUD coordinates (0..1280 x 0..720); the shader finds the ground point under every pixel.
     */
    fun render3D(batch: SpriteBatch, cam: PerspectiveCamera, allies: List<TankEntity>, lights: FloatArray, lightCount: Int) {
        val sh = Shaders.fog3d ?: return
        batch.shader = sh

        val tanY = kotlin.math.tan(Math.toRadians(cam.fieldOfView.toDouble() / 2.0)).toFloat()
        val aspect = 1280f / 720f
        tmpRight.set(cam.direction).crs(cam.up).nor().scl(tanY * aspect)

        sh.setUniformf("u_forward", cam.direction.x, cam.direction.y, cam.direction.z)
        sh.setUniformf("u_right", tmpRight.x, tmpRight.y, tmpRight.z)
        sh.setUniformf("u_up", cam.up.x * tanY, cam.up.y * tanY, cam.up.z * tanY)
        // camera position relative to the player's view origin; the 3D z axis is the 2D y axis flipped
        sh.setUniformf("u_camRel", cam.position.x - originX, cam.position.y, -cam.position.z - originY)
        sh.setUniformf("u_originW", originX, originY)

        sh.setUniformf("u_dir", coneDir * 0.017453292f)
        sh.setUniformf("u_half", halfAngle * 0.017453292f)
        sh.setUniformf("u_cone", coneRange)
        sh.setUniformf("u_circle", circleR)
        sh.setUniformf("u_maxR", maxRayRange)
        sh.setUniformf("u_fogOn", if (enabled) 1f else 0f)
        sh.setUniformf("u_tint", tintR, tintG, tintB)
        sh.setUniformf("u_tintAmt", tintAmt)

        for (i in 0 until 6) {
            if (i < allies.size) {
                val a = allies[i]
                allyData[i * 3] = a.position.x - originX
                allyData[i * 3 + 1] = a.position.y - originY
                allyData[i * 3 + 2] = 1f
            } else {
                allyData[i * 3] = 0f
                allyData[i * 3 + 1] = 0f
                allyData[i * 3 + 2] = 0f
            }
        }
        sh.setUniform3fv("u_allies", allyData, 0, 18)

        for (i in 0 until 24) relLights[i] = 0f
        for (i in 0 until lightCount.coerceAtMost(6)) {
            relLights[i * 4] = lights[i * 4] - originX
            relLights[i * 4 + 1] = lights[i * 4 + 1] - originY
            relLights[i * 4 + 2] = lights[i * 4 + 2]
            relLights[i * 4 + 3] = lights[i * 4 + 3]
        }
        sh.setUniform4fv("u_lights", relLights, 0, 24)

        rayTexture.bind(1)
        Gdx.gl.glActiveTexture(GL20.GL_TEXTURE0)
        sh.setUniformi("u_rays", 1)

        batch.setColor(1f, 1f, 1f, 1f)
        batch.draw(AssetManager.getRegion("pixel"), 0f, 0f, 1280f, 720f)
        batch.flush()
        batch.shader = null
    }

    /** Used only if the fog shader could not be compiled: slower grid of dark squares. */
    private fun renderFallback(batch: SpriteBatch, camX: Float, camY: Float, allies: List<TankEntity>) {
        if (!enabled) return
        val pixel = AssetManager.getRegion("pixel")
        val size = 16f
        val halfW = GameConfig.VIRTUAL_WIDTH / 2f + size
        val halfH = GameConfig.VIRTUAL_HEIGHT / 2f + size
        val startX = (Math.floor(((camX - halfW) / size).toDouble()) * size).toFloat()
        val startY = (Math.floor(((camY - halfH) / size).toDouble()) * size).toFloat()
        val endX = camX + halfW
        val endY = camY + halfH
        var y = startY
        while (y < endY) {
            var x = startX
            while (x < endX) {
                val l = lit(x + size / 2f, y + size / 2f, allies)
                val a = (1f - l) * 0.72f
                if (a > 0.01f) {
                    batch.setColor(0.02f, 0.03f, 0.05f, a)
                    batch.draw(pixel, x, y, size, size)
                }
                x += size
            }
            y += size
        }
        batch.setColor(1f, 1f, 1f, 1f)
    }
}
