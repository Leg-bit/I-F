package com.ironfront.ui

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.ScreenAdapter
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.FitViewport
import com.ironfront.IronFront
import com.ironfront.core.GameConfig
import kotlin.math.abs

/**
 * Base class for menu screens: one virtual 1280x720 canvas, tap and drag callbacks.
 * Subclasses draw in [draw] and react in [onTap] / [onDrag].
 */
abstract class UiScreen(protected val game: IronFront) : ScreenAdapter() {
    protected val camera = OrthographicCamera()
    protected val viewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, camera)
    private val touch = Vector3()

    private var touching = false
    private var dragged = false
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f

    abstract fun draw(b: SpriteBatch)

    open fun onTap(x: Float, y: Float) {}

    open fun onDrag(dx: Float, dy: Float) {}

    open fun update(delta: Float) {}

    override fun render(delta: Float) {
        update(delta)
        Gdx.gl.glClearColor(Theme.bg.r, Theme.bg.g, Theme.bg.b, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)

        viewport.apply()
        game.batch.projectionMatrix = camera.combined
        game.batch.begin()
        draw(game.batch)
        game.batch.end()

        handleInput()
    }

    private fun handleInput() {
        if (Gdx.input.isTouched) {
            val sx = Gdx.input.x.toFloat()
            val sy = Gdx.input.y.toFloat()
            if (!touching) {
                touching = true
                dragged = false
                downX = sx
                downY = sy
                lastX = sx
                lastY = sy
            } else {
                if (!dragged && (abs(sx - downX) > 14f || abs(sy - downY) > 14f)) dragged = true
                if (dragged) {
                    val scaleX = GameConfig.VIRTUAL_WIDTH / viewport.screenWidth.toFloat()
                    val scaleY = GameConfig.VIRTUAL_HEIGHT / viewport.screenHeight.toFloat()
                    onDrag((sx - lastX) * scaleX, -(sy - lastY) * scaleY)
                }
                lastX = sx
                lastY = sy
            }
        } else if (touching) {
            touching = false
            if (!dragged) {
                touch.set(downX, downY, 0f)
                viewport.unproject(touch)
                onTap(touch.x, touch.y)
            }
        }
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }
}
