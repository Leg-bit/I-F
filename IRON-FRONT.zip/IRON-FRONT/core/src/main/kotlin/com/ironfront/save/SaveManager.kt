package com.ironfront.save

import com.badlogic.gdx.Gdx
import com.ironfront.core.GameManager

object SaveManager {
    private const val PREF_NAME = "iron_front_save_v2"

    fun save() {
        val prefs = Gdx.app.getPreferences(PREF_NAME)
        prefs.putInteger("credits", GameManager.wallet.credits)
        prefs.putInteger("gold", GameManager.wallet.gold)
        prefs.putInteger("freeXp", GameManager.playerProfile.freeXp)
        prefs.putInteger("kills", GameManager.playerProfile.totalKills)
        prefs.putString("selectedTank", GameManager.selectedTankId)
        prefs.putString("unlockedTanks", GameManager.techTree.unlockedTanks.joinToString(","))
        prefs.putString("researchedTanks", GameManager.techTree.researchedTanks.joinToString(","))
        prefs.flush()
    }

    fun load() {
        val prefs = Gdx.app.getPreferences(PREF_NAME)
        if (!prefs.contains("credits")) return
        GameManager.wallet.credits = prefs.getInteger("credits", 15000)
        GameManager.wallet.gold = prefs.getInteger("gold", 150)
        GameManager.playerProfile.freeXp = prefs.getInteger("freeXp", 600)
        GameManager.playerProfile.totalKills = prefs.getInteger("kills", 0)
        GameManager.selectedTankId = prefs.getString("selectedTank", "t26")
        prefs.getString("unlockedTanks", "").split(",").filter { it.isNotBlank() }.forEach {
            GameManager.techTree.unlockTank(it)
        }
        prefs.getString("researchedTanks", "").split(",").filter { it.isNotBlank() }.forEach {
            GameManager.techTree.researchedTanks.add(it)
        }
    }
}
