package com.ironfront.save

import com.badlogic.gdx.Gdx
import com.ironfront.core.GameManager
import com.ironfront.equipment.EquipmentType
import com.ironfront.tanks.TankDatabase

object SaveManager {
    private const val PREF_NAME = "iron_front_save_v1"

    fun save() {
        val prefs = Gdx.app.getPreferences(PREF_NAME)
        prefs.putInteger("credits", GameManager.wallet.credits)
        prefs.putInteger("gold", GameManager.wallet.gold)
        prefs.putInteger("freeXp", GameManager.playerProfile.freeXp)
        prefs.putInteger("totalXp", GameManager.playerProfile.totalXp)
        prefs.putInteger("kills", GameManager.playerProfile.totalKills)
        prefs.putInteger("battles", GameManager.playerProfile.battlesPlayed)
        prefs.putInteger("wins", GameManager.playerProfile.battlesWon)
        prefs.putString("selectedTank", GameManager.selectedTankId)
        prefs.putString("unlockedTanks", GameManager.techTree.unlockedTanks.joinToString(","))
        prefs.putString("ownedEquipment", GameManager.ownedEquipment.joinToString(",") { it.name })
        prefs.putString("equippedEquipment", GameManager.equippedEquipment.joinToString(",") { it.name })
        prefs.putLong("lastDaily", GameManager.lastDailyClaimMs)
        prefs.putBoolean("controlDirect", GameManager.controlDirect)
        prefs.flush()
    }

    fun load() {
        val prefs = Gdx.app.getPreferences(PREF_NAME)
        if (!prefs.contains("credits")) return
        GameManager.wallet.credits = prefs.getInteger("credits", 15000)
        GameManager.wallet.gold = prefs.getInteger("gold", 150)
        GameManager.playerProfile.freeXp = prefs.getInteger("freeXp", 600)
        GameManager.playerProfile.totalXp = prefs.getInteger("totalXp", GameManager.playerProfile.freeXp)
        GameManager.playerProfile.totalKills = prefs.getInteger("kills", 0)
        GameManager.playerProfile.battlesPlayed = prefs.getInteger("battles", 0)
        GameManager.playerProfile.battlesWon = prefs.getInteger("wins", 0)
        GameManager.playerProfile.refreshLevel()

        val unlockedRaw = prefs.getString("unlockedTanks", "t34_76")
        unlockedRaw.split(",").filter { it.isNotBlank() && TankDatabase.contains(it) }.forEach {
            GameManager.techTree.unlockTank(it)
        }
        val selected = prefs.getString("selectedTank", "t34_76")
        GameManager.selectedTankId =
            if (TankDatabase.contains(selected) && GameManager.techTree.isUnlocked(selected)) selected else "t34_76"

        GameManager.ownedEquipment.clear()
        GameManager.equippedEquipment.clear()
        prefs.getString("ownedEquipment", "").split(",").forEach { name ->
            EquipmentType.values().firstOrNull { it.name == name }?.let { GameManager.ownedEquipment.add(it) }
        }
        prefs.getString("equippedEquipment", "").split(",").forEach { name ->
            val e = EquipmentType.values().firstOrNull { it.name == name }
            if (e != null && GameManager.ownedEquipment.contains(e) && GameManager.equippedEquipment.size < 3) {
                GameManager.equippedEquipment.add(e)
            }
        }
        GameManager.lastDailyClaimMs = prefs.getLong("lastDaily", 0L)
        GameManager.controlDirect = prefs.getBoolean("controlDirect", true)
    }
}
