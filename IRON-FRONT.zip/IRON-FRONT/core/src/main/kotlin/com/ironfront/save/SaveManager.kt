package com.ironfront.save

import com.badlogic.gdx.Gdx
import com.ironfront.core.GameManager
import com.ironfront.equipment.EquipmentType
import com.ironfront.tanks.TankDatabase

object SaveManager {
    private const val PREF_NAME = "iron_front_save_v1"

    fun save() {
        val prefs = Gdx.app.getPreferences(PREF_NAME)
        prefs.putInteger("credits", GameManager.wallet.credits)
        prefs.putInteger("gold", GameManager.wallet.gold)
        prefs.putInteger("warBonds", GameManager.wallet.warBonds)
        prefs.putInteger("freeXp", GameManager.playerProfile.freeXp)
        prefs.putInteger("totalXp", GameManager.playerProfile.totalXp)
        prefs.putInteger("kills", GameManager.playerProfile.totalKills)
        prefs.putInteger("battles", GameManager.playerProfile.battlesPlayed)
        prefs.putInteger("wins", GameManager.playerProfile.battlesWon)
        prefs.putString("selectedTank", GameManager.selectedTankId)
        prefs.putString("unlockedTanks", GameManager.techTree.unlockedTanks.joinToString(","))
        prefs.putString("ownedEquipment", GameManager.ownedEquipment.joinToString(",") { it.name })
        prefs.putString("equippedEquipment", GameManager.equippedEquipment.joinToString(",") { it.name })
        prefs.putLong("lastDaily", GameManager.lastDailyClaimMs)
        prefs.putString("eliteTanks", GameManager.techTree.eliteTanks.joinToString(","))
        prefs.putString("tankXp", GameManager.techTree.tankXp.entries.joinToString(",") { it.key + ":" + it.value })
        prefs.putInteger("dailyKills", GameManager.dailyContractKills)
        prefs.putBoolean("dailyClaimed", GameManager.dailyContractClaimed)
        prefs.putLong("dailyDay", GameManager.dailyContractDay)
        prefs.putInteger("loginStreak", GameManager.loginStreak)
        prefs.putLong("lastLoginDay", GameManager.lastLoginDay)
        prefs.putBoolean("controlDirect", GameManager.controlDirect)
        prefs.flush()
    }

    fun load() {
        val prefs = Gdx.app.getPreferences(PREF_NAME)
        if (!prefs.contains("credits")) return
        GameManager.wallet.credits = prefs.getInteger("credits", 15000)
        GameManager.wallet.gold = prefs.getInteger("gold", 150)
        GameManager.wallet.warBonds = prefs.getInteger("warBonds", 30)
        GameManager.playerProfile.freeXp = prefs.getInteger("freeXp", 600)
        GameManager.playerProfile.totalXp = prefs.getInteger("totalXp", GameManager.playerProfile.freeXp)
        GameManager.playerProfile.totalKills = prefs.getInteger("kills", 0)
        GameManager.playerProfile.battlesPlayed = prefs.getInteger("battles", 0)
        GameManager.playerProfile.battlesWon = prefs.getInteger("wins", 0)
        GameManager.playerProfile.refreshLevel()

        val unlockedRaw = prefs.getString("unlockedTanks", "t34_76")
        unlockedRaw.split(",").filter { it.isNotBlank() && TankDatabase.contains(it) }.forEach {
            GameManager.techTree.unlockTank(it)
        }
        val selected = prefs.getString("selectedTank", "t34_76")
        GameManager.selectedTankId =
            if (TankDatabase.contains(selected) && GameManager.techTree.isUnlocked(selected)) selected else "t34_76"

        GameManager.ownedEquipment.clear()
        GameManager.equippedEquipment.clear()
        prefs.getString("ownedEquipment", "").split(",").forEach { name ->
            EquipmentType.values().firstOrNull { it.name == name }?.let { GameManager.ownedEquipment.add(it) }
        }
        prefs.getString("equippedEquipment", "").split(",").forEach { name ->
            val e = EquipmentType.values().firstOrNull { it.name == name }
            if (e != null && GameManager.ownedEquipment.contains(e) && GameManager.equippedEquipment.size < 3) {
                GameManager.equippedEquipment.add(e)
            }
        }
        GameManager.lastDailyClaimMs = prefs.getLong("lastDaily", 0L)
        prefs.getString("eliteTanks", "").split(",").filter { it.isNotBlank() && TankDatabase.contains(it) }.forEach {
            GameManager.techTree.eliteTanks.add(it)
        }
        prefs.getString("tankXp", "").split(",").forEach { entry ->
            val parts = entry.split(":")
            if (parts.size == 2 && TankDatabase.contains(parts[0])) {
                val xp = parts[1].toIntOrNull()
                if (xp != null && xp > 0) GameManager.techTree.tankXp[parts[0]] = xp
            }
        }
        GameManager.dailyContractKills = prefs.getInteger("dailyKills", 0)
        GameManager.dailyContractClaimed = prefs.getBoolean("dailyClaimed", false)
        GameManager.dailyContractDay = prefs.getLong("dailyDay", 0L)
        GameManager.loginStreak = prefs.getInteger("loginStreak", 0)
        GameManager.lastLoginDay = prefs.getLong("lastLoginDay", 0L)
        GameManager.refreshDailyContract()
        GameManager.controlDirect = prefs.getBoolean("controlDirect", true)
    }
}
