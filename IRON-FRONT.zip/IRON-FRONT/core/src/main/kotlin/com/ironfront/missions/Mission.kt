package com.ironfront.missions

data class Mission(
    val id: String,
    val title: String,
    val briefing: String,
    val enemyTankIds: List<String>,
    val rewardCredits: Int,
    val rewardXp: Int
)

object MissionRegistry {
    private val missions = linkedMapOf<String, Mission>()

    fun load() {
        missions.clear()
        missions["mission_01"] = Mission(
            id = "mission_01",
            title = "Operation Steppe Dawn",
            briefing = "Destroy the enemy armored patrol scouting the eastern ridge.",
            enemyTankIds = listOf("pz4_f2", "pz4_f2", "m4_sherman"),
            rewardCredits = 2500,
            rewardXp = 350
        )
        missions["mission_02"] = Mission(
            id = "mission_02",
            title = "Steel Ambush",
            briefing = "Hold the crossroads against a reinforced medium & heavy platoon.",
            enemyTankIds = listOf("pz4_f2", "m4_sherman", "tiger_1"),
            rewardCredits = 5000,
            rewardXp = 750
        )
        missions["mission_03"] = Mission(
            id = "mission_03",
            title = "Iron Citadel",
            briefing = "Eliminate the elite heavy tank division guarding the fortress.",
            enemyTankIds = listOf("tiger_1", "is_2", "tiger_1"),
            rewardCredits = 9500,
            rewardXp = 1400
        )
    }

    fun getMission(id: String): Mission = missions[id] ?: missions.values.first()
    fun all(): List<Mission> = missions.values.toList()
}
