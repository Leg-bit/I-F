package com.ironfront.maps

import com.badlogic.gdx.graphics.Color
import com.ironfront.core.GameConfig
import java.util.Random
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * What a map object is.
 * BOX    - rectangular solid (walls, sandbags, cliffs)
 * ROCK   - round solid (boulders, debris piles, hedgehogs)
 * TRUNK  - tree: only the small trunk is solid, the canopy is drawn above tanks
 * BUSH   - no collision, drawn above tanks, hides tanks standing inside it
 * DECOR  - flat ground decoration (craters, roads, floors, dunes)
 * SWAMP  - flat zone that slows tanks (mud, quicksand, thin ice)
 * WRECK  - burnt-out tank, round solid
 */
enum class ObstacleKind(val solid: Boolean, val blocksSight: Boolean) {
    BOX(true, true),
    ROCK(true, true),
    TRUNK(true, true),
    BUSH(false, false),
    DECOR(false, false),
    SWAMP(false, false),
    WRECK(true, true)
}

data class ObstacleDef(
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val texture: String,
    val destructible: Boolean = false,
    val kind: ObstacleKind = ObstacleKind.BOX,
    val rotation: Float = 0f,
    val tankId: String = ""
)

data class SpawnZone(val minX: Float, val maxX: Float, val minY: Float, val maxY: Float)

data class MapDef(
    val id: String,
    val name: String,
    val description: String,
    val groundColor: Color,
    val groundDetail: Color,
    val obstacleColor: Color,
    val playerSpawnX: Float,
    val playerSpawnY: Float,
    val enemyZone: SpawnZone,
    val obstacles: List<ObstacleDef>
)

/** Helper that scatters forests, ruins, roads, craters, cliffs ... while keeping the spawn areas clear. */
private class MapBuilder(seed: Long, private val playerX: Float, private val playerY: Float, private val enemy: SpawnZone) {
    val rnd = Random(seed)
    val list = mutableListOf<ObstacleDef>()
    private val m = GameConfig.MAP_WIDTH

    private fun rand(a: Float, b: Float): Float = a + rnd.nextFloat() * (b - a)

    /** Solid things must not block the two spawn areas. */
    private fun clear(x: Float, y: Float): Boolean {
        val dx = x - playerX
        val dy = y - playerY
        if (dx * dx + dy * dy < 300f * 300f) return false
        if (x > enemy.minX - 90f && x < enemy.maxX + 90f && y > enemy.minY - 90f && y < enemy.maxY + 90f) return false
        return x > 60f && x < m - 60f && y > 60f && y < m - 60f
    }

    fun add(d: ObstacleDef) {
        list.add(d)
    }

    fun grove(cx: Float, cy: Float, radius: Float, count: Int, textures: List<String>) {
        var placed = 0
        var tries = 0
        val spots = mutableListOf<FloatArray>()
        while (placed < count && tries < count * 25) {
            tries++
            val a = rnd.nextFloat() * 6.2832f
            val r = sqrt(rnd.nextFloat()) * radius
            val x = cx + cos(a) * r
            val y = cy + sin(a) * r
            if (!clear(x, y)) continue
            if (spots.any { (it[0] - x) * (it[0] - x) + (it[1] - y) * (it[1] - y) < 46f * 46f }) continue
            spots.add(floatArrayOf(x, y))
            val size = rand(64f, 88f)
            add(ObstacleDef(x, y, size, size, textures[rnd.nextInt(textures.size)], true, ObstacleKind.TRUNK, rnd.nextFloat() * 360f))
            placed++
        }
    }

    fun scatterTrees(count: Int, textures: List<String>) {
        var placed = 0
        var tries = 0
        while (placed < count && tries < count * 20) {
            tries++
            val x = rand(120f, m - 120f)
            val y = rand(120f, m - 120f)
            if (!clear(x, y)) continue
            val size = rand(60f, 84f)
            add(ObstacleDef(x, y, size, size, textures[rnd.nextInt(textures.size)], true, ObstacleKind.TRUNK, rnd.nextFloat() * 360f))
            placed++
        }
    }

    fun rocks(count: Int, texture: String, minSize: Float = 52f, maxSize: Float = 80f) {
        var placed = 0
        var tries = 0
        while (placed < count && tries < count * 20) {
            tries++
            val x = rand(120f, m - 120f)
            val y = rand(120f, m - 120f)
            if (!clear(x, y)) continue
            val s = rand(minSize, maxSize)
            add(ObstacleDef(x, y, s, s, texture, false, ObstacleKind.ROCK, rnd.nextFloat() * 360f))
            placed++
        }
    }

    fun bushPatches(count: Int, texture: String = "obstacle_bush") {
        for (p in 0 until count) {
            val cx = rand(200f, m - 200f)
            val cy = rand(200f, m - 200f)
            val n = 4 + rnd.nextInt(4)
            for (i in 0 until n) {
                val x = cx + rand(-90f, 90f)
                val y = cy + rand(-70f, 70f)
                val s = rand(80f, 118f)
                add(ObstacleDef(x, y, s, s, texture, false, ObstacleKind.BUSH, rnd.nextFloat() * 360f))
            }
        }
    }

    fun craters(count: Int) {
        for (i in 0 until count) {
            val s = rand(70f, 140f)
            add(ObstacleDef(rand(100f, m - 100f), rand(100f, m - 100f), s, s, "decor_crater", false, ObstacleKind.DECOR, rnd.nextFloat() * 360f))
        }
    }

    fun dunes(count: Int) {
        for (i in 0 until count) {
            val w = rand(260f, 420f)
            add(ObstacleDef(rand(100f, m - 100f), rand(100f, m - 100f), w, w * rand(0.35f, 0.5f), "decor_dune", false, ObstacleKind.DECOR, rnd.nextFloat() * 180f))
        }
    }

    fun swamps(count: Int, texture: String, minR: Float, maxR: Float) {
        var placed = 0
        var tries = 0
        while (placed < count && tries < 60) {
            tries++
            val x = rand(300f, m - 300f)
            val y = rand(300f, m - 300f)
            val dx = x - playerX
            val dy = y - playerY
            if (dx * dx + dy * dy < 420f * 420f) continue
            val r = rand(minR, maxR)
            add(ObstacleDef(x, y, r * 2f, r * 2f, texture, false, ObstacleKind.SWAMP, rnd.nextFloat() * 360f))
            placed++
        }
    }

    fun wrecks(count: Int, ids: List<String>) {
        var placed = 0
        var tries = 0
        while (placed < count && tries < 40) {
            tries++
            val x = rand(200f, m - 200f)
            val y = rand(200f, m - 200f)
            if (!clear(x, y)) continue
            add(ObstacleDef(x, y, 44f, 44f, "wreck", false, ObstacleKind.WRECK, rnd.nextFloat() * 360f, ids[rnd.nextInt(ids.size)]))
            placed++
        }
    }

    fun hedgehogs(count: Int) {
        var placed = 0
        var tries = 0
        while (placed < count && tries < count * 20) {
            tries++
            val x = rand(200f, m - 200f)
            val y = rand(200f, m - 200f)
            if (!clear(x, y)) continue
            add(ObstacleDef(x, y, 40f, 40f, "obstacle_hedgehog", true, ObstacleKind.ROCK, rnd.nextFloat() * 360f))
            placed++
        }
    }

    fun sandbags(x: Float, y: Float, count: Int, vertical: Boolean) {
        for (i in 0 until count) {
            val px = if (vertical) x else x + i * 66f
            val py = if (vertical) y + i * 66f else y
            if (!clear(px, py)) continue
            if (vertical) {
                add(ObstacleDef(px, py, 28f, 64f, "obstacle_sandbag_v", true, ObstacleKind.BOX))
            } else {
                add(ObstacleDef(px, py, 64f, 28f, "obstacle_sandbag", true, ObstacleKind.BOX))
            }
        }
    }

    /** A dirt road made of rotated flat strips. */
    fun road(points: List<FloatArray>, width: Float) {
        for (i in 0 until points.size - 1) {
            val x1 = points[i][0]
            val y1 = points[i][1]
            val x2 = points[i + 1][0]
            val y2 = points[i + 1][1]
            val len = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1))
            val ang = atan2(y2 - y1, x2 - x1) * 57.29578f
            add(ObstacleDef((x1 + x2) / 2f, (y1 + y2) / 2f, len + 40f, width, "decor_road", false, ObstacleKind.DECOR, ang))
        }
    }

    /** A bombed-out building: floor, broken brick walls with doorways, rubble inside. */
    fun ruinHouse(cx: Float, cy: Float, w: Float, h: Float, breakChance: Float = 0.25f) {
        add(ObstacleDef(cx, cy, w, h, "decor_floor", false, ObstacleKind.DECOR, 0f))
        val thick = 24f
        val pieceLen = 96f
        // horizontal walls (top and bottom). The bottom wall always gets a doorway in the middle.
        val nx = max(2, (w / pieceLen).toInt())
        val stepX = w / nx
        for (i in 0 until nx) {
            val x = cx - w / 2f + stepX * (i + 0.5f)
            val tex = "obstacle_wallh" + rnd.nextInt(2)
            if (rnd.nextFloat() > breakChance) addWall(x, cy + h / 2f, stepX, thick, tex)
            val doorway = (i == nx / 2)
            if (!doorway && rnd.nextFloat() > breakChance) addWall(x, cy - h / 2f, stepX, thick, tex)
        }
        // vertical walls (left and right)
        val ny = max(2, (h / pieceLen).toInt())
        val stepY = h / ny
        for (i in 0 until ny) {
            val y = cy - h / 2f + stepY * (i + 0.5f)
            val tex = "obstacle_wallv" + rnd.nextInt(2)
            if (rnd.nextFloat() > breakChance) addWall(cx - w / 2f, y, thick, stepY, tex)
            if (rnd.nextFloat() > breakChance + 0.1f) addWall(cx + w / 2f, y, thick, stepY, tex)
        }
        // rubble inside
        for (i in 0 until 2) {
            val s = rand(38f, 54f)
            add(ObstacleDef(cx + rand(-w / 4f, w / 4f), cy + rand(-h / 4f, h / 4f), s, s, "obstacle_debris", false, ObstacleKind.ROCK, rnd.nextFloat() * 360f))
        }
    }

    private fun addWall(x: Float, y: Float, w: Float, h: Float, tex: String) {
        if (!clear(x, y)) return
        add(ObstacleDef(x, y, w, h, tex, true, ObstacleKind.BOX))
    }

    /** Jagged cliff ridge made of blocks of different sizes. */
    fun cliffLine(x1: Float, y1: Float, x2: Float, y2: Float, gapEvery: Int) {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        val n = max(2, (len / 70f).toInt())
        for (i in 0..n) {
            if (gapEvery > 0 && i % gapEvery == gapEvery - 1) continue
            val t = i.toFloat() / n
            val x = x1 + dx * t + rand(-14f, 14f)
            val y = y1 + dy * t + rand(-14f, 14f)
            if (!clear(x, y)) continue
            add(ObstacleDef(x, y, rand(70f, 118f), rand(56f, 100f), "obstacle_cliff", false, ObstacleKind.BOX))
        }
    }
}

object MapRegistry {
    private val maps = linkedMapOf<String, MapDef>()

    private val WRECK_IDS = listOf("pz4_f2", "t34_76", "m4_sherman", "pz3_j", "bt7", "cromwell", "chi_ha", "m3_stuart")
    private val TREES = listOf("obstacle_tree", "obstacle_tree", "obstacle_pine")
    private val PINES = listOf("obstacle_pine")
    private val DEAD = listOf("obstacle_deadtree")

    init {
        register(steppe())
        register(canyon())
        register(urban())
        register(desert())
        register(frozen())
    }

    private fun register(map: MapDef) {
        maps[map.id] = map
    }

    fun get(id: String): MapDef = maps[id] ?: maps.values.first()
    fun all(): List<MapDef> = maps.values.toList()

    private fun pt(x: Float, y: Float) = floatArrayOf(x, y)

    // ---------------------------------------------------------------- maps

    private fun steppe(): MapDef {
        val enemy = SpawnZone(1700f, 2350f, 1700f, 2350f)
        val b = MapBuilder(101L, 300f, 300f, enemy)
        b.road(listOf(pt(200f, 260f), pt(900f, 700f), pt(1300f, 1300f), pt(1900f, 1700f), pt(2400f, 2300f)), 54f)
        b.craters(18)
        b.grove(900f, 1700f, 230f, 11, TREES)
        b.grove(1750f, 800f, 260f, 13, TREES)
        b.grove(500f, 1250f, 170f, 8, TREES)
        b.grove(1300f, 2150f, 200f, 9, TREES)
        b.grove(2150f, 1250f, 180f, 8, TREES)
        b.scatterTrees(18, TREES)
        b.rocks(14, "obstacle_rock")
        b.bushPatches(9)
        b.ruinHouse(1250f, 1050f, 320f, 230f)
        b.ruinHouse(800f, 2050f, 260f, 200f, 0.35f)
        b.sandbags(1480f, 1500f, 4, false)
        b.sandbags(1100f, 1480f, 3, true)
        b.hedgehogs(6)
        b.wrecks(4, WRECK_IDS)
        return MapDef(
            id = "steppe",
            name = "Steppe Dawn",
            description = "Open plains with groves, a dirt road and ruined farms. Good for flanking.",
            groundColor = Color(0.34f, 0.35f, 0.21f, 1f),
            groundDetail = Color(0.28f, 0.30f, 0.17f, 1f),
            obstacleColor = Color(0.20f, 0.40f, 0.17f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = enemy,
            obstacles = b.list
        )
    }

    private fun canyon(): MapDef {
        val enemy = SpawnZone(1700f, 2350f, 1650f, 2350f)
        val b = MapBuilder(202L, 300f, 300f, enemy)
        b.road(listOf(pt(250f, 300f), pt(1000f, 800f), pt(1400f, 1300f), pt(2000f, 1800f), pt(2350f, 2300f)), 50f)
        b.cliffLine(500f, 900f, 1500f, 700f, 6)
        b.cliffLine(900f, 1500f, 2100f, 1250f, 7)
        b.cliffLine(300f, 1800f, 1100f, 2100f, 5)
        b.cliffLine(1500f, 300f, 2350f, 650f, 6)
        b.cliffLine(1750f, 1000f, 1750f, 1700f, 5)
        b.craters(10)
        b.rocks(34, "obstacle_rock")
        b.bushPatches(5)
        b.scatterTrees(10, DEAD)
        b.ruinHouse(1250f, 1350f, 260f, 200f, 0.4f)
        b.sandbags(700f, 1200f, 3, false)
        b.hedgehogs(5)
        b.wrecks(3, WRECK_IDS)
        return MapDef(
            id = "canyon",
            name = "Rocky Canyon",
            description = "Cliff ridges with narrow passes. Ambush spots and tight corners.",
            groundColor = Color(0.42f, 0.33f, 0.24f, 1f),
            groundDetail = Color(0.35f, 0.27f, 0.19f, 1f),
            obstacleColor = Color(0.52f, 0.34f, 0.22f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = enemy,
            obstacles = b.list
        )
    }

    private fun urban(): MapDef {
        val enemy = SpawnZone(1750f, 2350f, 1750f, 2350f)
        val b = MapBuilder(303L, 300f, 300f, enemy)
        // street grid
        b.road(listOf(pt(150f, 1280f), pt(2420f, 1280f)), 70f)
        b.road(listOf(pt(1280f, 150f), pt(1280f, 2420f)), 70f)
        b.road(listOf(pt(150f, 700f), pt(2420f, 700f)), 50f)
        b.road(listOf(pt(150f, 1900f), pt(2420f, 1900f)), 50f)
        b.road(listOf(pt(700f, 150f), pt(700f, 2420f)), 50f)
        b.road(listOf(pt(1900f, 150f), pt(1900f, 2420f)), 50f)
        b.craters(16)
        // city blocks
        val xs = floatArrayOf(480f, 1000f, 1560f, 2100f)
        val ys = floatArrayOf(480f, 1000f, 1560f, 2100f)
        var n = 0
        for (x in xs) {
            for (y in ys) {
                n++
                val w = 230f + (n * 37 % 90)
                val h = 200f + (n * 53 % 80)
                b.ruinHouse(x + (n * 17 % 40), y + (n * 29 % 40), w, h, 0.28f)
            }
        }
        b.rocks(16, "obstacle_debris", 44f, 70f)
        b.scatterTrees(10, DEAD)
        b.bushPatches(3)
        b.sandbags(1180f, 1330f, 3, false)
        b.sandbags(1330f, 1180f, 3, true)
        b.sandbags(640f, 760f, 2, false)
        b.sandbags(1850f, 1840f, 2, false)
        b.hedgehogs(10)
        b.wrecks(7, WRECK_IDS)
        return MapDef(
            id = "urban",
            name = "Urban Ruins",
            description = "A bombed city. Walls crumble when shot, so watch the rubble.",
            groundColor = Color(0.27f, 0.28f, 0.28f, 1f),
            groundDetail = Color(0.22f, 0.23f, 0.23f, 1f),
            obstacleColor = Color(0.50f, 0.45f, 0.42f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = enemy,
            obstacles = b.list
        )
    }

    private fun desert(): MapDef {
        val enemy = SpawnZone(1700f, 2350f, 1700f, 2350f)
        val b = MapBuilder(404L, 300f, 300f, enemy)
        b.dunes(16)
        b.road(listOf(pt(200f, 300f), pt(1100f, 900f), pt(1500f, 1500f), pt(2400f, 2200f)), 52f)
        b.swamps(4, "decor_sand", 120f, 190f)
        b.craters(12)
        b.rocks(20, "obstacle_sandrock")
        b.scatterTrees(9, DEAD)
        b.bushPatches(10)
        b.ruinHouse(1250f, 1250f, 300f, 220f, 0.3f)
        b.ruinHouse(1580f, 1020f, 220f, 170f, 0.35f)
        b.ruinHouse(950f, 1500f, 240f, 190f, 0.3f)
        b.sandbags(1400f, 1560f, 4, false)
        b.hedgehogs(5)
        b.wrecks(4, WRECK_IDS)
        return MapDef(
            id = "desert",
            name = "Desert Dunes",
            description = "Open sand with a ruined village, scrub, and quicksand that slows tanks.",
            groundColor = Color(0.74f, 0.63f, 0.42f, 1f),
            groundDetail = Color(0.62f, 0.52f, 0.34f, 1f),
            obstacleColor = Color(0.70f, 0.58f, 0.38f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = enemy,
            obstacles = b.list
        )
    }

    private fun frozen(): MapDef {
        val enemy = SpawnZone(1650f, 2350f, 1650f, 2350f)
        val b = MapBuilder(505L, 300f, 300f, enemy)
        b.road(listOf(pt(200f, 280f), pt(800f, 1100f), pt(1500f, 1400f), pt(2350f, 2250f)), 48f)
        b.swamps(2, "decor_ice", 220f, 300f)
        b.craters(8)
        b.grove(700f, 700f, 280f, 20, PINES)
        b.grove(1700f, 600f, 300f, 24, PINES)
        b.grove(500f, 1700f, 280f, 20, PINES)
        b.grove(1300f, 1300f, 260f, 18, PINES)
        b.grove(2100f, 1300f, 240f, 16, PINES)
        b.grove(1100f, 2150f, 280f, 20, PINES)
        b.scatterTrees(18, PINES)
        b.rocks(14, "obstacle_snowrock")
        b.bushPatches(7)
        b.ruinHouse(1000f, 1000f, 220f, 170f, 0.3f)
        b.ruinHouse(1850f, 1950f, 220f, 170f, 0.35f)
        b.hedgehogs(4)
        b.wrecks(3, WRECK_IDS)
        return MapDef(
            id = "frozen",
            name = "Frozen Forest",
            description = "Dense pine forest and frozen lakes. Trees can be shot down; bushes hide tanks.",
            groundColor = Color(0.80f, 0.85f, 0.90f, 1f),
            groundDetail = Color(0.66f, 0.73f, 0.80f, 1f),
            obstacleColor = Color(0.15f, 0.32f, 0.24f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = enemy,
            obstacles = b.list
        )
    }
}
