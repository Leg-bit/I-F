package com.ironfront.maps

import com.badlogic.gdx.graphics.Color
import com.ironfront.core.GameConfig
import java.util.Random
import kotlin.math.ceil
import kotlin.math.sqrt

data class ObstacleDef(
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val texture: String,
    val destructible: Boolean = false
)

data class SpawnZone(val minX: Float, val maxX: Float, val minY: Float, val maxY: Float)

data class MapDef(
    val id: String,
    val name: String,
    val description: String,
    val groundColor: Color,
    val groundDetail: Color,
    val obstacleColor: Color,
    val playerSpawnX: Float,
    val playerSpawnY: Float,
    val enemyZone: SpawnZone,
    val obstacles: List<ObstacleDef>
)

object MapRegistry {
    private val maps = linkedMapOf<String, MapDef>()

    init {
        register(steppe())
        register(canyon())
        register(urban())
        register(desert())
        register(frozen())
    }

    private fun register(map: MapDef) {
        maps[map.id] = map
    }

    fun get(id: String): MapDef = maps[id] ?: maps.values.first()
    fun all(): List<MapDef> = maps.values.toList()

    // ---------------------------------------------------------------- maps

    private fun steppe(): MapDef = MapDef(
        id = "steppe",
        name = "Steppe Dawn",
        description = "Open plains with scattered rocks. Fast flanking and long shots.",
        groundColor = Color(0.34f, 0.32f, 0.22f, 1f),
        groundDetail = Color(0.29f, 0.27f, 0.18f, 1f),
        obstacleColor = Color(0.35f, 0.35f, 0.38f, 1f),
        playerSpawnX = 300f,
        playerSpawnY = 300f,
        enemyZone = SpawnZone(1500f, 2350f, 1500f, 2350f),
        obstacles = scatter(30, 7L, 300f, 300f, 320f, "obstacle_rock", 64f)
    )

    private fun canyon(): MapDef {
        val list = mutableListOf<ObstacleDef>()
        list.addAll(wall(120f, 900f, 1000f, 900f, "obstacle_cliff"))
        list.addAll(wall(1350f, 900f, 2440f, 900f, "obstacle_cliff"))
        list.addAll(wall(120f, 1700f, 1200f, 1700f, "obstacle_cliff"))
        list.addAll(wall(1520f, 1700f, 2440f, 1700f, "obstacle_cliff"))
        list.addAll(wall(1280f, 1150f, 1280f, 1450f, "obstacle_cliff"))
        list.addAll(scatter(8, 33L, 300f, 300f, 320f, "obstacle_cliff", 64f))
        return MapDef(
            id = "canyon",
            name = "Rocky Canyon",
            description = "Cliff ridges force fights through narrow choke points.",
            groundColor = Color(0.45f, 0.33f, 0.22f, 1f),
            groundDetail = Color(0.38f, 0.27f, 0.17f, 1f),
            obstacleColor = Color(0.50f, 0.33f, 0.22f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = SpawnZone(1500f, 2350f, 1850f, 2350f),
            obstacles = list
        )
    }

    private fun urban(): MapDef {
        val list = mutableListOf<ObstacleDef>()
        val coords = floatArrayOf(700f, 1180f, 1660f, 2140f)
        for (cx in coords) {
            for (cy in coords) {
                list.add(ObstacleDef(cx, cy, 192f, 192f, "obstacle_building"))
            }
        }
        list.addAll(scatter(14, 21L, 300f, 300f, 320f, "obstacle_rubble", 64f))
        return MapDef(
            id = "urban",
            name = "Urban Ruins",
            description = "Ruined city blocks. Fight street by street.",
            groundColor = Color(0.27f, 0.28f, 0.29f, 1f),
            groundDetail = Color(0.22f, 0.23f, 0.24f, 1f),
            obstacleColor = Color(0.40f, 0.36f, 0.34f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = SpawnZone(1850f, 2400f, 1850f, 2400f),
            obstacles = list
        )
    }

    private fun desert(): MapDef {
        val list = mutableListOf<ObstacleDef>()
        list.addAll(scatter(26, 51L, 300f, 300f, 340f, "obstacle_sandrock", 64f))
        list.addAll(scatter(8, 52L, 300f, 300f, 340f, "obstacle_rubble", 64f))
        list.addAll(wall(900f, 1300f, 1700f, 1300f, "obstacle_sandrock"))
        return MapDef(
            id = "desert",
            name = "Desert Dunes",
            description = "Wide open sand with a ridge across the middle.",
            groundColor = Color(0.74f, 0.63f, 0.42f, 1f),
            groundDetail = Color(0.62f, 0.52f, 0.34f, 1f),
            obstacleColor = Color(0.70f, 0.58f, 0.38f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = SpawnZone(1600f, 2350f, 1700f, 2350f),
            obstacles = list
        )
    }

    private fun frozen(): MapDef {
        val list = mutableListOf<ObstacleDef>()
        list.addAll(scatter(36, 61L, 300f, 300f, 340f, "obstacle_pine", 56f, true))
        list.addAll(scatter(14, 62L, 300f, 300f, 340f, "obstacle_snowrock", 64f))
        return MapDef(
            id = "frozen",
            name = "Frozen Forest",
            description = "Snowy pine forest. Trees can be shot down for cover.",
            groundColor = Color(0.80f, 0.85f, 0.90f, 1f),
            groundDetail = Color(0.66f, 0.73f, 0.80f, 1f),
            obstacleColor = Color(0.15f, 0.32f, 0.24f, 1f),
            playerSpawnX = 300f,
            playerSpawnY = 300f,
            enemyZone = SpawnZone(1600f, 2350f, 1600f, 2350f),
            obstacles = list
        )
    }

    // ------------------------------------------------------------- helpers

    private fun scatter(
        count: Int,
        seed: Long,
        avoidX: Float,
        avoidY: Float,
        avoidRadius: Float,
        texture: String,
        size: Float,
        destructible: Boolean = false
    ): List<ObstacleDef> {
        val rnd = Random(seed)
        val out = mutableListOf<ObstacleDef>()
        var attempts = 0
        while (out.size < count && attempts < count * 30) {
            attempts++
            val x = 200f + rnd.nextFloat() * (GameConfig.MAP_WIDTH - 400f)
            val y = 200f + rnd.nextFloat() * (GameConfig.MAP_HEIGHT - 400f)
            val dx = x - avoidX
            val dy = y - avoidY
            if (dx * dx + dy * dy < avoidRadius * avoidRadius) continue
            out.add(ObstacleDef(x, y, size, size, texture, destructible))
        }
        return out
    }

    private fun wall(x1: Float, y1: Float, x2: Float, y2: Float, texture: String): List<ObstacleDef> {
        val step = 64f
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        val n = ceil(len / step).toInt().coerceAtLeast(1)
        val out = mutableListOf<ObstacleDef>()
        for (i in 0..n) {
            val t = i.toFloat() / n.toFloat()
            out.add(ObstacleDef(x1 + dx * t, y1 + dy * t, step, step, texture))
        }
        return out
    }
}
