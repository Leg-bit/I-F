package com.ironfront.core

import com.ironfront.economy.CurrencyWallet
import com.ironfront.maps.LobbySettings
import com.ironfront.missions.Mission
import com.ironfront.missions.MissionRegistry
import com.ironfront.progression.PlayerProfile
import com.ironfront.research.TechTreeManager
import com.ironfront.tanks.TankDatabase

object GameManager {
    lateinit var playerProfile: PlayerProfile
    lateinit var wallet: CurrencyWallet
    lateinit var techTree: TechTreeManager
    var selectedTankId: String = "t26"
    var activeMission: Mission? = null
    val lobby = LobbySettings()

    fun init() {
        TankDatabase.load()
        MissionRegistry.load()
        playerProfile = PlayerProfile()
        wallet = CurrencyWallet(credits = 15000, gold = 150)
        techTree = TechTreeManager()
        // Every nation starts with its first tank (no parents, free).
        TankDatabase.all().filter { it.parents.isEmpty() }.forEach { techTree.unlockTank(it.id) }
        activeMission = MissionRegistry.getMission("mission_01")
    }
}
