package com.ironfront.core

import com.ironfront.economy.CurrencyWallet
import com.ironfront.equipment.EquipmentType
import com.ironfront.maps.LobbySettings
import com.ironfront.missions.Mission
import com.ironfront.missions.MissionRegistry
import com.ironfront.progression.PlayerProfile
import com.ironfront.research.TechTreeManager
import com.ironfront.tanks.TankDatabase

object GameManager {
    lateinit var playerProfile: PlayerProfile
    lateinit var wallet: CurrencyWallet
    lateinit var techTree: TechTreeManager
    var selectedTankId: String = "t34_76"
    var activeMission: Mission? = null
    val lobby = LobbySettings()

    val ownedEquipment = mutableSetOf<EquipmentType>()
    val equippedEquipment = mutableListOf<EquipmentType>()
    var lastDailyClaimMs: Long = 0L

    /** Daily Combat Contract: destroy 5 enemy tanks. Resets every day. */
    var dailyContractKills: Int = 0
    var dailyContractClaimed: Boolean = false
    var dailyContractDay: Long = 0L

    /** Daily login streak (1..7) for the supply drop on the exchange screen. */
    var loginStreak: Int = 0
    var lastLoginDay: Long = 0L

    /** true: the move stick points where the tank should go. false: classic tank sticks (up = forward, sideways = turn). */
    var controlDirect: Boolean = true

    fun today(): Long = System.currentTimeMillis() / 86_400_000L

    /** Starts a fresh daily contract when a new day has begun. */
    fun refreshDailyContract() {
        val t = today()
        if (dailyContractDay != t) {
            dailyContractDay = t
            dailyContractKills = 0
            dailyContractClaimed = false
        }
    }

    fun init() {
        TankDatabase.load()
        MissionRegistry.load()
        playerProfile = PlayerProfile()
        wallet = CurrencyWallet(credits = 15000, gold = 150)
        techTree = TechTreeManager()
        techTree.unlockTank("t26")
        techTree.unlockTank("bt7")
        techTree.unlockTank("t34_76")
        selectedTankId = "t34_76"
        activeMission = MissionRegistry.getMission("mission_01")
    }
}
