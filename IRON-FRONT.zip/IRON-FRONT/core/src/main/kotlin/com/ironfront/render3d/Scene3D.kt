package com.ironfront.render3d

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.Environment
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelBatch
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.BoxShapeBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.ConeShapeBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.CylinderShapeBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.SphereShapeBuilder
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import com.ironfront.art.shade
import com.ironfront.battlefield.BattlefieldWorld
import com.ironfront.core.AssetManager
import com.ironfront.entities.ObstacleEntity
import com.ironfront.maps.ObstacleKind
import com.ironfront.tanks.TankEntity
import com.ironfront.tanks.TankSpec
import com.ironfront.tanks.TurretShape
import com.ironfront.teams.Team
import com.ironfront.weapons.AmmoType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 3D view of the battle. The game itself still runs on the flat 2D map: a tank at (x, y) is drawn at
 * 3D position (x, 0, -y), so screen-up is north and the controls are unchanged. Models are built in code
 * from the real tank dimensions (hull, tracks, wheels, turret, barrel) and the painted top-down sprite is
 * used as the roof texture of the hull.
 */
class Scene3D(private val world: BattlefieldWorld) {
    val camera = PerspectiveCamera(50f, 1280f, 720f)

    private val modelBatch = ModelBatch()
    private val env = Environment()
    private val builder = ModelBuilder()
    private val models = ArrayList<Model>()
    private val tmp = Matrix4()
    private val vec = Vector3()

    private val usageNT: Long = (Usage.Position or Usage.Normal).toLong()
    private val usageNTT: Long = (Usage.Position or Usage.Normal or Usage.TextureCoordinates).toLong()

    private class Item(val obstacle: ObstacleEntity, val parts: List<ModelInstance>, val radius: Float, val x: Float, val z: Float)

    private class TankModel(val hull: Model, val turret: Model, val turretBase: Float)

    private class TankInst(val hull: ModelInstance, val turret: ModelInstance, val ring: ModelInstance, val model: TankModel) {
        var darkened = false
    }

    private val items = ArrayList<Item>()
    private val tankModels = HashMap<String, TankModel>()
    private val tankInsts = HashMap<String, TankInst>()
    private val modelCache = HashMap<String, Model>()
    private val shellInsts = ArrayList<ModelInstance>()

    private val groundInst: ModelInstance
    private val ringModel: Model
    private val shellModel: Model

    init {
        env.set(ColorAttribute(ColorAttribute.AmbientLight, 0.50f, 0.52f, 0.56f, 1f))
        env.add(DirectionalLight().set(0.78f, 0.74f, 0.66f, -0.45f, -1.0f, -0.55f))

        // ground: the map's ground tile repeated 40 x 40 times
        val gtex = AssetManager.getTexture("ground_" + world.map.id + "_0")
        gtex.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat)
        val gm = texMat(gtex, false)
        val ta = gm.get(TextureAttribute::class.java, TextureAttribute.Diffuse)
        if (ta != null) {
            ta.scaleU = 40f
            ta.scaleV = 40f
        }
        val groundModel = keep(builder.createBox(2560f, 6f, 2560f, gm, usageNTT))
        groundInst = ModelInstance(groundModel)
        groundInst.transform.idt().translate(1280f, -3f, -1280f)

        ringModel = keep(
            builder.createCylinder(
                1f, 1f, 1f, 24,
                Material(ColorAttribute.createDiffuse(Color.WHITE), BlendingAttribute(0.5f)), usageNT
            )
        )
        shellModel = keep(
            builder.createSphere(
                1f, 1f, 1f, 8, 6,
                Material(ColorAttribute.createDiffuse(Color.WHITE), ColorAttribute.createEmissive(Color.WHITE)), usageNT
            )
        )

        for (o in world.obstacles) buildStatic(o)
    }

    private fun keep(m: Model): Model {
        models.add(m)
        return m
    }

    // ------------------------------------------------------------------ materials

    private fun paintMat(c: Color): Material = Material(ColorAttribute.createDiffuse(c))

    private fun texMat(tex: Texture, blend: Boolean): Material {
        val m = Material(TextureAttribute.createDiffuse(tex), ColorAttribute.createDiffuse(Color.WHITE))
        if (blend) m.set(BlendingAttribute(true, GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA, 1f))
        return m
    }

    private fun setDiffuse(inst: ModelInstance, c: Color) {
        for (i in 0 until inst.materials.size) {
            val attr = inst.materials.get(i).get(ColorAttribute::class.java, ColorAttribute.Diffuse)
            if (attr != null) attr.color.set(c)
        }
    }

    private fun setEmissive(inst: ModelInstance, c: Color) {
        for (i in 0 until inst.materials.size) {
            val attr = inst.materials.get(i).get(ColorAttribute::class.java, ColorAttribute.Emissive)
            if (attr != null) attr.color.set(c)
        }
    }

    // ------------------------------------------------------------ shape helpers

    private fun box(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        BoxShapeBuilder.build(p, w, h, d)
    }

    private fun cyl(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float, div: Int) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        CylinderShapeBuilder.build(p, w, h, d, div)
    }

    private fun cone(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float, div: Int) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        ConeShapeBuilder.build(p, w, h, d, div)
    }

    private fun sphere(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        SphereShapeBuilder.build(p, w, h, d, 12, 9)
    }

    /** Cylinder lying along the x axis (gun barrels). */
    private fun cylAxisX(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, length: Float, radius: Float) {
        tmp.setToTranslation(cx, cy, cz).rotate(Vector3.Z, 90f)
        p.setVertexTransform(tmp)
        CylinderShapeBuilder.build(p, radius * 2f, length, radius * 2f, 10)
    }

    /** Cylinder lying along the z axis (road wheels). */
    private fun cylAxisZ(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, thickness: Float, radius: Float) {
        tmp.setToTranslation(cx, cy, cz).rotate(Vector3.X, 90f)
        p.setVertexTransform(tmp)
        CylinderShapeBuilder.build(p, radius * 2f, thickness, radius * 2f, 12)
    }

    // ------------------------------------------------------------------ tanks

    private fun tankModel(spec: TankSpec): TankModel = tankModels.getOrPut(spec.id) {
        TankModel(keep(buildHull(spec)), keep(buildTurret(spec)), turretBase(spec))
    }

    private fun hullHeight(spec: TankSpec): Float = (spec.design.hullWidPx * 0.42f).coerceIn(15f, 26f)

    private fun casemateHeight(spec: TankSpec): Float = spec.design.hullWidPx * 0.30f

    private fun turretBase(spec: TankSpec): Float {
        val h = hullHeight(spec)
        return if (spec.design.casemate) h + casemateHeight(spec) * 0.35f else h
    }

    private fun buildHull(spec: TankSpec): Model {
        val d = spec.design
        val l = d.hullLenPx.toFloat()
        val w = d.hullWidPx.toFloat()
        val tw = d.trackWidPx.toFloat()
        val hullH = hullHeight(spec)
        val trackH = hullH * 0.95f
        val paint = shade(d.paint.body, 0.92f)
        val tracksCol = Color(0.10f, 0.10f, 0.11f, 1f)
        val wheelCol = Color(0.19f, 0.19f, 0.20f, 1f)
        val deckTex = AssetManager.getTexture("hull_" + spec.id)

        builder.begin()
        builder.node()

        var p = builder.part("body", GL20.GL_TRIANGLES, usageNT, paintMat(paint))
        box(p, 0f, hullH * 0.5f, 0f, l * 0.98f, hullH, w - 2f * tw)
        if (d.casemate) {
            val ch = casemateHeight(spec)
            box(p, l * 0.05f, hullH + ch * 0.5f, 0f, l * 0.64f, ch, w - 2f * tw - 6f)
        }
        if (d.skirts) {
            val sh = trackH * 0.9f
            box(p, l * 0.03f, sh * 0.5f + 1f, w / 2f + 0.8f, l * 0.68f, sh, 2f)
            box(p, l * 0.03f, sh * 0.5f + 1f, -w / 2f - 0.8f, l * 0.68f, sh, 2f)
        }

        p = builder.part("tracks", GL20.GL_TRIANGLES, usageNT, paintMat(tracksCol))
        val zt = w / 2f - tw / 2f
        box(p, 0f, trackH * 0.5f, zt, l, trackH, tw)
        box(p, 0f, trackH * 0.5f, -zt, l, trackH, tw)

        p = builder.part("wheels", GL20.GL_TRIANGLES, usageNT, paintMat(wheelCol))
        val wr = trackH * 0.52f
        val n = max(4, (l / (wr * 2.1f)).toInt())
        for (i in 0 until n) {
            val cx = -l / 2f + wr + (l - 2f * wr) * i / (n - 1)
            cylAxisZ(p, cx, wr, w / 2f + 0.9f, 2.2f, wr)
            cylAxisZ(p, cx, wr, -w / 2f - 0.9f, 2.2f, wr)
        }

        // roof: the painted top-down sprite lies on top of the hull (grille, insignia, camouflage)
        p = builder.part("deck", GL20.GL_TRIANGLES, usageNTT, texMat(deckTex, true))
        p.setVertexTransform(null)
        val hx = deckTex.width / 2f
        val hz = deckTex.height / 2f
        val y = hullH + 0.6f
        p.rect(Vector3(-hx, y, hz), Vector3(hx, y, hz), Vector3(hx, y, -hz), Vector3(-hx, y, -hz), Vector3(0f, 1f, 0f))

        return builder.end()
    }

    private fun buildTurret(spec: TankSpec): Model {
        val d = spec.design
        val rx = d.turretRxPx.toFloat()
        val ry = d.turretRyPx.toFloat()
        val mount = d.turretShape == TurretShape.MOUNT
        val tH = if (mount) 8f else (ry * 0.78f).coerceIn(9f, 21f)
        val paint = shade(d.paint.body, 1.05f)
        val darkPaint = shade(d.paint.body, 0.6f)
        val steel = Color(0.22f, 0.22f, 0.24f, 1f)

        builder.begin()
        builder.node()

        var p = builder.part("turret", GL20.GL_TRIANGLES, usageNT, paintMat(paint))
        when (d.turretShape) {
            TurretShape.ROUND, TurretShape.CAST, TurretShape.FLAT_CAST -> cyl(p, 0f, tH / 2f, 0f, rx * 2f, tH, ry * 2f, 20)
            TurretShape.OCTAGON -> cyl(p, 0f, tH / 2f, 0f, rx * 2f, tH, ry * 2f, 8)
            TurretShape.BOX, TurretShape.ANGULAR -> box(p, 0f, tH / 2f, 0f, rx * 2f, tH, ry * 2f)
            TurretShape.MOUNT -> cyl(p, 0f, tH / 2f, 0f, 9f, tH, 9f, 12)
        }
        if (d.bustlePx > 0 && !mount) {
            box(p, -(rx + d.bustlePx / 2f - 2f), tH * 0.45f, 0f, d.bustlePx + 4f, tH * 0.8f, ry * 1.35f)
        }

        p = builder.part("detail", GL20.GL_TRIANGLES, usageNT, paintMat(darkPaint))
        if (!mount) {
            if (d.cupola) cyl(p, -rx * 0.25f, tH + 2.5f, ry * 0.45f, max(6f, ry * 0.52f), 5f, max(6f, ry * 0.52f), 10)
            box(p, -rx * 0.30f, tH + 1.2f, -ry * 0.5f, max(5f, rx * 0.30f), 2.4f, max(5f, ry * 0.30f))
        }

        p = builder.part("steel", GL20.GL_TRIANGLES, usageNT, paintMat(steel))
        val by = if (mount) tH * 0.5f else tH * 0.62f
        val len = d.barrelPx.toFloat()
        val radius = max(1.6f, d.barrelThickPx / 2f + 0.5f)
        cylAxisX(p, rx - 1f + len / 2f, by, 0f, len, radius)
        if (d.muzzleLenPx > 0) {
            val ml = d.muzzleLenPx.toFloat()
            box(p, rx + len - ml / 2f, by, 0f, ml, radius * 2f + 3f, radius * 2f + 3f)
        }
        box(p, rx - 1f, by, 0f, 5f, min(tH * 0.9f, d.mantletPx * 0.7f), d.mantletPx.toFloat())

        return builder.end()
    }

    private fun createTankInst(spec: TankSpec, team: Team?): TankInst {
        val tm = tankModel(spec)
        val ring = ModelInstance(ringModel)
        if (team != null) setDiffuse(ring, team.outline)
        return TankInst(ModelInstance(tm.hull), ModelInstance(tm.turret), ring, tm)
    }

    // ---------------------------------------------------------------- statics

    private fun cached(key: String, create: () -> Model): Model = modelCache.getOrPut(key) { keep(create()) }

    private fun boxHeight(o: ObstacleEntity): Float = when {
        o.textureKey.startsWith("obstacle_wall") -> 46f
        o.textureKey.startsWith("obstacle_sandbag") -> 20f
        o.textureKey == "obstacle_cliff" -> 55f + (abs((o.position.x * 7f + o.position.y * 13f).toInt()) % 40)
        else -> 30f
    }

    private fun rockColor(key: String): Color = when (key) {
        "obstacle_sandrock" -> Color(0.70f, 0.58f, 0.40f, 1f)
        "obstacle_snowrock" -> Color(0.80f, 0.85f, 0.92f, 1f)
        "obstacle_debris" -> Color(0.45f, 0.38f, 0.32f, 1f)
        "obstacle_hedgehog" -> Color(0.25f, 0.26f, 0.28f, 1f)
        else -> Color(0.45f, 0.45f, 0.48f, 1f)
    }

    private fun treeModel(key: String): Model = cached("tree_$key") {
        builder.begin()
        builder.node()
        var p = builder.part("trunk", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.30f, 0.20f, 0.12f, 1f)))
        cyl(p, 0f, 0.22f, 0f, 0.14f, 0.44f, 0.14f, 8)
        when (key) {
            "obstacle_pine" -> {
                p = builder.part("needles", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.10f, 0.30f, 0.20f, 1f)))
                cone(p, 0f, 0.62f, 0f, 0.95f, 0.50f, 0.95f, 10)
                cone(p, 0f, 0.86f, 0f, 0.72f, 0.46f, 0.72f, 10)
                cone(p, 0f, 1.08f, 0f, 0.50f, 0.42f, 0.50f, 10)
            }
            "obstacle_deadtree" -> {
                p = builder.part("branches", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.26f, 0.20f, 0.15f, 1f)))
                box(p, 0.10f, 0.60f, 0f, 0.05f, 0.45f, 0.05f)
                box(p, -0.12f, 0.66f, 0.05f, 0.05f, 0.40f, 0.05f)
                box(p, 0.02f, 0.80f, -0.10f, 0.04f, 0.35f, 0.04f)
                box(p, 0f, 0.55f, 0f, 0.04f, 0.5f, 0.04f)
            }
            else -> {
                p = builder.part("leaves", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.20f, 0.44f, 0.16f, 1f)))
                sphere(p, 0f, 0.78f, 0f, 0.95f, 0.80f, 0.95f)
            }
        }
        builder.end()
    }

    private fun sphereModel(key: String, c: Color, divU: Int, divV: Int): Model = cached("sphere_$key") {
        builder.createSphere(1f, 1f, 1f, divU, divV, paintMat(c), usageNT)
    }

    private fun texturedBox(key: String, thickness: Float): Model = cached("box_${key}_$thickness") {
        builder.createBox(1f, thickness, 1f, texMat(AssetManager.getTexture(key), true), usageNTT)
    }

    private fun buildStatic(o: ObstacleEntity) {
        val x = o.position.x
        val z = -o.position.y
        val d = o.def
        val parts = ArrayList<ModelInstance>()
        var radius = max(o.width, o.height) * 0.75f

        when (o.kind) {
            ObstacleKind.BOX -> {
                val h = boxHeight(o)
                val m = cached("solid_" + o.textureKey) {
                    builder.createBox(1f, 1f, 1f, texMat(AssetManager.getTexture(o.textureKey), true), usageNTT)
                }
                val inst = ModelInstance(m)
                inst.transform.idt().translate(x, h / 2f, z).scale(o.width, h, o.height)
                parts.add(inst)
            }
            ObstacleKind.ROCK -> {
                val flat = o.textureKey == "obstacle_hedgehog"
                val m = if (flat) sphereModel("hedgehog", rockColor(o.textureKey), 5, 4)
                else sphereModel(o.textureKey, rockColor(o.textureKey), 12, 9)
                val s = d.w
                val inst = ModelInstance(m)
                inst.transform.idt().translate(x, s * (if (flat) 0.3f else 0.22f), z)
                    .rotate(Vector3.Y, d.rotation).scale(s, s * (if (flat) 0.6f else 0.55f), s)
                parts.add(inst)
                radius = s
            }
            ObstacleKind.TRUNK -> {
                val inst = ModelInstance(treeModel(o.textureKey))
                val s = d.w * 1.05f
                inst.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, d.rotation).scale(s, s, s)
                parts.add(inst)
                radius = s
            }
            ObstacleKind.BUSH -> {
                val inst = ModelInstance(sphereModel("bush", Color(0.19f, 0.36f, 0.15f, 1f), 12, 8))
                inst.transform.idt().translate(x, d.w * 0.18f, z).rotate(Vector3.Y, d.rotation)
                    .scale(d.w * 0.95f, d.w * 0.42f, d.w * 0.8f)
                parts.add(inst)
                radius = d.w
            }
            ObstacleKind.DECOR, ObstacleKind.SWAMP -> {
                val lift = if (o.kind == ObstacleKind.SWAMP) 0.45f else 0.25f
                val inst = ModelInstance(texturedBox(o.textureKey, 0.3f))
                inst.transform.idt().translate(x, lift, z).rotate(Vector3.Y, d.rotation).scale(d.w, 1f, d.h)
                parts.add(inst)
            }
            ObstacleKind.WRECK -> {
                if (!AssetManager.hasTexture("hull_" + d.tankId)) return
                val spec = com.ironfront.tanks.TankDatabase.get(d.tankId)
                val tm = tankModel(spec)
                val hull = ModelInstance(tm.hull)
                val turret = ModelInstance(tm.turret)
                hull.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, d.rotation)
                turret.transform.idt().translate(x, tm.turretBase, z).rotate(Vector3.Y, d.rotation + 40f)
                val burnt = Color(0.16f, 0.14f, 0.13f, 1f)
                setDiffuse(hull, burnt)
                setDiffuse(turret, burnt)
                parts.add(hull)
                parts.add(turret)
                radius = 70f
            }
        }
        items.add(Item(o, parts, radius, x, z))
    }

    // ----------------------------------------------------------------- render

    /** Draws the 3D world. [camX]/[camY] are the 2D map coordinates the camera looks at. */
    fun render(camX: Float, camY: Float, shake: Float) {
        val sx = if (shake > 0.2f) MathUtils.random(-shake, shake) else 0f
        val sz = if (shake > 0.2f) MathUtils.random(-shake, shake) else 0f
        camera.position.set(camX + sx, CAM_HEIGHT, -camY + CAM_BACK + sz)
        camera.lookAt(camX, 0f, -camY)
        camera.near = 30f
        camera.far = 4200f
        camera.update()

        modelBatch.begin(camera)
        modelBatch.render(groundInst, env)

        for (item in items) {
            if (!item.obstacle.isAlive) continue
            if (abs(item.x - camX) > 1100f || abs(item.z + camY) > 900f) continue
            if (!camera.frustum.sphereInFrustum(item.x, 20f, item.z, item.radius)) continue
            for (inst in item.parts) modelBatch.render(inst, env)
        }

        for (t in world.tanks) renderTank(t)
        renderShells()

        modelBatch.end()
    }

    private fun renderTank(t: TankEntity) {
        if (!t.isAlive && t.wreckTime <= 0f) return
        if (!world.vision.isSpotted(t)) return
        val x = t.position.x
        val z = -t.position.y
        if (!camera.frustum.sphereInFrustum(x, 15f, z, 110f)) return

        val inst = tankInsts.getOrPut(t.id) { createTankInst(t.spec, t.team) }
        val l = t.spec.design.hullLenPx.toFloat()
        val w = t.spec.design.hullWidPx.toFloat()

        inst.hull.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, t.rotation)
        val rec = t.recoilPx
        val tx = t.turretX - MathUtils.cosDeg(t.turretRotation) * rec
        val ty = t.turretY - MathUtils.sinDeg(t.turretRotation) * rec
        val extraYaw = if (t.isAlive) 0f else t.wreckTurretOffset
        inst.turret.transform.idt().translate(tx, inst.model.turretBase, -ty).rotate(Vector3.Y, t.turretRotation + extraYaw)

        if (!t.isAlive && !inst.darkened) {
            val burnt = Color(0.17f, 0.15f, 0.14f, 1f)
            setDiffuse(inst.hull, burnt)
            setDiffuse(inst.turret, burnt)
            inst.darkened = true
        }

        modelBatch.render(inst.hull, env)
        modelBatch.render(inst.turret, env)
        if (t.isAlive) {
            inst.ring.transform.idt().translate(x, 0.6f, z).rotate(Vector3.Y, t.rotation).scale(l * 1.18f, 1f, w * 1.5f)
            modelBatch.render(inst.ring, env)
        }
    }

    private fun renderShells() {
        var n = 0
        for (p in world.projectiles) {
            if (p.team != Team.FRIEND && world.vision.lit(p.position.x, p.position.y, world.friendsOf()) < 0.25f) continue
            if (n >= shellInsts.size) shellInsts.add(ModelInstance(shellModel))
            val inst = shellInsts[n]
            n++
            val len = 9f + p.caliberMm * 0.10f
            val th = 3f + p.caliberMm * 0.04f
            inst.transform.idt().translate(p.position.x, 17f, -p.position.y).rotate(Vector3.Y, p.rotation).scale(len, th, th)
            val c = if (p.ammoType == AmmoType.AP || p.ammoType == AmmoType.APCR || p.ammoType == AmmoType.HE) p.ammoType.color else Color.WHITE
            setDiffuse(inst, c)
            setEmissive(inst, c)
            modelBatch.render(inst, env)
        }
    }

    // ---------------------------------------------------------------- overlays

    /** Converts a map position (and a height above the ground) to HUD coordinates. Returns false when off screen. */
    private fun project(x: Float, y: Float, h: Float, out: Vector3): Boolean {
        out.set(x, h, -y).prj(camera.combined)
        if (out.z > 1f) return false
        out.x = (out.x * 0.5f + 0.5f) * 1280f
        out.y = (out.y * 0.5f + 0.5f) * 720f
        return out.x > -120f && out.x < 1400f && out.y > -120f && out.y < 840f
    }

    /** Particles, fog / spotlight, health bars and floating texts, drawn in HUD space after the 3D pass. */
    fun drawOverlays(batch: SpriteBatch) {
        world.fx.renderProjected(batch, camera.combined, 12f)

        val count = world.collectLights()
        world.vision.render3D(batch, camera, world.friendsOf(), world.lightArray, count)

        val pixel = AssetManager.getTexture("pixel")
        val font = AssetManager.fontSmall
        for (t in world.tanks) {
            if (!t.isAlive || !t.showHealthBar) continue
            if (!world.vision.isSpotted(t)) continue
            if (!project(t.position.x, t.position.y, 46f, vec)) continue
            val bw = 58f
            val ratio = (t.currentHp / t.maxHealth).coerceIn(0f, 1f)
            batch.setColor(0f, 0f, 0f, 0.65f)
            batch.draw(pixel, vec.x - bw / 2f - 1f, vec.y - 1f, bw + 2f, 7f)
            batch.setColor(t.team.outline.r, t.team.outline.g, t.team.outline.b, 1f)
            batch.draw(pixel, vec.x - bw / 2f, vec.y, bw * ratio, 5f)
            batch.setColor(1f, 1f, 1f, 1f)
            val label = if (t.playerControlled) "YOU" else "T" + t.spec.tier + " " + t.spec.shortName
            font.color = t.team.outline
            font.draw(batch, label, vec.x - bw / 2f, vec.y + 24f)
            font.color = Color.WHITE
        }

        for (msg in world.floatingMessages) {
            if (world.vision.lit(msg.x, msg.y, world.friendsOf()) < 0.2f) continue
            if (!project(msg.x, msg.y, 40f, vec)) continue
            font.draw(batch, msg.text, vec.x - 36f, vec.y)
        }
    }

    fun dispose() {
        modelBatch.dispose()
        for (m in models) m.dispose()
        models.clear()
    }

    companion object {
        private const val CAM_HEIGHT = 560f
        private const val CAM_BACK = 310f
    }
}
