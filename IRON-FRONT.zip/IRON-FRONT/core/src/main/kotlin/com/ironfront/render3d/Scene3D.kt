package com.ironfront.render3d

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.Environment
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelBatch
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.BlendingAttribute
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight
import com.badlogic.gdx.graphics.g3d.environment.DirectionalShadowLight
import com.badlogic.gdx.graphics.g3d.utils.DepthShaderProvider
import com.badlogic.gdx.graphics.g3d.utils.MeshPartBuilder
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.BoxShapeBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.ConeShapeBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.CylinderShapeBuilder
import com.badlogic.gdx.graphics.g3d.utils.shapebuilders.SphereShapeBuilder
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import com.ironfront.art.shade
import com.ironfront.battlefield.BattlefieldWorld
import com.ironfront.core.AssetManager
import com.ironfront.entities.ObstacleEntity
import com.ironfront.maps.ObstacleKind
import com.ironfront.tanks.TankEntity
import com.ironfront.tanks.TankSpec
import com.ironfront.tanks.TurretShape
import com.ironfront.teams.Team
import com.ironfront.weapons.AmmoType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 3D view of the battle. The game itself still runs on the flat 2D map: a tank at (x, y) is drawn at
 * 3D position (x, 0, -y), so screen-up is north and the controls are unchanged. Models are built in code
 * from the real tank dimensions (hull, tracks, wheels, turret, barrel) and the painted top-down sprite is
 * used as the roof texture of the hull.
 */
class Scene3D(
    private val world: BattlefieldWorld,
    private val player: TankEntity,
    private val quality: Int
) {
    val camera = PerspectiveCamera(50f, 1280f, 720f)

    private val modelBatch = ModelBatch()
    private val env = Environment()
    private val builder = ModelBuilder()
    private val models = ArrayList<Model>()
    private val tmp = Matrix4()
    private val vec = Vector3()
    private val vec2 = Vector3()

    private val usageNT: Long = (Usage.Position or Usage.Normal).toLong()
    private val usageNTT: Long = (Usage.Position or Usage.Normal or Usage.TextureCoordinates).toLong()

    private class Item(
        val obstacle: ObstacleEntity,
        val parts: List<ModelInstance>,
        val blob: ModelInstance?,
        val radius: Float,
        val x: Float,
        val z: Float,
        val casts: Boolean
    )

    private class TankModel(val hull: Model, val turret: Model, val turretBase: Float)

    private class TankInst(
        val hull: ModelInstance,
        val turret: ModelInstance,
        val ring: ModelInstance,
        val blob: ModelInstance,
        val model: TankModel
    ) {
        var darkened = false
    }

    private val items = ArrayList<Item>()
    private val tankModels = HashMap<String, TankModel>()
    private val tankInsts = HashMap<String, TankInst>()
    private val modelCache = HashMap<String, Model>()
    private val shellInsts = ArrayList<ModelInstance>()
    private val visibleTanks = ArrayList<Pair<TankEntity, TankInst>>()

    private val groundInst: ModelInstance
    private val mountainInst: ModelInstance
    private val ringModel: Model
    private val shellModel: Model
    private val blobModel: Model

    // sky colours of the current map: top of the sky and the haze at the horizon (also the fog colour)
    private val skyTop = Color(0.40f, 0.58f, 0.85f, 1f)
    private val skyHorizon = Color(0.74f, 0.82f, 0.90f, 1f)

    private var shadowLight: DirectionalShadowLight? = null
    private var shadowBatch: ModelBatch? = null
    private val sunDir = Vector3(-0.45f, -1.0f, -0.55f).nor()
    private val shadowCenter = Vector3()

    var mode = MODE_CHASE
        private set

    private var focusX = 0f
    private var focusY = 0f

    init {
        configureMap()

        env.set(ColorAttribute(ColorAttribute.AmbientLight, 0.50f, 0.52f, 0.56f, 1f))
        env.set(ColorAttribute(ColorAttribute.Fog, skyHorizon.r, skyHorizon.g, skyHorizon.b, 1f))
        if (quality >= 2) {
            try {
                val sl = DirectionalShadowLight(1024, 1024, 560f, 560f, 1f, 900f)
                sl.set(0.78f, 0.74f, 0.66f, sunDir.x, sunDir.y, sunDir.z)
                env.add(sl)
                env.shadowMap = sl
                shadowLight = sl
                shadowBatch = ModelBatch(DepthShaderProvider())
            } catch (e: Exception) {
                shadowLight = null
                shadowBatch = null
            }
        }
        if (shadowLight == null) {
            env.add(DirectionalLight().set(0.78f, 0.74f, 0.66f, sunDir.x, sunDir.y, sunDir.z))
        }

        // ground: the map's ground tile repeated over a huge plane so that the horizon is covered
        val gtex = AssetManager.getTexture("ground_" + world.map.id + "_0")
        gtex.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat)
        val gm = texMat(gtex, false)
        val ta = gm.get(TextureAttribute::class.java, TextureAttribute.Diffuse)
        if (ta != null) {
            ta.scaleU = 140f
            ta.scaleV = 140f
        }
        val groundModel = keep(builder.createBox(9000f, 6f, 9000f, gm, usageNTT))
        groundInst = ModelInstance(groundModel)
        groundInst.transform.idt().translate(1280f, -3f, -1280f)

        mountainInst = ModelInstance(keep(buildMountains()))

        ringModel = keep(
            builder.createCylinder(
                1f, 1f, 1f, 24,
                Material(ColorAttribute.createDiffuse(Color.WHITE), BlendingAttribute(0.5f)), usageNT
            )
        )
        blobModel = keep(
            builder.createCylinder(
                1f, 0.2f, 1f, 20,
                Material(ColorAttribute.createDiffuse(Color.BLACK), BlendingAttribute(0.40f)), usageNT
            )
        )
        shellModel = keep(
            builder.createSphere(
                1f, 1f, 1f, 8, 6,
                Material(ColorAttribute.createDiffuse(Color.WHITE), ColorAttribute.createEmissive(Color.WHITE)), usageNT
            )
        )

        for (o in world.obstacles) buildStatic(o)
    }

    private fun configureMap() {
        when (world.map.id) {
            "steppe" -> { skyTop.set(Color(0.36f, 0.55f, 0.86f, 1f)); skyHorizon.set(Color(0.76f, 0.83f, 0.88f, 1f)) }
            "canyon" -> { skyTop.set(Color(0.45f, 0.58f, 0.80f, 1f)); skyHorizon.set(Color(0.88f, 0.78f, 0.66f, 1f)) }
            "urban" -> { skyTop.set(Color(0.40f, 0.45f, 0.52f, 1f)); skyHorizon.set(Color(0.66f, 0.68f, 0.70f, 1f)) }
            "desert" -> { skyTop.set(Color(0.42f, 0.62f, 0.90f, 1f)); skyHorizon.set(Color(0.92f, 0.84f, 0.66f, 1f)) }
            else -> { skyTop.set(Color(0.55f, 0.70f, 0.90f, 1f)); skyHorizon.set(Color(0.88f, 0.92f, 0.96f, 1f)) }
        }
    }

    private fun mountainColor(): Color = when (world.map.id) {
        "steppe" -> Color(0.34f, 0.42f, 0.40f, 1f)
        "canyon" -> Color(0.56f, 0.38f, 0.28f, 1f)
        "urban" -> Color(0.34f, 0.36f, 0.40f, 1f)
        "desert" -> Color(0.74f, 0.62f, 0.44f, 1f)
        else -> Color(0.82f, 0.88f, 0.94f, 1f)
    }

    /** A ring of low-poly mountains far outside the map: one single draw call. */
    private fun buildMountains(): Model {
        builder.begin()
        builder.node()
        val p = builder.part("mountains", GL20.GL_TRIANGLES, usageNT, paintMat(mountainColor()))
        val rnd = java.util.Random(77L)
        val n = 30
        for (i in 0 until n) {
            val ang = Math.toRadians((i * 360.0 / n) + rnd.nextInt(8))
            val r = 3100.0 + rnd.nextInt(600)
            val w = 700f + rnd.nextInt(600)
            val h = 380f + rnd.nextInt(480)
            val cx = 1280f + (Math.cos(ang) * r).toFloat()
            val cz = -1280f + (Math.sin(ang) * r).toFloat()
            cone(p, cx, h / 2f, cz, w, h, w, 7)
        }
        return builder.end()
    }

    private fun keep(m: Model): Model {
        models.add(m)
        return m
    }

    // ------------------------------------------------------------------ materials

    private fun paintMat(c: Color): Material = Material(ColorAttribute.createDiffuse(c))

    private fun texMat(tex: Texture, blend: Boolean): Material {
        val m = Material(TextureAttribute.createDiffuse(tex), ColorAttribute.createDiffuse(Color.WHITE))
        if (blend) m.set(BlendingAttribute(true, GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA, 1f))
        return m
    }

    private fun setDiffuse(inst: ModelInstance, c: Color) {
        for (i in 0 until inst.materials.size) {
            val attr = inst.materials.get(i).get(ColorAttribute::class.java, ColorAttribute.Diffuse)
            if (attr != null) attr.color.set(c)
        }
    }

    private fun setEmissive(inst: ModelInstance, c: Color) {
        for (i in 0 until inst.materials.size) {
            val attr = inst.materials.get(i).get(ColorAttribute::class.java, ColorAttribute.Emissive)
            if (attr != null) attr.color.set(c)
        }
    }

    // ------------------------------------------------------------ shape helpers

    private fun box(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        BoxShapeBuilder.build(p, w, h, d)
    }

    private fun cyl(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float, div: Int) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        CylinderShapeBuilder.build(p, w, h, d, div)
    }

    private fun cone(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float, div: Int) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        ConeShapeBuilder.build(p, w, h, d, div)
    }

    private fun sphere(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, w: Float, h: Float, d: Float) {
        tmp.setToTranslation(cx, cy, cz)
        p.setVertexTransform(tmp)
        SphereShapeBuilder.build(p, w, h, d, 12, 9)
    }

    /** Cylinder lying along the x axis (gun barrels). */
    private fun cylAxisX(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, length: Float, radius: Float) {
        tmp.setToTranslation(cx, cy, cz).rotate(Vector3.Z, 90f)
        p.setVertexTransform(tmp)
        CylinderShapeBuilder.build(p, radius * 2f, length, radius * 2f, 10)
    }

    /** Cylinder lying along the z axis (road wheels). */
    private fun cylAxisZ(p: MeshPartBuilder, cx: Float, cy: Float, cz: Float, thickness: Float, radius: Float) {
        tmp.setToTranslation(cx, cy, cz).rotate(Vector3.X, 90f)
        p.setVertexTransform(tmp)
        CylinderShapeBuilder.build(p, radius * 2f, thickness, radius * 2f, 12)
    }

    // ------------------------------------------------------------------ tanks

    private fun tankModel(spec: TankSpec): TankModel = tankModels.getOrPut(spec.id) {
        TankModel(keep(buildHull(spec)), keep(buildTurret(spec)), turretBase(spec))
    }

    private fun hullHeight(spec: TankSpec): Float = (spec.design.hullWidPx * 0.42f).coerceIn(15f, 26f)

    private fun casemateHeight(spec: TankSpec): Float = spec.design.hullWidPx * 0.30f

    private fun turretBase(spec: TankSpec): Float {
        val h = hullHeight(spec)
        return if (spec.design.casemate) h + casemateHeight(spec) * 0.35f else h
    }

    private fun buildHull(spec: TankSpec): Model {
        val d = spec.design
        val l = d.hullLenPx.toFloat()
        val w = d.hullWidPx.toFloat()
        val tw = d.trackWidPx.toFloat()
        val hullH = hullHeight(spec)
        val trackH = hullH * 0.95f
        val paint = shade(d.paint.body, 0.92f)
        val tracksCol = Color(0.10f, 0.10f, 0.11f, 1f)
        val wheelCol = Color(0.19f, 0.19f, 0.20f, 1f)
        val deckTex = AssetManager.getTexture("hull_" + spec.id)

        builder.begin()
        builder.node()

        var p = builder.part("body", GL20.GL_TRIANGLES, usageNT, paintMat(paint))
        box(p, 0f, hullH * 0.5f, 0f, l * 0.98f, hullH, w - 2f * tw)
        if (d.casemate) {
            val ch = casemateHeight(spec)
            box(p, l * 0.05f, hullH + ch * 0.5f, 0f, l * 0.64f, ch, w - 2f * tw - 6f)
        }
        if (d.skirts) {
            val sh = trackH * 0.9f
            box(p, l * 0.03f, sh * 0.5f + 1f, w / 2f + 0.8f, l * 0.68f, sh, 2f)
            box(p, l * 0.03f, sh * 0.5f + 1f, -w / 2f - 0.8f, l * 0.68f, sh, 2f)
        }

        p = builder.part("tracks", GL20.GL_TRIANGLES, usageNT, paintMat(tracksCol))
        val zt = w / 2f - tw / 2f
        box(p, 0f, trackH * 0.5f, zt, l, trackH, tw)
        box(p, 0f, trackH * 0.5f, -zt, l, trackH, tw)

        p = builder.part("wheels", GL20.GL_TRIANGLES, usageNT, paintMat(wheelCol))
        val wr = trackH * 0.52f
        val n = max(4, (l / (wr * 2.1f)).toInt())
        for (i in 0 until n) {
            val cx = -l / 2f + wr + (l - 2f * wr) * i / (n - 1)
            cylAxisZ(p, cx, wr, w / 2f + 0.9f, 2.2f, wr)
            cylAxisZ(p, cx, wr, -w / 2f - 0.9f, 2.2f, wr)
        }

        // hatches, tool boxes and exhaust pipes
        p = builder.part("fittings", GL20.GL_TRIANGLES, usageNT, paintMat(shade(d.paint.body, 0.7f)))
        if (!d.casemate) {
            box(p, l * 0.33f, hullH + 2.2f, -w * 0.12f, 6f, 3.2f, 7f)
            box(p, -l * 0.18f, hullH + 2.4f, w * 0.30f, l * 0.12f, 3.6f, 6f)
        }
        box(p, -l * 0.26f, hullH + 2.0f, -w * 0.30f, l * 0.10f, 3f, 6f)
        p = builder.part("exhaust", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.25f, 0.22f, 0.20f, 1f)))
        cylAxisX(p, -l / 2f - 2f, hullH * 0.55f, w * 0.24f, 7f, 2.3f)
        cylAxisX(p, -l / 2f - 2f, hullH * 0.55f, -w * 0.24f, 7f, 2.3f)

        // roof: the painted top-down sprite lies on top of the hull (grille, insignia, camouflage)
        p = builder.part("deck", GL20.GL_TRIANGLES, usageNTT, texMat(deckTex, true))
        p.setVertexTransform(null)
        val hx = deckTex.width / 2f
        val hz = deckTex.height / 2f
        val y = hullH + 0.6f
        p.rect(Vector3(-hx, y, hz), Vector3(hx, y, hz), Vector3(hx, y, -hz), Vector3(-hx, y, -hz), Vector3(0f, 1f, 0f))

        return builder.end()
    }

    private fun buildTurret(spec: TankSpec): Model {
        val d = spec.design
        val rx = d.turretRxPx.toFloat()
        val ry = d.turretRyPx.toFloat()
        val mount = d.turretShape == TurretShape.MOUNT
        val tH = if (mount) 8f else (ry * 0.78f).coerceIn(9f, 21f)
        val paint = shade(d.paint.body, 1.05f)
        val darkPaint = shade(d.paint.body, 0.6f)
        val steel = Color(0.22f, 0.22f, 0.24f, 1f)

        builder.begin()
        builder.node()

        var p = builder.part("turret", GL20.GL_TRIANGLES, usageNT, paintMat(paint))
        when (d.turretShape) {
            TurretShape.ROUND, TurretShape.CAST, TurretShape.FLAT_CAST -> cyl(p, 0f, tH / 2f, 0f, rx * 2f, tH, ry * 2f, 20)
            TurretShape.OCTAGON -> cyl(p, 0f, tH / 2f, 0f, rx * 2f, tH, ry * 2f, 8)
            TurretShape.BOX, TurretShape.ANGULAR -> box(p, 0f, tH / 2f, 0f, rx * 2f, tH, ry * 2f)
            TurretShape.MOUNT -> cyl(p, 0f, tH / 2f, 0f, 9f, tH, 9f, 12)
        }
        if (d.bustlePx > 0 && !mount) {
            box(p, -(rx + d.bustlePx / 2f - 2f), tH * 0.45f, 0f, d.bustlePx + 4f, tH * 0.8f, ry * 1.35f)
        }

        p = builder.part("detail", GL20.GL_TRIANGLES, usageNT, paintMat(darkPaint))
        if (!mount) {
            if (d.cupola) cyl(p, -rx * 0.25f, tH + 2.5f, ry * 0.45f, max(6f, ry * 0.52f), 5f, max(6f, ry * 0.52f), 10)
            box(p, -rx * 0.30f, tH + 1.2f, -ry * 0.5f, max(5f, rx * 0.30f), 2.4f, max(5f, ry * 0.30f))
        }

        p = builder.part("steel", GL20.GL_TRIANGLES, usageNT, paintMat(steel))
        val by = if (mount) tH * 0.5f else tH * 0.62f
        val len = d.barrelPx.toFloat()
        val radius = max(1.6f, d.barrelThickPx / 2f + 0.5f)
        cylAxisX(p, rx - 1f + len / 2f, by, 0f, len, radius)
        if (d.barrelThickPx >= 4) {
            cylAxisX(p, rx + len * 0.55f, by, 0f, 9f, radius + 1.4f)
        }
        if (d.muzzleLenPx > 0) {
            val ml = d.muzzleLenPx.toFloat()
            box(p, rx + len - ml / 2f, by, 0f, ml, radius * 2f + 3f, radius * 2f + 3f)
        }
        box(p, rx - 1f, by, 0f, 5f, min(tH * 0.9f, d.mantletPx * 0.7f), d.mantletPx.toFloat())

        return builder.end()
    }

    private fun createTankInst(spec: TankSpec, team: Team?): TankInst {
        val tm = tankModel(spec)
        val ring = ModelInstance(ringModel)
        if (team != null) setDiffuse(ring, team.outline)
        return TankInst(ModelInstance(tm.hull), ModelInstance(tm.turret), ring, ModelInstance(blobModel), tm)
    }

    // ---------------------------------------------------------------- statics

    private fun cached(key: String, create: () -> Model): Model = modelCache.getOrPut(key) { keep(create()) }

    private fun boxHeight(o: ObstacleEntity): Float = when {
        o.textureKey.startsWith("obstacle_wall") -> 46f
        o.textureKey.startsWith("obstacle_sandbag") -> 20f
        o.textureKey == "obstacle_cliff" -> 55f + (abs((o.position.x * 7f + o.position.y * 13f).toInt()) % 40)
        else -> 30f
    }

    private fun rockColor(key: String): Color = when (key) {
        "obstacle_sandrock" -> Color(0.70f, 0.58f, 0.40f, 1f)
        "obstacle_snowrock" -> Color(0.80f, 0.85f, 0.92f, 1f)
        "obstacle_debris" -> Color(0.45f, 0.38f, 0.32f, 1f)
        "obstacle_hedgehog" -> Color(0.25f, 0.26f, 0.28f, 1f)
        else -> Color(0.45f, 0.45f, 0.48f, 1f)
    }

    private fun treeModel(key: String): Model = cached("tree_$key") {
        builder.begin()
        builder.node()
        var p = builder.part("trunk", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.30f, 0.20f, 0.12f, 1f)))
        cyl(p, 0f, 0.22f, 0f, 0.14f, 0.44f, 0.14f, 8)
        when (key) {
            "obstacle_pine" -> {
                p = builder.part("needles", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.10f, 0.30f, 0.20f, 1f)))
                cone(p, 0f, 0.62f, 0f, 0.95f, 0.50f, 0.95f, 10)
                cone(p, 0f, 0.86f, 0f, 0.72f, 0.46f, 0.72f, 10)
                cone(p, 0f, 1.08f, 0f, 0.50f, 0.42f, 0.50f, 10)
            }
            "obstacle_deadtree" -> {
                p = builder.part("branches", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.26f, 0.20f, 0.15f, 1f)))
                box(p, 0.10f, 0.60f, 0f, 0.05f, 0.45f, 0.05f)
                box(p, -0.12f, 0.66f, 0.05f, 0.05f, 0.40f, 0.05f)
                box(p, 0.02f, 0.80f, -0.10f, 0.04f, 0.35f, 0.04f)
                box(p, 0f, 0.55f, 0f, 0.04f, 0.5f, 0.04f)
            }
            else -> {
                p = builder.part("leaves", GL20.GL_TRIANGLES, usageNT, paintMat(Color(0.20f, 0.44f, 0.16f, 1f)))
                sphere(p, 0f, 0.78f, 0f, 0.95f, 0.80f, 0.95f)
            }
        }
        builder.end()
    }

    private fun sphereModel(key: String, c: Color, divU: Int, divV: Int): Model = cached("sphere_$key") {
        builder.createSphere(1f, 1f, 1f, divU, divV, paintMat(c), usageNT)
    }

    private fun texturedBox(key: String, thickness: Float): Model = cached("box_${key}_$thickness") {
        builder.createBox(1f, thickness, 1f, texMat(AssetManager.getTexture(key), true), usageNTT)
    }

    /** Soft dark ellipse on the ground, pushed away from the sun: the cheap shadow of the medium quality. */
    private fun makeBlob(x: Float, z: Float, radius: Float, height: Float): ModelInstance {
        val inst = ModelInstance(blobModel)
        inst.transform.idt().translate(x - 0.30f * height, 0.5f, z - 0.36f * height).scale(radius * 2.2f, 1f, radius * 1.9f)
        return inst
    }

    private fun buildStatic(o: ObstacleEntity) {
        val x = o.position.x
        val z = -o.position.y
        val d = o.def
        val parts = ArrayList<ModelInstance>()
        var radius = max(o.width, o.height) * 0.75f

        when (o.kind) {
            ObstacleKind.BOX -> {
                val h = boxHeight(o)
                val m = cached("solid_" + o.textureKey) {
                    builder.createBox(1f, 1f, 1f, texMat(AssetManager.getTexture(o.textureKey), true), usageNTT)
                }
                val inst = ModelInstance(m)
                inst.transform.idt().translate(x, h / 2f, z).scale(o.width, h, o.height)
                parts.add(inst)
            }
            ObstacleKind.ROCK -> {
                val flat = o.textureKey == "obstacle_hedgehog"
                val m = if (flat) sphereModel("hedgehog", rockColor(o.textureKey), 5, 4)
                else sphereModel(o.textureKey, rockColor(o.textureKey), 12, 9)
                val s = d.w
                val inst = ModelInstance(m)
                inst.transform.idt().translate(x, s * (if (flat) 0.3f else 0.22f), z)
                    .rotate(Vector3.Y, d.rotation).scale(s, s * (if (flat) 0.6f else 0.55f), s)
                parts.add(inst)
                radius = s
            }
            ObstacleKind.TRUNK -> {
                val inst = ModelInstance(treeModel(o.textureKey))
                val s = d.w * 1.05f
                inst.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, d.rotation).scale(s, s, s)
                parts.add(inst)
                radius = s
            }
            ObstacleKind.BUSH -> {
                val inst = ModelInstance(sphereModel("bush", Color(0.19f, 0.36f, 0.15f, 1f), 12, 8))
                inst.transform.idt().translate(x, d.w * 0.18f, z).rotate(Vector3.Y, d.rotation)
                    .scale(d.w * 0.95f, d.w * 0.42f, d.w * 0.8f)
                parts.add(inst)
                radius = d.w
            }
            ObstacleKind.DECOR, ObstacleKind.SWAMP -> {
                val lift = if (o.kind == ObstacleKind.SWAMP) 0.45f else 0.25f
                val inst = ModelInstance(texturedBox(o.textureKey, 0.3f))
                inst.transform.idt().translate(x, lift, z).rotate(Vector3.Y, d.rotation).scale(d.w, 1f, d.h)
                parts.add(inst)
            }
            ObstacleKind.WRECK -> {
                if (!AssetManager.hasTexture("hull_" + d.tankId)) return
                val spec = com.ironfront.tanks.TankDatabase.get(d.tankId)
                val tm = tankModel(spec)
                val hull = ModelInstance(tm.hull)
                val turret = ModelInstance(tm.turret)
                hull.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, d.rotation)
                turret.transform.idt().translate(x, tm.turretBase, z).rotate(Vector3.Y, d.rotation + 40f)
                val burnt = Color(0.16f, 0.14f, 0.13f, 1f)
                setDiffuse(hull, burnt)
                setDiffuse(turret, burnt)
                parts.add(hull)
                parts.add(turret)
                radius = 70f
            }
        }
        var blob: ModelInstance? = null
        var casts = false
        when (o.kind) {
            ObstacleKind.TRUNK -> {
                casts = true
                blob = makeBlob(x, z, d.w * 1.05f * 0.5f, d.w * 1.05f * 1.3f)
            }
            ObstacleKind.ROCK -> {
                casts = true
                blob = makeBlob(x, z, d.w * 0.55f, d.w * 0.4f)
            }
            ObstacleKind.BOX -> casts = true
            else -> {}
        }
        items.add(Item(o, parts, blob, radius, x, z, casts))
    }

    // ----------------------------------------------------------------- render

    /**
     * Places the camera for the chosen view.
     *  MODE_CHASE: third person, behind the tank, looking where the turret points (like War Thunder).
     *  MODE_SIGHT: gunner's sight from the gun mount, zoomed in.
     *  MODE_TOP:   tilted tactical camera, north is up.
     * [camX]/[camY] is the smoothed map point used by the tactical view; [yawDeg] is the view heading.
     */
    fun prepare(camX: Float, camY: Float, shake: Float, viewMode: Int, yawDeg: Float) {
        mode = viewMode
        focusX = if (viewMode == MODE_TOP) camX else player.position.x
        focusY = if (viewMode == MODE_TOP) camY else player.position.y
        val sx = if (shake > 0.2f) MathUtils.random(-shake, shake) else 0f
        val sz = if (shake > 0.2f) MathUtils.random(-shake, shake) else 0f
        val c = MathUtils.cosDeg(yawDeg)
        val sn = MathUtils.sinDeg(yawDeg)
        when (viewMode) {
            MODE_CHASE -> {
                camera.fieldOfView = 62f
                camera.near = 8f
                val px = player.position.x
                val py = player.position.y
                camera.position.set(px - c * 175f + sx, 92f + sz * 0.5f, -(py - sn * 175f) + sz)
                camera.up.set(0f, 1f, 0f)
                camera.lookAt(px + c * 230f, 14f, -(py + sn * 230f))
            }
            MODE_SIGHT -> {
                camera.fieldOfView = 17f
                camera.near = 3f
                val h = tankModel(player.spec).turretBase + 7f
                val tx = player.turretX
                val ty = player.turretY
                camera.position.set(tx + c * 4f + sx * 0.25f, h, -(ty + sn * 4f) + sz * 0.25f)
                camera.up.set(0f, 1f, 0f)
                camera.lookAt(tx + c * 1000f, h - 5f, -(ty + sn * 1000f))
            }
            else -> {
                camera.fieldOfView = 50f
                camera.near = 30f
                camera.position.set(camX + sx, CAM_HEIGHT, -camY + CAM_BACK + sz)
                camera.up.set(0f, 1f, 0f)
                camera.lookAt(camX, 0f, -camY)
            }
        }
        camera.far = 4200f
        camera.update()
    }

    /** Sky gradient behind the 3D world (third-person and sight views). Draw it in HUD space before the 3D pass. */
    fun drawSky(batch: SpriteBatch) {
        if (mode == MODE_TOP) return
        val dx = camera.direction.x
        val dz = camera.direction.z
        val len = kotlin.math.sqrt(dx * dx + dz * dz)
        var horizonY = 360f
        if (len > 0.001f) {
            vec.set(camera.position.x + dx / len * 20000f, camera.position.y, camera.position.z + dz / len * 20000f)
            vec.prj(camera.combined)
            horizonY = (vec.y * 0.5f + 0.5f) * 720f
        }
        val pixel = AssetManager.getRegion("pixel")
        val hy = horizonY.coerceIn(0f, 720f)
        batch.setColor(skyHorizon.r, skyHorizon.g, skyHorizon.b, 1f)
        batch.draw(pixel, 0f, 0f, 1280f, hy)
        val bands = 28
        val bandH = (720f - hy) / bands
        if (bandH > 0.4f) {
            for (i in 0 until bands) {
                val t = (i + 0.5f) / bands
                val k = Math.pow(t.toDouble(), 0.8).toFloat()
                batch.setColor(
                    skyHorizon.r + (skyTop.r - skyHorizon.r) * k,
                    skyHorizon.g + (skyTop.g - skyHorizon.g) * k,
                    skyHorizon.b + (skyTop.b - skyHorizon.b) * k,
                    1f
                )
                batch.draw(pixel, 0f, hy + i * bandH, 1280f, bandH + 1f)
            }
        }
        batch.setColor(1f, 1f, 1f, 1f)
    }

    private fun collectVisibleTanks() {
        visibleTanks.clear()
        for (t in world.tanks) {
            if (!t.isAlive && t.wreckTime <= 0f) continue
            if (t === player && mode == MODE_SIGHT) continue
            if (!world.vision.isSpotted(t)) continue
            val x = t.position.x
            val z = -t.position.y
            if (!camera.frustum.sphereInFrustum(x, 15f, z, 110f)) continue

            val inst = tankInsts.getOrPut(t.id) { createTankInst(t.spec, t.team) }
            val l = t.spec.design.hullLenPx.toFloat()
            val w = t.spec.design.hullWidPx.toFloat()
            inst.hull.transform.idt().translate(x, 0f, z).rotate(Vector3.Y, t.rotation)
            val rec = t.recoilPx
            val tx = t.turretX - MathUtils.cosDeg(t.turretRotation) * rec
            val ty = t.turretY - MathUtils.sinDeg(t.turretRotation) * rec
            val extraYaw = if (t.isAlive) 0f else t.wreckTurretOffset
            inst.turret.transform.idt().translate(tx, inst.model.turretBase, -ty).rotate(Vector3.Y, t.turretRotation + extraYaw)
            if (t.isAlive) {
                inst.ring.transform.idt().translate(x, 0.6f, z).rotate(Vector3.Y, t.rotation).scale(l * 1.18f, 1f, w * 1.5f)
                inst.blob.transform.idt().translate(x - 12f, 0.5f, z - 14f).rotate(Vector3.Y, t.rotation).scale(l * 1.05f, 1f, w * 1.35f)
            }
            if (!t.isAlive && !inst.darkened) {
                val burnt = Color(0.17f, 0.15f, 0.14f, 1f)
                setDiffuse(inst.hull, burnt)
                setDiffuse(inst.turret, burnt)
                inst.darkened = true
            }
            visibleTanks.add(Pair(t, inst))
        }
    }

    /** Shadow map pass (high quality only). */
    private fun renderShadows() {
        val sl = shadowLight ?: return
        val sb = shadowBatch ?: return
        shadowCenter.set(focusX, 0f, -focusY)
        sl.begin(shadowCenter, sunDir)
        sb.begin(sl.camera)
        val r2 = 560f * 560f
        for (item in items) {
            if (!item.casts || !item.obstacle.isAlive) continue
            val dx = item.x - focusX
            val dz = item.z + focusY
            if (dx * dx + dz * dz > r2) continue
            for (inst in item.parts) sb.render(inst)
        }
        for (pair in visibleTanks) {
            sb.render(pair.second.hull)
            sb.render(pair.second.turret)
        }
        sb.end()
        sl.end()
    }

    /** Draws the 3D world (call after [prepare]). */
    fun renderWorld() {
        collectVisibleTanks()
        renderShadows()

        modelBatch.begin(camera)
        modelBatch.render(mountainInst, env)
        modelBatch.render(groundInst, env)

        val cull = when (quality) {
            0 -> 950f
            1 -> 1250f
            else -> 1550f
        }
        val cullSq = cull * cull
        for (item in items) {
            if (!item.obstacle.isAlive) continue
            val dx = item.x - focusX
            val dz = item.z + focusY
            if (dx * dx + dz * dz > cullSq) continue
            if (!camera.frustum.sphereInFrustum(item.x, 20f, item.z, item.radius)) continue
            for (inst in item.parts) modelBatch.render(inst, env)
            val blob = item.blob
            if (quality == 1 && blob != null) modelBatch.render(blob, env)
        }

        for (pair in visibleTanks) {
            val t = pair.first
            val inst = pair.second
            modelBatch.render(inst.hull, env)
            modelBatch.render(inst.turret, env)
            if (t.isAlive) {
                modelBatch.render(inst.ring, env)
                if (quality == 1) modelBatch.render(inst.blob, env)
            }
        }
        renderShells()

        modelBatch.end()
    }

    private fun renderShells() {
        var n = 0
        for (p in world.projectiles) {
            if (p.team != Team.FRIEND && world.vision.lit(p.position.x, p.position.y, world.friendsOf()) < 0.25f) continue
            if (n >= shellInsts.size) shellInsts.add(ModelInstance(shellModel))
            val inst = shellInsts[n]
            n++
            val len = 9f + p.caliberMm * 0.10f
            val th = 3f + p.caliberMm * 0.04f
            inst.transform.idt().translate(p.position.x, 17f, -p.position.y).rotate(Vector3.Y, p.rotation).scale(len, th, th)
            val c = if (p.ammoType == AmmoType.AP || p.ammoType == AmmoType.APCR || p.ammoType == AmmoType.HE) p.ammoType.color else Color.WHITE
            setDiffuse(inst, c)
            setEmissive(inst, c)
            modelBatch.render(inst, env)
        }
    }

    // ---------------------------------------------------------------- overlays

    /** Converts a map position (and a height above the ground) to HUD coordinates. Returns false when off screen. */
    fun project(x: Float, y: Float, h: Float, out: Vector3): Boolean {
        out.set(x, h, -y).prj(camera.combined)
        if (out.z > 1f) return false
        out.x = (out.x * 0.5f + 0.5f) * 1280f
        out.y = (out.y * 0.5f + 0.5f) * 720f
        return out.x > -120f && out.x < 1400f && out.y > -120f && out.y < 840f
    }

    /** Particles, fog / spotlight, health bars and floating texts, drawn in HUD space after the 3D pass. */
    fun drawOverlays(batch: SpriteBatch) {
        world.fx.renderProjected(batch, camera.combined, 12f)

        val count = world.collectLights()
        world.vision.render3D(batch, camera, world.friendsOf(), world.lightArray, count)

        val pixel = AssetManager.getTexture("pixel")
        val font = AssetManager.fontSmall
        for (t in world.tanks) {
            if (!t.isAlive || !t.showHealthBar) continue
            if (!world.vision.isSpotted(t)) continue
            if (!project(t.position.x, t.position.y, 46f, vec)) continue
            val bw = 58f
            val ratio = (t.currentHp / t.maxHealth).coerceIn(0f, 1f)
            batch.setColor(0f, 0f, 0f, 0.65f)
            batch.draw(pixel, vec.x - bw / 2f - 1f, vec.y - 1f, bw + 2f, 7f)
            batch.setColor(t.team.outline.r, t.team.outline.g, t.team.outline.b, 1f)
            batch.draw(pixel, vec.x - bw / 2f, vec.y, bw * ratio, 5f)
            batch.setColor(1f, 1f, 1f, 1f)
            val label = if (t.playerControlled) "YOU" else "T" + t.spec.tier + " " + t.spec.shortName
            font.color = t.team.outline
            font.draw(batch, label, vec.x - bw / 2f, vec.y + 24f)
            font.color = Color.WHITE
        }

        for (msg in world.floatingMessages) {
            if (world.vision.lit(msg.x, msg.y, world.friendsOf()) < 0.2f) continue
            if (!project(msg.x, msg.y, 40f, vec)) continue
            font.draw(batch, msg.text, vec.x - 36f, vec.y)
        }
    }

    private fun rect(batch: SpriteBatch, x: Float, y: Float, w: Float, h: Float, r: Float, g: Float, b: Float, a: Float) {
        batch.setColor(r, g, b, a)
        batch.draw(AssetManager.getRegion("pixel"), x, y, w, h)
    }

    /** Black scope edge with fine cross hairs for the gunner's sight. */
    private fun drawScope(batch: SpriteBatch) {
        val r = 340f
        val px = AssetManager.getRegion("pixel")
        batch.setColor(0f, 0f, 0f, 0.97f)
        var y = 0f
        while (y < 720f) {
            val dy = (y + 3f) - 360f
            val inside = r * r - dy * dy
            val hw = if (inside > 0f) kotlin.math.sqrt(inside) else 0f
            batch.draw(px, 0f, y, 640f - hw, 6f)
            batch.draw(px, 640f + hw, y, 640f - hw, 6f)
            y += 6f
        }
        // fine cross hairs and range marks
        rect(batch, 640f - r, 359f, r * 2f, 2f, 0f, 0f, 0f, 0.55f)
        rect(batch, 639f, 360f - r, 2f, r * 2f, 0f, 0f, 0f, 0.55f)
        for (i in 1..8) {
            rect(batch, 640f + i * 36f, 352f, 2f, 16f, 0f, 0f, 0f, 0.65f)
            rect(batch, 640f - i * 36f, 352f, 2f, 16f, 0f, 0f, 0f, 0.65f)
            rect(batch, 632f, 360f - i * 36f, 16f, 2f, 0f, 0f, 0f, 0.65f)
        }
        batch.setColor(1f, 1f, 1f, 1f)
    }

    /**
     * Cross hair with range for the third-person view, scope overlay for the sight view.
     * [rangePx] is the distance to what the barrel points at (map pixels), [reload] 0..1.
     */
    fun drawAimOverlay(batch: SpriteBatch, rangePx: Float, enemyHit: Boolean, reload: Float, label: String) {
        if (mode == MODE_TOP) return
        val cx: Float
        val cy: Float
        if (mode == MODE_SIGHT) {
            drawScope(batch)
            cx = 640f
            cy = 360f
        } else {
            val reach = max(rangePx, 60f)
            val ax = player.muzzleX + MathUtils.cosDeg(player.turretRotation) * reach
            val ay = player.muzzleY + MathUtils.sinDeg(player.turretRotation) * reach
            if (!project(ax, ay, 16f, vec2)) return
            cx = vec2.x
            cy = vec2.y
        }
        val r = if (enemyHit) 1f else 0.95f
        val g = if (enemyHit) 0.30f else 0.95f
        val b = if (enemyHit) 0.25f else 0.95f
        rect(batch, cx - 30f, cy - 1f, 20f, 2f, r, g, b, 0.9f)
        rect(batch, cx + 10f, cy - 1f, 20f, 2f, r, g, b, 0.9f)
        rect(batch, cx - 1f, cy - 30f, 2f, 20f, r, g, b, 0.9f)
        rect(batch, cx - 1f, cy + 10f, 2f, 20f, r, g, b, 0.9f)
        rect(batch, cx - 2f, cy - 2f, 4f, 4f, r, g, b, 1f)
        batch.setColor(r, g, b, 0.22f)
        batch.draw(AssetManager.getRegion("circle"), cx - 22f, cy - 22f, 44f, 44f)

        val font = AssetManager.fontSmall
        font.color = Color(r, g, b, 1f)
        font.draw(batch, (rangePx / 14f).toInt().toString() + " m", cx + 16f, cy - 12f)
        font.draw(batch, label, cx + 16f, cy - 30f)
        font.color = Color.WHITE
        // reload bar
        rect(batch, cx - 28f, cy - 40f, 56f, 5f, 0f, 0f, 0f, 0.6f)
        rect(batch, cx - 27f, cy - 39f, 54f * reload.coerceIn(0f, 1f), 3f, 1f, if (reload >= 1f) 0.9f else 0.6f, 0.2f, 1f)
        batch.setColor(1f, 1f, 1f, 1f)
    }

    fun dispose() {
        shadowBatch?.dispose()
        shadowLight?.dispose()
        modelBatch.dispose()
        for (m in models) m.dispose()
        models.clear()
    }

    companion object {
        const val MODE_CHASE = 0
        const val MODE_SIGHT = 1
        const val MODE_TOP = 2
        private const val CAM_HEIGHT = 560f
        private const val CAM_BACK = 310f
    }
}
