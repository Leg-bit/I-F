package com.ironfront.combat

import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector2
import com.ironfront.armor.HitPart
import com.ironfront.armor.HitZone
import com.ironfront.entities.ProjectileEntity
import com.ironfront.tanks.TankEntity
import com.ironfront.weapons.AmmoType
import kotlin.math.abs
import kotlin.math.cos

data class HitResult(
    val penetrated: Boolean,
    val ricochet: Boolean,
    val damageDealt: Float,
    val zone: HitZone,
    val part: HitPart,
    val effectiveArmorMm: Float,
    val reflectAngleDeg: Float
)

/**
 * Armour model:
 *  1. Find which part (hull / turret) and which side (front / side / rear) was hit.
 *  2. The angle between the shell and the plate's normal is added to the plate slope.
 *  3. If that total angle is above the shell's ricochet angle (and the shell is not overmatching
 *     the plate: calibre >= 3x thickness) the shell bounces off in a reflected direction.
 *  4. Otherwise effective armour = thickness / cos(angle) is compared to the shell's penetration.
 */
object DamageCalculator {

    fun resolveHit(shell: ProjectileEntity, target: TankEntity, hitX: Float, hitY: Float): HitResult {
        val spec = target.spec
        val part = determinePart(target, hitX, hitY)
        val baseRot = if (part == HitPart.TURRET && !spec.isCasemate) target.turretRotation else target.rotation

        val incoming = shell.rotation + 180f
        val rel = normalize180(incoming - baseRot)
        val absRel = abs(rel)
        val zone = when {
            absRel <= 45f -> HitZone.FRONT
            absRel >= 135f -> HitZone.REAR
            else -> HitZone.SIDE
        }
        val deviation = when (zone) {
            HitZone.FRONT -> absRel
            HitZone.REAR -> 180f - absRel
            HitZone.SIDE -> abs(90f - absRel)
        }

        val face = spec.armor.face(part, zone)
        val ammo = shell.ammoType
        val effDeviation = (deviation - ammo.normalizationDeg).coerceAtLeast(0f)
        val totalAngle = (face.slopeDeg + effDeviation).coerceAtMost(80f)
        val overmatch = shell.caliberMm >= face.thicknessMm * 3f
        val armorMult = target.loadout.getTotalArmorMultiplier()
        val effective = face.thicknessMm * armorMult / cos(Math.toRadians(totalAngle.toDouble())).toFloat()
        val pen = shell.currentPenetration() * MathUtils.random(0.92f, 1.08f)

        if (ammo != AmmoType.HE && !overmatch && totalAngle >= ammo.ricochetAngleDeg) {
            val normalAngle = when (zone) {
                HitZone.FRONT -> baseRot
                HitZone.REAR -> baseRot + 180f
                HitZone.SIDE -> if (rel > 0f) baseRot + 90f else baseRot - 90f
            }
            val reflected = 2f * normalAngle + 180f - shell.rotation + MathUtils.random(-8f, 8f)
            return HitResult(false, true, 0f, zone, part, effective, reflected)
        }

        if (pen >= effective) {
            val dmg = shell.baseDamage * MathUtils.random(0.9f, 1.1f)
            return HitResult(true, false, dmg, zone, part, effective, 0f)
        }

        if (ammo == AmmoType.HE) {
            val splash = shell.baseDamage * 0.30f
            return HitResult(false, false, splash, zone, part, effective, 0f)
        }

        return HitResult(false, false, 0f, zone, part, effective, 0f)
    }

    private fun determinePart(t: TankEntity, hx: Float, hy: Float): HitPart {
        val d = t.spec.design
        if (t.spec.isCasemate) {
            val u = t.localU(hx, hy)
            return if (u > -d.hullLenPx * 0.28f && u < d.hullLenPx * 0.38f) HitPart.TURRET else HitPart.HULL
        }
        return if (Vector2.dst(hx, hy, t.turretX, t.turretY) <= d.turretHitRadiusPx) HitPart.TURRET else HitPart.HULL
    }

    private fun normalize180(angle: Float): Float {
        var a = angle % 360f
        if (a > 180f) a -= 360f
        if (a < -180f) a += 360f
        return a
    }
}
