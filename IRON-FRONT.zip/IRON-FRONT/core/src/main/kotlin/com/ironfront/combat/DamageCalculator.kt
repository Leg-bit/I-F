package com.ironfront.combat

import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector2
import com.ironfront.armor.ArmorPlate
import com.ironfront.armor.ArmorScheme
import com.ironfront.armor.HitSection
import com.ironfront.armor.HitZone
import com.ironfront.core.GameConfig
import com.ironfront.entities.ProjectileEntity
import com.ironfront.tanks.TankEntity
import com.ironfront.tanks.TankSpec
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos

enum class HitOutcome { PENETRATION, RICOCHET, NO_PENETRATION, SPLASH }

data class HitResult(
    val outcome: HitOutcome,
    val damageDealt: Float,
    val zone: HitZone,
    val section: HitSection,
    val impactAngleDeg: Float,
    val effectiveArmorMm: Float,
    val penetrationMm: Float
)

/**
 * Armor model:
 *  1. Which part was hit (hull or turret) and which plate (front/side/rear) from the real impact direction.
 *  2. Impact obliquity from plate slope and horizontal angle: cos(a) = cos(slope) * cos(phi).
 *  3. Ricochet if the shell is too oblique (limit depends on shell type), unless overmatched
 *     (shell diameter >= 2x plate thickness).
 *  4. Normalization turns the shell toward the plate normal (capped shells more than solid shot).
 *  5. Effective thickness = thickness / cos(obliquity); penetration is taken at the distance flown.
 */
object DamageCalculator {
    private val local = Vector2()

    fun resolveHit(shell: ProjectileEntity, target: TankEntity): HitResult {
        val spec = target.spec
        target.toLocal(shell.position.x, shell.position.y, local)

        val section = determineSection(spec, local)
        val facing = if (section == HitSection.TURRET && spec.hasTurret) target.turretRotation else target.rotation
        val diff = abs(angleDiff(facing, shell.rotation + 180f))

        val zone = when {
            diff <= 45f -> HitZone.FRONT
            diff >= 135f -> HitZone.REAR
            else -> HitZone.SIDE
        }
        val phi = when (zone) {
            HitZone.FRONT -> diff
            HitZone.SIDE -> abs(diff - 90f)
            HitZone.REAR -> 180f - diff
        }

        val plate = pickPlate(spec.armor, section, zone)
        val thickness = plate.thicknessMm * target.loadout.getTotalArmorMultiplier()

        val cosAlpha = (cos(Math.toRadians(plate.slopeDeg.toDouble())) * cos(Math.toRadians(phi.toDouble())))
            .coerceIn(0.0001, 1.0)
        val alphaDeg = Math.toDegrees(acos(cosAlpha)).toFloat()

        val ammo = shell.ammo
        val kind = ammo.kind
        val overmatch = kind.overmatchRule && ammo.coreCaliberMm >= thickness * 2f

        val ricochetLimit = kind.ricochetDeg + MathUtils.random(-3f, 3f)
        if (!overmatch && alphaDeg > ricochetLimit) {
            return HitResult(HitOutcome.RICOCHET, 0f, zone, section, alphaDeg, 0f, 0f)
        }

        val normalization = kind.normalizationDeg * (if (overmatch) 2f else 1f)
        val effAlpha = (alphaDeg - normalization).coerceIn(0f, 80f)
        val effThickness = thickness / cos(Math.toRadians(effAlpha.toDouble())).toFloat()

        val penetration = ammo.penetrationAt(shell.distanceMeters) * MathUtils.random(0.92f, 1.08f)
        val damage = ammo.damage * MathUtils.random(0.85f, 1.15f)

        return when {
            penetration >= effThickness ->
                HitResult(HitOutcome.PENETRATION, damage, zone, section, alphaDeg, effThickness, penetration)
            kind == com.ironfront.weapons.AmmoKind.HE ->
                HitResult(HitOutcome.SPLASH, damage * 0.25f, zone, section, alphaDeg, effThickness, penetration)
            else ->
                HitResult(HitOutcome.NO_PENETRATION, 0f, zone, section, alphaDeg, effThickness, penetration)
        }
    }

    private fun determineSection(spec: TankSpec, loc: Vector2): HitSection {
        if (spec.hasTurret) {
            val radius = spec.turretDiameterM * GameConfig.PX_PER_M / 2f
            if (loc.len() <= radius && MathUtils.random() < GameConfig.TURRET_HIT_CHANCE) return HitSection.TURRET
            return HitSection.HULL
        }
        // Casemate tank destroyer: the forward part of the hull is the fixed fighting compartment.
        val forwardLimit = -spec.hullLengthM * GameConfig.PX_PER_M * 0.2f
        if (loc.x >= forwardLimit && MathUtils.random() < 0.7f) return HitSection.TURRET
        return HitSection.HULL
    }

    private fun pickPlate(a: ArmorScheme, section: HitSection, zone: HitZone): ArmorPlate =
        when (section) {
            HitSection.HULL -> when (zone) {
                HitZone.FRONT -> a.hullFront
                HitZone.SIDE -> a.hullSide
                HitZone.REAR -> a.hullRear
            }
            HitSection.TURRET -> when (zone) {
                HitZone.FRONT -> a.turretFront
                HitZone.SIDE -> a.turretSide
                HitZone.REAR -> a.turretRear
            }
        }

    private fun angleDiff(from: Float, to: Float): Float {
        var d = (to - from) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }
}
