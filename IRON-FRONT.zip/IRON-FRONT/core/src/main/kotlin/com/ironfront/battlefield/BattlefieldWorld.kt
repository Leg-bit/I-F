package com.ironfront.battlefield

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector2
import com.ironfront.ai.EnemyAIController
import com.ironfront.combat.DamageCalculator
import com.ironfront.combat.HitOutcome
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.entities.ObstacleEntity
import com.ironfront.entities.ProjectileEntity
import com.ironfront.maps.BattleSetup
import com.ironfront.physics.CollisionSystem
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankEntity
import com.ironfront.teams.Team
import kotlin.math.abs
import kotlin.math.ceil

class BattlefieldWorld(val playerTank: TankEntity, val setup: BattleSetup) {
    val map = setup.map

    private val allTanks = mutableListOf<TankEntity>()
    private val aiControllers = mutableListOf<EnemyAIController>()
    val projectiles = mutableListOf<ProjectileEntity>()
    val obstacles = mutableListOf<ObstacleEntity>()

    var enemiesDestroyed = 0
        private set

    var totalEnemies = 0
        private set
    var totalFriends = 0
        private set

    var floatingMessages = mutableListOf<FloatingText>()

    init {
        map.obstacles.forEachIndexed { i, d ->
            obstacles.add(ObstacleEntity("obs_$i", d.x, d.y, d.w, d.h, textureKey = d.texture))
        }
        allTanks.add(playerTank)
        spawnBots()
        totalEnemies = allTanks.count { it.team == Team.ENEMY }
        totalFriends = allTanks.count { it.team == Team.FRIEND }
    }

    fun enemiesAlive(): Int = allTanks.count { it.isAlive && it.team == Team.ENEMY }
    fun friendsAlive(): Int = allTanks.count { it.isAlive && it.team == Team.FRIEND }

    // ------------------------------------------------------------ spawning

    private fun spawnBots() {
        setup.bots.forEachIndexed { idx, bot ->
            val spec = TankDatabase.get(bot.tankId)
            val pos = if (bot.team == Team.ENEMY) {
                val z = map.enemyZone
                findFreeSpot(z.minX, z.maxX, z.minY, z.maxY)
            } else {
                val px = playerTank.position.x
                val py = playerTank.position.y
                findFreeSpot(
                    MathUtils.clamp(px - 260f, 100f, GameConfig.MAP_WIDTH - 100f),
                    MathUtils.clamp(px + 260f, 100f, GameConfig.MAP_WIDTH - 100f),
                    MathUtils.clamp(py - 260f, 100f, GameConfig.MAP_HEIGHT - 100f),
                    MathUtils.clamp(py + 260f, 100f, GameConfig.MAP_HEIGHT - 100f)
                )
            }
            val tank = TankEntity("bot_$idx", spec, pos.x, pos.y, playerControlled = false, team = bot.team)
            tank.rotation = if (bot.team == Team.ENEMY) 225f else 45f
            tank.turretRotation = tank.rotation
            tank.desiredTurretRotation = tank.rotation
            allTanks.add(tank)
            aiControllers.add(EnemyAIController(tank))
        }
    }

    private fun findFreeSpot(minX: Float, maxX: Float, minY: Float, maxY: Float): Vector2 {
        val last = Vector2((minX + maxX) / 2f, (minY + maxY) / 2f)
        for (attempt in 0 until 80) {
            val x = MathUtils.random(minX, maxX)
            val y = MathUtils.random(minY, maxY)
            if (isSpotFree(x, y)) return Vector2(x, y)
            last.set(x, y)
        }
        return last
    }

    private fun isSpotFree(x: Float, y: Float): Boolean {
        val half = 50f
        for (o in obstacles) {
            if (abs(x - o.position.x) < o.width / 2f + half && abs(y - o.position.y) < o.height / 2f + half) {
                return false
            }
        }
        for (t in allTanks) {
            if (t.position.dst(x, y) < 90f) return false
        }
        return true
    }

    // -------------------------------------------------------------- update

    private fun resolveWorld(tank: TankEntity) {
        CollisionSystem.resolveTankWorldBounds(tank)
        for (o in obstacles) CollisionSystem.resolveTankObstacle(tank, o)
    }

    fun update(delta: Float) {
        playerTank.update(delta)
        resolveWorld(playerTank)

        for (ai in aiControllers) {
            val bot = ai.tank
            if (!bot.isAlive) continue
            val targets = allTanks.filter { it.isAlive && it.team != bot.team }
            val leader = if (bot.team == Team.FRIEND && playerTank.isAlive) playerTank else null
            val fired = ai.update(delta, targets, leader)
            if (fired != null) projectiles.add(fired)
            bot.update(delta)
            resolveWorld(bot)
        }

        for (i in 0 until allTanks.size) {
            for (j in i + 1 until allTanks.size) {
                CollisionSystem.resolveTankVsTank(allTanks[i], allTanks[j])
            }
        }

        val projIter = projectiles.iterator()
        while (projIter.hasNext()) {
            val shell = projIter.next()
            // Sub-step fast shells so thin tanks and walls are never skipped.
            val steps = ceil(shell.speedPx * delta / 6f).toInt().coerceIn(1, 24)
            val dt = delta / steps
            var s = 0
            while (s < steps && shell.isAlive) {
                shell.advance(dt)
                resolveShellStep(shell)
                s++
            }
            if (!shell.isAlive) projIter.remove()
        }

        floatingMessages.forEach {
            it.timer -= delta
            it.y += 28f * delta
        }
        floatingMessages.removeAll { it.timer <= 0f }
    }

    private fun resolveShellStep(shell: ProjectileEntity) {
        if (!shell.isAlive) return
        val px = shell.position.x
        val py = shell.position.y
        if (px < 0f || py < 0f || px > GameConfig.MAP_WIDTH || py > GameConfig.MAP_HEIGHT) {
            shell.isAlive = false
            return
        }
        for (o in obstacles) {
            if (abs(px - o.position.x) <= o.width / 2f && abs(py - o.position.y) <= o.height / 2f) {
                shell.isAlive = false
                return
            }
        }
        for (tank in allTanks) {
            if (!tank.isAlive || tank.team == shell.team) continue
            if (!tank.containsPoint(px, py)) continue

            val result = DamageCalculator.resolveHit(shell, tank)
            val tx = tank.position.x
            val ty = tank.position.y + 40f
            when (result.outcome) {
                HitOutcome.PENETRATION -> {
                    tank.takeDamage(result.damageDealt)
                    addFloatingText("-${result.damageDealt.toInt()}", tx, ty)
                }
                HitOutcome.SPLASH -> {
                    tank.takeDamage(result.damageDealt)
                    addFloatingText("-${result.damageDealt.toInt()} HE", tx, ty)
                }
                HitOutcome.RICOCHET -> addFloatingText("RICOCHET!", tx, ty)
                HitOutcome.NO_PENETRATION ->
                    addFloatingText("NO PEN ${result.penetrationMm.toInt()}/${result.effectiveArmorMm.toInt()}", tx, ty)
            }
            if (!tank.isAlive && tank.team == Team.ENEMY) enemiesDestroyed++
            shell.isAlive = false
            return
        }
    }

    // -------------------------------------------------------------- render

    fun render(batch: SpriteBatch, camX: Float, camY: Float) {
        val ts = GameConfig.TILE_SIZE
        val cols = (GameConfig.MAP_WIDTH / ts).toInt()
        val rows = (GameConfig.MAP_HEIGHT / ts).toInt()
        val halfW = GameConfig.VIRTUAL_WIDTH / 2f
        val halfH = GameConfig.VIRTUAL_HEIGHT / 2f

        val minCol = ((camX - halfW) / ts).toInt().coerceIn(0, cols - 1)
        val maxCol = ((camX + halfW) / ts).toInt().coerceIn(0, cols - 1)
        val minRow = ((camY - halfH) / ts).toInt().coerceIn(0, rows - 1)
        val maxRow = ((camY + halfH) / ts).toInt().coerceIn(0, rows - 1)

        val tile = AssetManager.getTexture("ground_${map.id}")
        for (cx in minCol..maxCol) {
            for (cy in minRow..maxRow) {
                batch.draw(tile, cx * ts, cy * ts)
            }
        }

        obstacles.forEach { it.render(batch) }
        allTanks.forEach { if (it !== playerTank) it.render(batch) }
        playerTank.render(batch)
        projectiles.forEach { it.render(batch) }

        floatingMessages.forEach { msg ->
            AssetManager.font.draw(batch, msg.text, msg.x - 40f, msg.y)
        }
    }

    private fun addFloatingText(text: String, x: Float, y: Float) {
        floatingMessages.add(FloatingText(text, x, y, 1.0f))
    }

    data class FloatingText(val text: String, var x: Float, var y: Float, var timer: Float)
}
