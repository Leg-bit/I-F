package com.ironfront.battlefield

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector2
import com.ironfront.ai.EnemyAIController
import com.ironfront.audio.AudioManager
import com.ironfront.combat.DamageCalculator
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.entities.ObstacleEntity
import com.ironfront.entities.ProjectileEntity
import com.ironfront.fx.FxSystem
import com.ironfront.maps.BattleSetup
import com.ironfront.maps.ObstacleKind
import com.ironfront.physics.CollisionSystem
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankEntity
import com.ironfront.teams.Team
import com.ironfront.vision.VisionSystem
import com.ironfront.weapons.AmmoType
import kotlin.math.abs
import kotlin.math.ceil

class BattlefieldWorld(val playerTank: TankEntity, val setup: BattleSetup) {
    val map = setup.map

    private val allTanks = mutableListOf<TankEntity>()
    private val aiControllers = mutableListOf<EnemyAIController>()
    val projectiles = mutableListOf<ProjectileEntity>()
    val obstacles = mutableListOf<ObstacleEntity>()
    val fx = FxSystem()
    val vision: VisionSystem

    /** Screen shake in pixels, read by the battle screen. */
    var shake = 0f

    val tanks: List<TankEntity> get() = allTanks

    var enemiesDestroyed = 0
        private set
    var totalEnemies = 0
        private set
    var totalFriends = 0
        private set

    // statistics of the player for the result screen
    var playerShots = 0
        private set
    var playerHits = 0
        private set
    var playerRicochets = 0
        private set
    var playerKills = 0
        private set
    var playerDamage = 0f
        private set

    var floatingMessages = mutableListOf<FloatingText>()
    private class Light(val x: Float, val y: Float, val radius: Float, val intensity: Float, var life: Float, val maxLife: Float)

    private val lights = ArrayList<Light>()
    private val lightData = FloatArray(24)

    /** The 6 brightest recent lights (x, y, radius, intensity) for the fog shader. */
    val lightArray: FloatArray get() = lightData

    fun collectLights(): Int {
        var count = 0
        for (li in lights.indices.reversed()) {
            val l = lights[li]
            if (count >= 6) break
            val f = (l.life / l.maxLife).coerceIn(0f, 1f)
            lightData[count * 4] = l.x
            lightData[count * 4 + 1] = l.y
            lightData[count * 4 + 2] = l.radius
            lightData[count * 4 + 3] = l.intensity * f
            count++
        }
        return count
    }
    private val swamps = ArrayList<ObstacleEntity>()
    private val flat = ArrayList<ObstacleEntity>()
    private val tops = ArrayList<ObstacleEntity>()

    private val groundTiles = Array(3) { AssetManager.getTexture("ground_${map.id}_$it") }
    private var smokeTimer = 0f

    init {
        map.obstacles.forEachIndexed { i, d ->
            obstacles.add(ObstacleEntity("obs_$i", d))
        }
        for (o in obstacles) {
            when {
                o.kind == ObstacleKind.SWAMP -> swamps.add(o)
                o.isFlat() -> flat.add(o)
                o.kind == ObstacleKind.TRUNK || o.kind == ObstacleKind.BUSH -> tops.add(o)
            }
        }
        vision = VisionSystem(obstacles)
        vision.enabled = setup.visionEnabled
        when (map.id) {
            "steppe" -> vision.setAtmosphere(1.0f, 0.88f, 0.62f, 0.06f)
            "canyon" -> vision.setAtmosphere(1.0f, 0.70f, 0.45f, 0.08f)
            "urban" -> vision.setAtmosphere(0.55f, 0.60f, 0.70f, 0.10f)
            "desert" -> vision.setAtmosphere(1.0f, 0.82f, 0.45f, 0.10f)
            else -> vision.setAtmosphere(0.60f, 0.76f, 1.0f, 0.10f)
        }
        allTanks.add(playerTank)
        spawnBots()
        totalEnemies = allTanks.count { it.team == Team.ENEMY }
        totalFriends = allTanks.count { it.team == Team.FRIEND }
    }

    fun enemiesAlive(): Int = allTanks.count { it.isAlive && it.team == Team.ENEMY }
    fun friendsAlive(): Int = allTanks.count { it.isAlive && it.team == Team.FRIEND }

    // ------------------------------------------------------------ spawning

    private fun spawnBots() {
        setup.bots.forEachIndexed { idx, bot ->
            val spec = TankDatabase.get(bot.tankId)
            val pos = if (bot.team == Team.ENEMY) {
                val z = map.enemyZone
                findFreeSpot(z.minX, z.maxX, z.minY, z.maxY)
            } else {
                val px = playerTank.position.x
                val py = playerTank.position.y
                findFreeSpot(
                    MathUtils.clamp(px - 260f, 100f, GameConfig.MAP_WIDTH - 100f),
                    MathUtils.clamp(px + 260f, 100f, GameConfig.MAP_WIDTH - 100f),
                    MathUtils.clamp(py - 260f, 100f, GameConfig.MAP_HEIGHT - 100f),
                    MathUtils.clamp(py + 260f, 100f, GameConfig.MAP_HEIGHT - 100f)
                )
            }
            val tank = TankEntity("bot_$idx", spec, pos.x, pos.y, playerControlled = false, team = bot.team)
            tank.rotation = if (bot.team == Team.ENEMY) 225f else 45f
            tank.turretRotation = tank.rotation
            tank.desiredTurretRotation = tank.rotation
            allTanks.add(tank)
            aiControllers.add(EnemyAIController(tank))
        }
    }

    private fun findFreeSpot(minX: Float, maxX: Float, minY: Float, maxY: Float): Vector2 {
        val last = Vector2((minX + maxX) / 2f, (minY + maxY) / 2f)
        for (attempt in 0 until 100) {
            val x = MathUtils.random(minX, maxX)
            val y = MathUtils.random(minY, maxY)
            if (isSpotFree(x, y)) return Vector2(x, y)
            last.set(x, y)
        }
        return last
    }

    private fun isSpotFree(x: Float, y: Float): Boolean {
        val half = 62f
        for (o in obstacles) {
            if (!o.solid) continue
            val reach = if (o.kind == ObstacleKind.BOX) o.width / 2f else o.radius
            val reachY = if (o.kind == ObstacleKind.BOX) o.height / 2f else o.radius
            if (abs(x - o.position.x) < reach + half && abs(y - o.position.y) < reachY + half) {
                return false
            }
        }
        for (t in allTanks) {
            if (t.position.dst(x, y) < 120f) return false
        }
        return true
    }

    // -------------------------------------------------------------- firing

    /** Adds a freshly fired shell to the world and plays flash, dust, kick and sound. */
    fun fireShell(shell: ProjectileEntity, shooter: TankEntity) {
        projectiles.add(shell)
        val cal = shooter.spec.gun.caliberMm
        fx.muzzleFlash(shooter.muzzleX, shooter.muzzleY, shooter.turretRotation)
        addLight(shooter.muzzleX, shooter.muzzleY, 200f + cal * 1.6f, 1f, 0.16f)
        fx.dust(shooter.muzzleX, shooter.muzzleY, shooter.turretRotation, 0.5f + cal / 90f)
        if (shooter === playerTank) {
            playerShots++
            shake = maxOf(shake, shooter.lastRecoilPower)
        }
        AudioManager.playCannonFire(volumeAt(shooter.position.x, shooter.position.y, 1f), cal, panAt(shooter.position.x))
    }

    private fun addLight(x: Float, y: Float, radius: Float, intensity: Float, life: Float) {
        if (lights.size >= 16) lights.removeAt(0)
        lights.add(Light(x, y, radius, intensity, life, life))
    }

    fun dispose() {
        vision.dispose()
    }

    private fun volumeAt(x: Float, y: Float, base: Float): Float {
        val d = playerTank.position.dst(x, y)
        return (base * (1f - d / 1100f)).coerceIn(0.12f, 1f)
    }

    private fun panAt(x: Float): Float = ((x - playerTank.position.x) / 650f).coerceIn(-1f, 1f)

    /** Result of [rangeAlong]: how far the barrel points before something solid, and whether it is an enemy tank. */
    class RangeResult(var distance: Float = 0f, var enemyTank: Boolean = false)

    /** Range finder for the gun sight: marches along the barrel until a solid object or an enemy tank. */
    fun rangeAlong(x: Float, y: Float, angleDeg: Float, maxRange: Float, shooter: TankEntity, out: RangeResult) {
        val dx = MathUtils.cosDeg(angleDeg)
        val dy = MathUtils.sinDeg(angleDeg)
        var d = 24f
        out.enemyTank = false
        while (d < maxRange) {
            val px = x + dx * d
            val py = y + dy * d
            if (px < 0f || py < 0f || px > GameConfig.MAP_WIDTH || py > GameConfig.MAP_HEIGHT) break
            for (t in allTanks) {
                if (!t.isAlive || t === shooter) continue
                if (abs(t.position.x - px) > 70f || abs(t.position.y - py) > 70f) continue
                if (t.containsPoint(px, py)) {
                    out.distance = d
                    out.enemyTank = t.team != shooter.team
                    return
                }
            }
            for (o in obstacles) {
                if (!o.isAlive || !o.solid) continue
                if (abs(o.position.x - px) > 120f || abs(o.position.y - py) > 120f) continue
                if (o.containsPoint(px, py)) {
                    out.distance = d
                    return
                }
            }
            d += 12f
        }
        out.distance = d
    }

    // -------------------------------------------------------------- update

    private fun resolveWorld(tank: TankEntity) {
        CollisionSystem.resolveTankWorldBounds(tank)
        for (o in obstacles) CollisionSystem.resolveTankObstacle(tank, o)
    }

    /** Mud, quicksand and thin ice slow tanks down. */
    private fun applyTerrain(tank: TankEntity) {
        var f = 1f
        for (z in swamps) {
            val dx = tank.position.x - z.position.x
            val dy = tank.position.y - z.position.y
            if (dx * dx + dy * dy < z.radius * z.radius * 0.85f) {
                f = 0.52f
                break
            }
        }
        tank.terrainFactor = f
    }

    fun update(delta: Float) {
        applyTerrain(playerTank)
        playerTank.update(delta)
        resolveWorld(playerTank)

        for (ai in aiControllers) {
            val bot = ai.tank
            if (!bot.isAlive) {
                bot.update(delta)
                continue
            }
            val targets = allTanks.filter { it.isAlive && it.team != bot.team }
            val leader = if (bot.team == Team.FRIEND && playerTank.isAlive) playerTank else null
            val fired = ai.update(delta, targets, leader)
            if (fired != null) fireShell(fired, bot)
            applyTerrain(bot)
            bot.update(delta)
            resolveWorld(bot)
        }

        for (i in 0 until allTanks.size) {
            for (j in i + 1 until allTanks.size) {
                CollisionSystem.resolveTankVsTank(allTanks[i], allTanks[j])
            }
        }

        updateProjectiles(delta)
        if (obstacles.any { !it.isAlive }) {
            obstacles.removeAll { !it.isAlive }
            flat.removeAll { !it.isAlive }
            tops.removeAll { !it.isAlive }
        }
        vision.update(delta, playerTank, allTanks)
        if (shake > 0f) shake = (shake - 45f * delta).coerceAtLeast(0f)

        smokeTimer -= delta
        if (smokeTimer <= 0f) {
            smokeTimer = 0.18f
            for (t in allTanks) {
                if (!t.isAlive && t.wreckTime > 15f) fx.smoke(t.position.x, t.position.y)
            }
        }
        for (t in allTanks) {
            if (!t.isAlive) t.update(delta)
        }

        updateLights(delta)
        emitTankFx(delta)
        fx.update(delta)
        floatingMessages.forEach {
            it.timer -= delta
            it.y += 28f * delta
        }
        floatingMessages.removeAll { it.timer <= 0f }
    }

    private fun updateLights(delta: Float) {
        val it = lights.iterator()
        while (it.hasNext()) {
            val l = it.next()
            l.life -= delta
            if (l.life <= 0f) it.remove()
        }
    }

    /** Tread marks behind moving tanks and exhaust puffs. */
    private fun emitTankFx(delta: Float) {
        for (t in allTanks) {
            if (!t.isAlive) continue
            val speed = t.speedNow
            if (speed < 20f) continue
            val rot = t.rotation
            val dx = MathUtils.cosDeg(rot)
            val dy = MathUtils.sinDeg(rot)
            val halfLen = t.spec.design.hullLenPx / 2f
            val halfWid = t.spec.design.hullWidPx / 2f
            t.markAccum += speed * delta
            if (t.markAccum >= 11f) {
                t.markAccum = 0f
                val rx = t.position.x - dx * halfLen * 0.35f
                val ry = t.position.y - dy * halfLen * 0.35f
                val px = -dy * halfWid * 0.68f
                val py = dx * halfWid * 0.68f
                fx.trackMark(rx + px, ry + py, rot)
                fx.trackMark(rx - px, ry - py, rot)
            }
            t.exhaustTimer -= delta
            if (t.exhaustTimer <= 0f) {
                t.exhaustTimer = 0.14f
                val ex = t.position.x - dx * halfLen * 0.95f
                val ey = t.position.y - dy * halfLen * 0.95f
                fx.exhaust(ex - dy * halfWid * 0.25f, ey + dx * halfWid * 0.25f, rot, (speed / t.spec.moveSpeed).coerceIn(0f, 1f))
            }
        }
    }

    private fun updateProjectiles(delta: Float) {
        val iter = projectiles.iterator()
        while (iter.hasNext()) {
            val shell = iter.next()
            shell.tick(delta)

            if (shell.isAlive) {
                val total = shell.speed * delta
                val steps = ceil(total / SWEEP_STEP).toInt().coerceAtLeast(1)
                val stepLen = total / steps
                var s = 0
                while (s < steps && shell.isAlive) {
                    val dx = MathUtils.cosDeg(shell.rotation)
                    val dy = MathUtils.sinDeg(shell.rotation)
                    shell.position.add(dx * stepLen, dy * stepLen)
                    shell.traveled += stepLen
                    if (!hitObstacle(shell)) {
                        hitTank(shell)
                    }
                    s++
                }
            }
            if (!shell.isAlive) iter.remove()
        }
    }

    private fun hitObstacle(shell: ProjectileEntity): Boolean {
        val px = shell.position.x
        val py = shell.position.y
        for (o in obstacles) {
            if (!o.isAlive || !o.solid) continue
            if (abs(px - o.position.x) > 140f || abs(py - o.position.y) > 140f) continue
            if (!o.containsPoint(px, py)) continue
            shell.isAlive = false
            val pan = panAt(px)
            fx.sparks(px, py, shell.ammoType.color, 6)
            if (o.destructible) {
                o.hp -= shell.baseDamage
                if (o.hp <= 0f) {
                    o.isAlive = false
                    val wood = o.kind == ObstacleKind.TRUNK
                    if (wood) fx.debris(o.position.x, o.position.y, 0.3f, 0.5f, 0.2f)
                    else fx.debris(o.position.x, o.position.y, 0.5f, 0.45f, 0.40f)
                    AudioManager.playCrash(volumeAt(px, py, 0.9f), pan)
                    if (o.kind != ObstacleKind.TRUNK) fx.explosion(o.position.x, o.position.y, 0.5f)
                } else {
                    AudioManager.playThud(volumeAt(px, py, 0.7f), pan)
                }
            } else {
                AudioManager.playThud(volumeAt(px, py, 0.7f), pan)
                if (shell.ammoType == AmmoType.HE) fx.explosion(px, py, 0.5f)
            }
            return true
        }
        return false
    }

    private fun hitTank(shell: ProjectileEntity) {
        val px = shell.position.x
        val py = shell.position.y
        for (tank in allTanks) {
            if (!tank.isAlive || tank.team == shell.team) continue
            if (shell.ignoreTimer > 0f && tank.id == shell.ignoreTankId) continue
            if (tank.position.dst2(px, py) > 140f * 140f) continue
            if (!tank.containsPoint(px, py)) continue

            val fromPlayer = shell.ownerId == playerTank.id
            if (fromPlayer) playerHits++
            val result = DamageCalculator.resolveHit(shell, tank, px, py)

            if (result.ricochet) {
                shell.ricochet(result.reflectAngleDeg, tank.id)
                if (shell.bounces > 2) shell.isAlive = false
                fx.sparks(px, py, shell.ammoType.color, 8)
                AudioManager.playRicochet(volumeAt(px, py, 0.8f), panAt(px))
                addFloatingText(if (tank.team == Team.ENEMY) "RICOCHET!" else "BOUNCED!", tank.position.x, tank.position.y + 50f)
                if (fromPlayer) playerRicochets++
            } else if (result.damageDealt > 0f) {
                tank.takeDamage(result.damageDealt)
                val label = if (result.penetrated) "-" else "SPLASH -"
                addFloatingText(label + result.damageDealt.toInt(), tank.position.x, tank.position.y + 50f)
                fx.explosion(px, py, if (result.penetrated) 0.6f else 0.35f)
                addLight(px, py, 170f, 0.8f, 0.18f)
                AudioManager.playHit(volumeAt(px, py, 0.9f), panAt(px))
                if (tank === playerTank) shake = maxOf(shake, minOf(16f, 4f + result.damageDealt / 12f))
                if (fromPlayer) playerDamage += result.damageDealt
                shell.isAlive = false
                if (!tank.isAlive) onTankDestroyed(tank, fromPlayer)
            } else {
                addFloatingText("NO PENETRATION", tank.position.x, tank.position.y + 50f)
                fx.sparks(px, py, shell.ammoType.color, 5)
                AudioManager.playRicochet(volumeAt(px, py, 0.5f), panAt(px))
                shell.isAlive = false
            }
            return
        }
    }

    private fun onTankDestroyed(tank: TankEntity, byPlayer: Boolean) {
        fx.explosion(tank.position.x, tank.position.y, 1.6f)
        addLight(tank.position.x, tank.position.y, 430f, 1f, 0.55f)
        AudioManager.playExplosion(volumeAt(tank.position.x, tank.position.y, 1f), panAt(tank.position.x))
        if (tank === playerTank) shake = 18f else shake = maxOf(shake, 7f)
        addFloatingText("DESTROYED: " + tank.spec.shortName, tank.position.x, tank.position.y + 70f)
        if (tank.team == Team.ENEMY) {
            enemiesDestroyed++
            if (byPlayer) playerKills++
        }
    }

    // -------------------------------------------------------------- render

    fun render(batch: SpriteBatch, camX: Float, camY: Float) {
        val ts = GameConfig.TILE_SIZE
        val cols = (GameConfig.MAP_WIDTH / ts).toInt()
        val rows = (GameConfig.MAP_HEIGHT / ts).toInt()
        val halfW = GameConfig.VIRTUAL_WIDTH / 2f
        val halfH = GameConfig.VIRTUAL_HEIGHT / 2f

        val minCol = ((camX - halfW) / ts).toInt().coerceIn(0, cols - 1)
        val maxCol = ((camX + halfW) / ts).toInt().coerceIn(0, cols - 1)
        val minRow = ((camY - halfH) / ts).toInt().coerceIn(0, rows - 1)
        val maxRow = ((camY + halfH) / ts).toInt().coerceIn(0, rows - 1)

        for (cx in minCol..maxCol) {
            for (cy in minRow..maxRow) {
                val v = ((cx * 7 + cy * 13) % 3 + 3) % 3
                batch.draw(groundTiles[v], cx * ts, cy * ts)
            }
        }

        // 1) flat decoration: roads, craters, floors, dunes, swamps
        for (o in flat) if (nearCamera(o, camX, camY)) o.renderBase(batch)
        for (o in swamps) if (nearCamera(o, camX, camY)) o.renderBase(batch)
        fx.renderGround(batch)
        // 2) solid objects: walls, rocks, trunks, wrecks
        for (o in obstacles) {
            if (o.isFlat() || o.kind == ObstacleKind.BUSH) continue
            if (nearCamera(o, camX, camY)) o.renderBase(batch)
        }
        // 3) tanks (hidden enemies are not drawn)
        allTanks.forEach { if (!it.isAlive && vision.isSpotted(it)) it.render(batch) }
        allTanks.forEach { if (it.isAlive && it !== playerTank && vision.isSpotted(it)) it.render(batch) }
        if (playerTank.isAlive) playerTank.render(batch)
        // 4) shells
        for (p in projectiles) {
            if (p.team == Team.FRIEND || vision.lit(p.position.x, p.position.y, friendsOf()) > 0.25f) p.render(batch)
        }
        fx.render(batch)
        // 5) tree canopies and bushes cover the tanks
        for (o in tops) if (nearCamera(o, camX, camY)) o.renderTop(batch)
        // 6) fog of war with the spotlight
        var count = 0
        for (li in lights.indices.reversed()) {
            val l = lights[li]
            if (count >= 6) break
            val f = (l.life / l.maxLife).coerceIn(0f, 1f)
            lightData[count * 4] = l.x
            lightData[count * 4 + 1] = l.y
            lightData[count * 4 + 2] = l.radius
            lightData[count * 4 + 3] = l.intensity * f
            count++
        }
        vision.render(batch, camX, camY, friendsOf(), lightData, count)

        val font = AssetManager.fontSmall
        for (msg in floatingMessages) {
            if (vision.lit(msg.x, msg.y, friendsOf()) > 0.2f) font.draw(batch, msg.text, msg.x - 36f, msg.y)
        }
    }

    private val friendCache = ArrayList<TankEntity>()

    /** Friendly tanks other than the player (they light up the area around them). */
    fun friendsOf(): List<TankEntity> {
        friendCache.clear()
        for (t in allTanks) {
            if (t.isAlive && t.team == Team.FRIEND && t !== playerTank) friendCache.add(t)
        }
        return friendCache
    }

    private fun nearCamera(o: ObstacleEntity, camX: Float, camY: Float): Boolean {
        val reach = maxOf(o.width, o.height) * 0.75f + 20f
        return abs(o.position.x - camX) < GameConfig.VIRTUAL_WIDTH / 2f + reach &&
            abs(o.position.y - camY) < GameConfig.VIRTUAL_HEIGHT / 2f + reach
    }

    private fun addFloatingText(text: String, x: Float, y: Float) {
        floatingMessages.add(FloatingText(text, x, y, 1.1f))
    }

    data class FloatingText(val text: String, var x: Float, var y: Float, var timer: Float)

    companion object {
        private const val SWEEP_STEP = 4f
    }
}
