package com.ironfront.battlefield

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector2
import com.ironfront.ai.EnemyAIController
import com.ironfront.audio.AudioManager
import com.ironfront.combat.DamageCalculator
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.entities.ObstacleEntity
import com.ironfront.entities.ProjectileEntity
import com.ironfront.fx.FxSystem
import com.ironfront.maps.BattleSetup
import com.ironfront.physics.CollisionSystem
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankEntity
import com.ironfront.teams.Team
import com.ironfront.weapons.AmmoType
import kotlin.math.abs
import kotlin.math.ceil

class BattlefieldWorld(val playerTank: TankEntity, val setup: BattleSetup) {
    val map = setup.map

    private val allTanks = mutableListOf<TankEntity>()
    private val aiControllers = mutableListOf<EnemyAIController>()
    val projectiles = mutableListOf<ProjectileEntity>()
    val obstacles = mutableListOf<ObstacleEntity>()
    val fx = FxSystem()

    val tanks: List<TankEntity> get() = allTanks

    var enemiesDestroyed = 0
        private set
    var totalEnemies = 0
        private set
    var totalFriends = 0
        private set

    // statistics of the player for the result screen
    var playerShots = 0
        private set
    var playerHits = 0
        private set
    var playerRicochets = 0
        private set
    var playerKills = 0
        private set
    var playerDamage = 0f
        private set

    var floatingMessages = mutableListOf<FloatingText>()

    private val groundTiles = Array(3) { AssetManager.getTexture("ground_${map.id}_$it") }
    private var smokeTimer = 0f

    init {
        map.obstacles.forEachIndexed { i, d ->
            val o = ObstacleEntity("obs_$i", d.x, d.y, d.w, d.h, d.destructible, d.texture)
            if (d.destructible) o.hp = 140f
            obstacles.add(o)
        }
        allTanks.add(playerTank)
        spawnBots()
        totalEnemies = allTanks.count { it.team == Team.ENEMY }
        totalFriends = allTanks.count { it.team == Team.FRIEND }
    }

    fun enemiesAlive(): Int = allTanks.count { it.isAlive && it.team == Team.ENEMY }
    fun friendsAlive(): Int = allTanks.count { it.isAlive && it.team == Team.FRIEND }

    // ------------------------------------------------------------ spawning

    private fun spawnBots() {
        setup.bots.forEachIndexed { idx, bot ->
            val spec = TankDatabase.get(bot.tankId)
            val pos = if (bot.team == Team.ENEMY) {
                val z = map.enemyZone
                findFreeSpot(z.minX, z.maxX, z.minY, z.maxY)
            } else {
                val px = playerTank.position.x
                val py = playerTank.position.y
                findFreeSpot(
                    MathUtils.clamp(px - 260f, 100f, GameConfig.MAP_WIDTH - 100f),
                    MathUtils.clamp(px + 260f, 100f, GameConfig.MAP_WIDTH - 100f),
                    MathUtils.clamp(py - 260f, 100f, GameConfig.MAP_HEIGHT - 100f),
                    MathUtils.clamp(py + 260f, 100f, GameConfig.MAP_HEIGHT - 100f)
                )
            }
            val tank = TankEntity("bot_$idx", spec, pos.x, pos.y, playerControlled = false, team = bot.team)
            tank.rotation = if (bot.team == Team.ENEMY) 225f else 45f
            tank.turretRotation = tank.rotation
            tank.desiredTurretRotation = tank.rotation
            allTanks.add(tank)
            aiControllers.add(EnemyAIController(tank))
        }
    }

    private fun findFreeSpot(minX: Float, maxX: Float, minY: Float, maxY: Float): Vector2 {
        val last = Vector2((minX + maxX) / 2f, (minY + maxY) / 2f)
        for (attempt in 0 until 100) {
            val x = MathUtils.random(minX, maxX)
            val y = MathUtils.random(minY, maxY)
            if (isSpotFree(x, y)) return Vector2(x, y)
            last.set(x, y)
        }
        return last
    }

    private fun isSpotFree(x: Float, y: Float): Boolean {
        val half = 62f
        for (o in obstacles) {
            if (abs(x - o.position.x) < o.width / 2f + half && abs(y - o.position.y) < o.height / 2f + half) {
                return false
            }
        }
        for (t in allTanks) {
            if (t.position.dst(x, y) < 120f) return false
        }
        return true
    }

    // -------------------------------------------------------------- firing

    /** Adds a freshly fired shell to the world and plays flash and sound. */
    fun fireShell(shell: ProjectileEntity, shooter: TankEntity) {
        projectiles.add(shell)
        fx.muzzleFlash(shooter.muzzleX, shooter.muzzleY, shooter.turretRotation)
        if (shooter === playerTank) playerShots++
        AudioManager.playCannonFire(volumeAt(shooter.position.x, shooter.position.y, 1f))
    }

    private fun volumeAt(x: Float, y: Float, base: Float): Float {
        val d = playerTank.position.dst(x, y)
        return (base * (1f - d / 1100f)).coerceIn(0.12f, 1f)
    }

    // -------------------------------------------------------------- update

    private fun resolveWorld(tank: TankEntity) {
        CollisionSystem.resolveTankWorldBounds(tank)
        for (o in obstacles) CollisionSystem.resolveTankObstacle(tank, o)
    }

    fun update(delta: Float) {
        playerTank.update(delta)
        resolveWorld(playerTank)

        for (ai in aiControllers) {
            val bot = ai.tank
            if (!bot.isAlive) {
                bot.update(delta)
                continue
            }
            val targets = allTanks.filter { it.isAlive && it.team != bot.team }
            val leader = if (bot.team == Team.FRIEND && playerTank.isAlive) playerTank else null
            val fired = ai.update(delta, targets, leader)
            if (fired != null) fireShell(fired, bot)
            bot.update(delta)
            resolveWorld(bot)
        }

        for (i in 0 until allTanks.size) {
            for (j in i + 1 until allTanks.size) {
                CollisionSystem.resolveTankVsTank(allTanks[i], allTanks[j])
            }
        }

        updateProjectiles(delta)
        obstacles.removeAll { !it.isAlive }

        smokeTimer -= delta
        if (smokeTimer <= 0f) {
            smokeTimer = 0.18f
            for (t in allTanks) {
                if (!t.isAlive && t.wreckTime > 15f) fx.smoke(t.position.x, t.position.y)
            }
        }
        for (t in allTanks) {
            if (!t.isAlive) t.update(delta)
        }

        fx.update(delta)
        floatingMessages.forEach {
            it.timer -= delta
            it.y += 28f * delta
        }
        floatingMessages.removeAll { it.timer <= 0f }
    }

    private fun updateProjectiles(delta: Float) {
        val iter = projectiles.iterator()
        while (iter.hasNext()) {
            val shell = iter.next()
            shell.tick(delta)

            if (shell.isAlive) {
                val total = shell.speed * delta
                val steps = ceil(total / SWEEP_STEP).toInt().coerceAtLeast(1)
                val stepLen = total / steps
                var s = 0
                while (s < steps && shell.isAlive) {
                    val dx = MathUtils.cosDeg(shell.rotation)
                    val dy = MathUtils.sinDeg(shell.rotation)
                    shell.position.add(dx * stepLen, dy * stepLen)
                    shell.traveled += stepLen
                    if (!hitObstacle(shell)) {
                        hitTank(shell)
                    }
                    s++
                }
            }
            if (!shell.isAlive) iter.remove()
        }
    }

    private fun hitObstacle(shell: ProjectileEntity): Boolean {
        val px = shell.position.x
        val py = shell.position.y
        for (o in obstacles) {
            if (!o.isAlive || !o.containsPoint(px, py)) continue
            shell.isAlive = false
            fx.sparks(px, py, shell.ammoType.color, 6)
            if (o.destructible) {
                o.hp -= shell.baseDamage
                if (o.hp <= 0f) {
                    o.isAlive = false
                    fx.explosion(o.position.x, o.position.y, 0.6f)
                    AudioManager.playHit(volumeAt(px, py, 0.7f))
                }
            } else if (shell.ammoType == AmmoType.HE) {
                fx.explosion(px, py, 0.5f)
            }
            return true
        }
        return false
    }

    private fun hitTank(shell: ProjectileEntity) {
        val px = shell.position.x
        val py = shell.position.y
        for (tank in allTanks) {
            if (!tank.isAlive || tank.team == shell.team) continue
            if (shell.ignoreTimer > 0f && tank.id == shell.ignoreTankId) continue
            if (tank.position.dst2(px, py) > 140f * 140f) continue
            if (!tank.containsPoint(px, py)) continue

            val fromPlayer = shell.ownerId == playerTank.id
            if (fromPlayer) playerHits++
            val result = DamageCalculator.resolveHit(shell, tank, px, py)

            if (result.ricochet) {
                shell.ricochet(result.reflectAngleDeg, tank.id)
                if (shell.bounces > 2) shell.isAlive = false
                fx.sparks(px, py, shell.ammoType.color, 8)
                AudioManager.playRicochet(volumeAt(px, py, 0.8f))
                addFloatingText(if (tank.team == Team.ENEMY) "RICOCHET!" else "BOUNCED!", tank.position.x, tank.position.y + 50f)
                if (fromPlayer) playerRicochets++
            } else if (result.damageDealt > 0f) {
                tank.takeDamage(result.damageDealt)
                val label = if (result.penetrated) "-" else "SPLASH -"
                addFloatingText(label + result.damageDealt.toInt(), tank.position.x, tank.position.y + 50f)
                fx.explosion(px, py, if (result.penetrated) 0.6f else 0.35f)
                AudioManager.playHit(volumeAt(px, py, 0.9f))
                if (fromPlayer) playerDamage += result.damageDealt
                shell.isAlive = false
                if (!tank.isAlive) onTankDestroyed(tank, fromPlayer)
            } else {
                addFloatingText("NO PENETRATION", tank.position.x, tank.position.y + 50f)
                fx.sparks(px, py, shell.ammoType.color, 5)
                AudioManager.playRicochet(volumeAt(px, py, 0.5f))
                shell.isAlive = false
            }
            return
        }
    }

    private fun onTankDestroyed(tank: TankEntity, byPlayer: Boolean) {
        fx.explosion(tank.position.x, tank.position.y, 1.6f)
        AudioManager.playExplosion(volumeAt(tank.position.x, tank.position.y, 1f))
        addFloatingText("DESTROYED: " + tank.spec.shortName, tank.position.x, tank.position.y + 70f)
        if (tank.team == Team.ENEMY) {
            enemiesDestroyed++
            if (byPlayer) playerKills++
        }
    }

    // -------------------------------------------------------------- render

    fun render(batch: SpriteBatch, camX: Float, camY: Float) {
        val ts = GameConfig.TILE_SIZE
        val cols = (GameConfig.MAP_WIDTH / ts).toInt()
        val rows = (GameConfig.MAP_HEIGHT / ts).toInt()
        val halfW = GameConfig.VIRTUAL_WIDTH / 2f
        val halfH = GameConfig.VIRTUAL_HEIGHT / 2f

        val minCol = ((camX - halfW) / ts).toInt().coerceIn(0, cols - 1)
        val maxCol = ((camX + halfW) / ts).toInt().coerceIn(0, cols - 1)
        val minRow = ((camY - halfH) / ts).toInt().coerceIn(0, rows - 1)
        val maxRow = ((camY + halfH) / ts).toInt().coerceIn(0, rows - 1)

        for (cx in minCol..maxCol) {
            for (cy in minRow..maxRow) {
                val v = ((cx * 7 + cy * 13) % 3 + 3) % 3
                batch.draw(groundTiles[v], cx * ts, cy * ts)
            }
        }

        obstacles.forEach { it.render(batch) }
        allTanks.forEach { if (!it.isAlive) it.render(batch) }
        allTanks.forEach { if (it.isAlive && it !== playerTank) it.render(batch) }
        if (playerTank.isAlive) playerTank.render(batch)
        projectiles.forEach { it.render(batch) }
        fx.render(batch)

        val font = AssetManager.fontSmall
        for (msg in floatingMessages) {
            font.draw(batch, msg.text, msg.x - 36f, msg.y)
        }
    }

    private fun addFloatingText(text: String, x: Float, y: Float) {
        floatingMessages.add(FloatingText(text, x, y, 1.1f))
    }

    data class FloatingText(val text: String, var x: Float, var y: Float, var timer: Float)

    companion object {
        private const val SWEEP_STEP = 4f
    }
}
