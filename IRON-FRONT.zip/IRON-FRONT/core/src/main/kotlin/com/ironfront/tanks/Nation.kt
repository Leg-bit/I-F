package com.ironfront.tanks

import com.badlogic.gdx.graphics.Color

enum class Side { ALLIES, AXIS }

enum class TankClass(val label: String) {
    LIGHT("LIGHT"), MEDIUM("MEDIUM"), HEAVY("HEAVY"), TANK_DESTROYER("TD")
}

/** Each nation has its own paint scheme and its own tank tree. */
enum class Nation(val label: String, val side: Side, val body: Color, val turret: Color, val track: Color) {
    USSR("USSR", Side.ALLIES, Color(0.26f, 0.38f, 0.20f, 1f), Color(0.31f, 0.44f, 0.24f, 1f), Color(0.13f, 0.19f, 0.10f, 1f)),
    GERMANY("GERMANY", Side.AXIS, Color(0.40f, 0.41f, 0.42f, 1f), Color(0.47f, 0.48f, 0.49f, 1f), Color(0.17f, 0.17f, 0.18f, 1f)),
    USA("USA", Side.ALLIES, Color(0.38f, 0.38f, 0.21f, 1f), Color(0.44f, 0.44f, 0.25f, 1f), Color(0.18f, 0.18f, 0.10f, 1f)),
    UK("UK", Side.ALLIES, Color(0.45f, 0.39f, 0.26f, 1f), Color(0.51f, 0.45f, 0.31f, 1f), Color(0.22f, 0.19f, 0.12f, 1f))
}
