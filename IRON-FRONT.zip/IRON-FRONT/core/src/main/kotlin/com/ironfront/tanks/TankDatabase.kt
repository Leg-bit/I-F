package com.ironfront.tanks

import com.ironfront.armor.ArmorPlate
import com.ironfront.armor.ArmorScheme
import com.ironfront.tanks.TankClass.HEAVY
import com.ironfront.tanks.TankClass.LIGHT
import com.ironfront.tanks.TankClass.MEDIUM
import com.ironfront.tanks.TankClass.TANK_DESTROYER
import com.ironfront.tanks.Nation.GERMANY
import com.ironfront.tanks.Nation.UK
import com.ironfront.tanks.Nation.USA
import com.ironfront.tanks.Nation.USSR
import com.ironfront.weapons.Guns

/**
 * Real-life tanks, 4 nations. Armor is (thickness mm, slope from vertical deg).
 * Hull and turret are given as front / side / rear. For tank destroyers the
 * "turret" plates are the fixed casemate.
 */
object TankDatabase {
    private val specs = linkedMapOf<String, TankSpec>()

    private fun p(mm: Int, deg: Int) = ArmorPlate(mm.toFloat(), deg.toFloat())

    private fun armor(
        hf: ArmorPlate, hs: ArmorPlate, hr: ArmorPlate,
        tf: ArmorPlate, ts: ArmorPlate, tr: ArmorPlate
    ) = ArmorScheme(hf, hs, hr, tf, ts, tr)

    private fun reg(spec: TankSpec) {
        specs[spec.id] = spec
    }

    fun load() {
        specs.clear()
        registerUssr()
        registerGermany()
        registerUsa()
        registerUk()
    }

    fun get(id: String): TankSpec = specs[id] ?: specs.values.first()
    fun all(): List<TankSpec> = specs.values.toList()
    fun byNation(nation: Nation): List<TankSpec> = specs.values.filter { it.nation == nation }

    // ------------------------------------------------------------------ USSR
    private fun registerUssr() {
        reg(TankSpec(
            id = "t26", shortName = "T-26", name = "T-26 mod. 1933", nation = USSR, tier = 1, tankClass = LIGHT, year = 1933,
            massT = 9.4f, hullLengthM = 4.6f, hullWidthM = 2.41f, hullHeightM = 2.33f, crew = 3, enginePowerHp = 91, maxSpeedKmh = 31f,
            armor = armor(p(15, 0), p(15, 0), p(15, 0), p(15, 0), p(15, 0), p(15, 0)),
            gun = Guns.K20_45, turretDiameterM = 1.3f, turretTraverseDegS = 12f, treeRow = 1
        ))
        reg(TankSpec(
            id = "bt7", shortName = "BT-7", name = "BT-7 mod. 1937", nation = USSR, tier = 2, tankClass = LIGHT, year = 1937,
            massT = 13.8f, hullLengthM = 5.66f, hullWidthM = 2.29f, hullHeightM = 2.42f, crew = 3, enginePowerHp = 450, maxSpeedKmh = 53f,
            armor = armor(p(15, 30), p(15, 0), p(13, 0), p(15, 0), p(15, 0), p(15, 0)),
            gun = Guns.K20_45, turretDiameterM = 1.4f, turretTraverseDegS = 15f,
            parents = listOf("t26"), treeRow = 1, researchCostXp = 300, purchaseCostCredits = 2500
        ))
        reg(TankSpec(
            id = "t34", shortName = "T-34", name = "T-34 mod. 1941", nation = USSR, tier = 3, tankClass = MEDIUM, year = 1941,
            massT = 26.5f, hullLengthM = 5.92f, hullWidthM = 3.0f, hullHeightM = 2.45f, crew = 4, enginePowerHp = 500, maxSpeedKmh = 53f,
            armor = armor(p(45, 60), p(40, 40), p(40, 49), p(52, 20), p(45, 30), p(45, 30)),
            gun = Guns.F34, turretDiameterM = 1.9f, turretTraverseDegS = 18f,
            parents = listOf("bt7"), treeRow = 0, researchCostXp = 1000, purchaseCostCredits = 9000
        ))
        reg(TankSpec(
            id = "kv1", shortName = "KV-1", name = "KV-1 mod. 1941", nation = USSR, tier = 3, tankClass = HEAVY, year = 1941,
            massT = 45f, hullLengthM = 6.75f, hullWidthM = 3.32f, hullHeightM = 2.71f, crew = 5, enginePowerHp = 600, maxSpeedKmh = 35f,
            armor = armor(p(75, 30), p(75, 0), p(70, 0), p(90, 20), p(75, 15), p(75, 15)),
            gun = Guns.ZIS5, turretDiameterM = 2.1f, turretTraverseDegS = 12f,
            parents = listOf("bt7"), treeRow = 2, researchCostXp = 1100, purchaseCostCredits = 10000
        ))
        reg(TankSpec(
            id = "t3485", shortName = "T-34-85", name = "T-34-85 mod. 1944", nation = USSR, tier = 4, tankClass = MEDIUM, year = 1944,
            massT = 32f, hullLengthM = 6.1f, hullWidthM = 3.0f, hullHeightM = 2.72f, crew = 5, enginePowerHp = 500, maxSpeedKmh = 55f,
            armor = armor(p(45, 60), p(45, 40), p(45, 47), p(90, 15), p(75, 20), p(52, 20)),
            gun = Guns.ZIS_S53, turretDiameterM = 2.2f, turretTraverseDegS = 20f,
            parents = listOf("t34"), treeRow = 0, researchCostXp = 2500, purchaseCostCredits = 22000
        ))
        reg(TankSpec(
            id = "su85", shortName = "SU-85", name = "SU-85 tank destroyer", nation = USSR, tier = 4, tankClass = TANK_DESTROYER, year = 1943,
            massT = 29.6f, hullLengthM = 6.1f, hullWidthM = 3.0f, hullHeightM = 2.45f, crew = 4, enginePowerHp = 500, maxSpeedKmh = 55f,
            armor = armor(p(45, 50), p(45, 40), p(45, 47), p(45, 50), p(45, 20), p(40, 0)),
            gun = Guns.D5S, turretDiameterM = 0f, turretTraverseDegS = 10f, hasTurret = false, traverseLimitDeg = 10f,
            parents = listOf("t34"), treeRow = 1, researchCostXp = 2400, purchaseCostCredits = 21000
        ))
        reg(TankSpec(
            id = "is2", shortName = "IS-2", name = "IS-2 mod. 1944", nation = USSR, tier = 5, tankClass = HEAVY, year = 1944,
            massT = 46f, hullLengthM = 6.77f, hullWidthM = 3.09f, hullHeightM = 2.73f, crew = 4, enginePowerHp = 520, maxSpeedKmh = 37f,
            armor = armor(p(120, 60), p(90, 15), p(60, 45), p(120, 15), p(100, 20), p(100, 20)),
            gun = Guns.D25T, turretDiameterM = 2.3f, turretTraverseDegS = 14f,
            parents = listOf("kv1"), treeRow = 2, researchCostXp = 5500, purchaseCostCredits = 55000
        ))
    }

    // --------------------------------------------------------------- GERMANY
    private fun registerGermany() {
        reg(TankSpec(
            id = "pz2f", shortName = "Pz.II F", name = "Pz.Kpfw. II Ausf. F", nation = GERMANY, tier = 1, tankClass = LIGHT, year = 1941,
            massT = 9.5f, hullLengthM = 4.81f, hullWidthM = 2.28f, hullHeightM = 2.15f, crew = 3, enginePowerHp = 140, maxSpeedKmh = 40f,
            armor = armor(p(35, 9), p(15, 0), p(15, 0), p(30, 10), p(15, 0), p(15, 0)),
            gun = Guns.KWK38_20, turretDiameterM = 1.5f, turretTraverseDegS = 20f, treeRow = 1
        ))
        reg(TankSpec(
            id = "pz3j", shortName = "Pz.III J", name = "Pz.Kpfw. III Ausf. J", nation = GERMANY, tier = 2, tankClass = MEDIUM, year = 1941,
            massT = 21.5f, hullLengthM = 5.52f, hullWidthM = 2.95f, hullHeightM = 2.5f, crew = 5, enginePowerHp = 300, maxSpeedKmh = 40f,
            armor = armor(p(50, 9), p(30, 0), p(50, 10), p(50, 12), p(30, 0), p(30, 0)),
            gun = Guns.KWK38_50, turretDiameterM = 1.9f, turretTraverseDegS = 20f,
            parents = listOf("pz2f"), treeRow = 1, researchCostXp = 450, purchaseCostCredits = 3500
        ))
        reg(TankSpec(
            id = "pz4f2", shortName = "Pz.IV F2", name = "Pz.Kpfw. IV Ausf. F2", nation = GERMANY, tier = 3, tankClass = MEDIUM, year = 1942,
            massT = 23.6f, hullLengthM = 5.92f, hullWidthM = 2.88f, hullHeightM = 2.68f, crew = 5, enginePowerHp = 300, maxSpeedKmh = 40f,
            armor = armor(p(50, 12), p(30, 0), p(20, 8), p(50, 10), p(30, 0), p(30, 0)),
            gun = Guns.KWK40, turretDiameterM = 2.0f, turretTraverseDegS = 14f,
            parents = listOf("pz3j"), treeRow = 1, researchCostXp = 1200, purchaseCostCredits = 10000
        ))
        reg(TankSpec(
            id = "stug3g", shortName = "StuG III G", name = "StuG III Ausf. G", nation = GERMANY, tier = 3, tankClass = TANK_DESTROYER, year = 1942,
            massT = 23.9f, hullLengthM = 5.4f, hullWidthM = 2.95f, hullHeightM = 2.16f, crew = 4, enginePowerHp = 300, maxSpeedKmh = 40f,
            armor = armor(p(80, 9), p(30, 0), p(30, 0), p(80, 10), p(30, 0), p(30, 0)),
            gun = Guns.STUK40, turretDiameterM = 0f, turretTraverseDegS = 12f, hasTurret = false, traverseLimitDeg = 12f,
            parents = listOf("pz3j"), treeRow = 2, researchCostXp = 1300, purchaseCostCredits = 11000
        ))
        reg(TankSpec(
            id = "pantherg", shortName = "Panther G", name = "Pz.Kpfw. V Panther Ausf. G", nation = GERMANY, tier = 4, tankClass = MEDIUM, year = 1944,
            massT = 44.8f, hullLengthM = 6.87f, hullWidthM = 3.27f, hullHeightM = 2.99f, crew = 5, enginePowerHp = 700, maxSpeedKmh = 46f,
            armor = armor(p(80, 55), p(50, 30), p(40, 30), p(100, 12), p(45, 25), p(45, 25)),
            gun = Guns.KWK42, turretDiameterM = 2.4f, turretTraverseDegS = 18f,
            parents = listOf("pz4f2"), treeRow = 0, researchCostXp = 3000, purchaseCostCredits = 28000
        ))
        reg(TankSpec(
            id = "tiger1", shortName = "Tiger I", name = "Pz.Kpfw. VI Ausf. E Tiger", nation = GERMANY, tier = 4, tankClass = HEAVY, year = 1943,
            massT = 57f, hullLengthM = 6.3f, hullWidthM = 3.55f, hullHeightM = 3.0f, crew = 5, enginePowerHp = 700, maxSpeedKmh = 38f,
            armor = armor(p(100, 9), p(80, 0), p(80, 8), p(100, 8), p(80, 0), p(80, 0)),
            gun = Guns.KWK36, turretDiameterM = 2.4f, turretTraverseDegS = 14f,
            parents = listOf("pz4f2"), treeRow = 1, researchCostXp = 3300, purchaseCostCredits = 30000
        ))
        reg(TankSpec(
            id = "tiger2", shortName = "Tiger II", name = "Pz.Kpfw. VI Ausf. B Konigstiger", nation = GERMANY, tier = 5, tankClass = HEAVY, year = 1944,
            massT = 68.5f, hullLengthM = 7.38f, hullWidthM = 3.75f, hullHeightM = 3.09f, crew = 5, enginePowerHp = 700, maxSpeedKmh = 41.5f,
            armor = armor(p(150, 50), p(80, 25), p(80, 30), p(180, 10), p(80, 20), p(80, 20)),
            gun = Guns.KWK43, turretDiameterM = 2.6f, turretTraverseDegS = 19f,
            parents = listOf("tiger1"), treeRow = 1, researchCostXp = 6500, purchaseCostCredits = 70000
        ))
    }

    // ------------------------------------------------------------------- USA
    private fun registerUsa() {
        reg(TankSpec(
            id = "m3stuart", shortName = "M3 Stuart", name = "M3 Light Tank (Stuart)", nation = USA, tier = 1, tankClass = LIGHT, year = 1941,
            massT = 12.7f, hullLengthM = 4.54f, hullWidthM = 2.24f, hullHeightM = 2.3f, crew = 4, enginePowerHp = 250, maxSpeedKmh = 58f,
            armor = armor(p(51, 15), p(25, 0), p(25, 0), p(51, 0), p(38, 0), p(38, 0)),
            gun = Guns.M6_37, turretDiameterM = 1.5f, turretTraverseDegS = 25f, treeRow = 1
        ))
        reg(TankSpec(
            id = "m4a1", shortName = "M4A1", name = "M4A1 Sherman (75 mm)", nation = USA, tier = 3, tankClass = MEDIUM, year = 1942,
            massT = 30.3f, hullLengthM = 5.84f, hullWidthM = 2.62f, hullHeightM = 2.74f, crew = 5, enginePowerHp = 400, maxSpeedKmh = 39f,
            armor = armor(p(51, 56), p(38, 0), p(38, 10), p(76, 10), p(51, 10), p(51, 10)),
            gun = Guns.M3_75, turretDiameterM = 2.1f, turretTraverseDegS = 24f,
            parents = listOf("m3stuart"), treeRow = 1, researchCostXp = 900, purchaseCostCredits = 8000
        ))
        reg(TankSpec(
            id = "m4a3e8", shortName = "M4A3E8", name = "M4A3E8 Sherman Easy Eight", nation = USA, tier = 4, tankClass = MEDIUM, year = 1944,
            massT = 33.7f, hullLengthM = 5.84f, hullWidthM = 2.99f, hullHeightM = 2.74f, crew = 5, enginePowerHp = 500, maxSpeedKmh = 42f,
            armor = armor(p(64, 47), p(38, 0), p(38, 10), p(76, 10), p(51, 10), p(51, 10)),
            gun = Guns.M1A2_76, turretDiameterM = 2.1f, turretTraverseDegS = 24f,
            parents = listOf("m4a1"), treeRow = 0, researchCostXp = 2600, purchaseCostCredits = 24000
        ))
        reg(TankSpec(
            id = "m18", shortName = "M18", name = "M18 Hellcat", nation = USA, tier = 4, tankClass = TANK_DESTROYER, year = 1944,
            massT = 17f, hullLengthM = 5.05f, hullWidthM = 2.87f, hullHeightM = 2.58f, crew = 5, enginePowerHp = 400, maxSpeedKmh = 88f,
            armor = armor(p(13, 55), p(13, 0), p(13, 0), p(19, 0), p(13, 0), p(13, 0)),
            gun = Guns.M1A2_76, turretDiameterM = 2.0f, turretTraverseDegS = 24f,
            parents = listOf("m4a1"), treeRow = 2, researchCostXp = 2200, purchaseCostCredits = 20000
        ))
        reg(TankSpec(
            id = "m26", shortName = "M26", name = "M26 Pershing", nation = USA, tier = 5, tankClass = HEAVY, year = 1945,
            massT = 41.7f, hullLengthM = 6.3f, hullWidthM = 3.51f, hullHeightM = 2.78f, crew = 5, enginePowerHp = 500, maxSpeedKmh = 40f,
            armor = armor(p(102, 46), p(76, 0), p(51, 0), p(102, 10), p(76, 0), p(76, 0)),
            gun = Guns.M3_90, turretDiameterM = 2.3f, turretTraverseDegS = 22f,
            parents = listOf("m4a3e8"), treeRow = 0, researchCostXp = 5800, purchaseCostCredits = 60000
        ))
    }

    // -------------------------------------------------------------------- UK
    private fun registerUk() {
        reg(TankSpec(
            id = "matilda2", shortName = "Matilda II", name = "Infantry Tank Mk.II Matilda II", nation = UK, tier = 1, tankClass = HEAVY, year = 1940,
            massT = 26.9f, hullLengthM = 5.61f, hullWidthM = 2.59f, hullHeightM = 2.52f, crew = 4, enginePowerHp = 174, maxSpeedKmh = 24f,
            armor = armor(p(78, 20), p(65, 0), p(55, 0), p(75, 0), p(75, 0), p(75, 0)),
            gun = Guns.QF2, turretDiameterM = 1.8f, turretTraverseDegS = 15f, treeRow = 1
        ))
        reg(TankSpec(
            id = "crusader3", shortName = "Crusader", name = "Cruiser Mk.VI Crusader III", nation = UK, tier = 2, tankClass = MEDIUM, year = 1942,
            massT = 19.7f, hullLengthM = 5.97f, hullWidthM = 2.64f, hullHeightM = 2.24f, crew = 3, enginePowerHp = 340, maxSpeedKmh = 44f,
            armor = armor(p(51, 10), p(28, 0), p(32, 0), p(51, 5), p(51, 0), p(51, 0)),
            gun = Guns.QF6, turretDiameterM = 1.8f, turretTraverseDegS = 20f,
            parents = listOf("matilda2"), treeRow = 0, researchCostXp = 400, purchaseCostCredits = 3500
        ))
        reg(TankSpec(
            id = "cromwell4", shortName = "Cromwell", name = "Cruiser Mk.VIII Cromwell IV", nation = UK, tier = 3, tankClass = MEDIUM, year = 1944,
            massT = 27.9f, hullLengthM = 6.35f, hullWidthM = 2.9f, hullHeightM = 2.5f, crew = 5, enginePowerHp = 600, maxSpeedKmh = 52f,
            armor = armor(p(64, 18), p(32, 0), p(32, 0), p(76, 10), p(63, 0), p(57, 0)),
            gun = Guns.QF75, turretDiameterM = 2.2f, turretTraverseDegS = 24f,
            parents = listOf("crusader3"), treeRow = 0, researchCostXp = 1000, purchaseCostCredits = 9000
        ))
        reg(TankSpec(
            id = "churchill7", shortName = "Churchill", name = "Infantry Tank Mk.IV Churchill VII", nation = UK, tier = 4, tankClass = HEAVY, year = 1944,
            massT = 40.7f, hullLengthM = 7.44f, hullWidthM = 3.25f, hullHeightM = 2.45f, crew = 5, enginePowerHp = 350, maxSpeedKmh = 20f,
            armor = armor(p(152, 0), p(95, 0), p(50, 0), p(152, 0), p(95, 0), p(95, 0)),
            gun = Guns.QF75, turretDiameterM = 2.2f, turretTraverseDegS = 15f,
            parents = listOf("matilda2"), treeRow = 2, researchCostXp = 2300, purchaseCostCredits = 20000
        ))
        reg(TankSpec(
            id = "firefly", shortName = "Firefly", name = "Sherman Vc Firefly", nation = UK, tier = 4, tankClass = MEDIUM, year = 1944,
            massT = 32.3f, hullLengthM = 5.84f, hullWidthM = 2.62f, hullHeightM = 2.74f, crew = 4, enginePowerHp = 425, maxSpeedKmh = 40f,
            armor = armor(p(51, 56), p(38, 0), p(38, 10), p(76, 10), p(51, 10), p(51, 10)),
            gun = Guns.QF17, turretDiameterM = 2.1f, turretTraverseDegS = 20f,
            parents = listOf("cromwell4"), treeRow = 1, researchCostXp = 2700, purchaseCostCredits = 25000
        ))
        reg(TankSpec(
            id = "comet", shortName = "Comet", name = "Cruiser Mk.VIII Comet I (A34)", nation = UK, tier = 5, tankClass = MEDIUM, year = 1944,
            massT = 33f, hullLengthM = 6.55f, hullWidthM = 3.04f, hullHeightM = 2.67f, crew = 5, enginePowerHp = 600, maxSpeedKmh = 47f,
            armor = armor(p(76, 15), p(32, 0), p(32, 0), p(101, 0), p(63, 0), p(57, 0)),
            gun = Guns.QF77, turretDiameterM = 2.4f, turretTraverseDegS = 27f,
            parents = listOf("cromwell4"), treeRow = 0, researchCostXp = 5000, purchaseCostCredits = 52000
        ))
    }
}
