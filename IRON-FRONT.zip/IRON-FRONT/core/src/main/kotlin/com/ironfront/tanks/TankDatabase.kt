package com.ironfront.tanks

import com.ironfront.armor.ArmorFace
import com.ironfront.armor.ArmorProfile
import com.ironfront.nations.Nation
import com.ironfront.weapons.GunSpec

/**
 * Every playable tank. Numbers are based on the real vehicles
 * (weight, crew, engine power, speed, plate thickness and slope, gun penetration).
 * Armour is "thickness mm @ slope from vertical".
 */
object TankDatabase {
    private val specs = linkedMapOf<String, TankSpec>()
    private var loaded = false

    private val XP_COST = intArrayOf(150, 450, 1000, 2000, 3800, 6500)
    private val CREDIT_COST = intArrayOf(1500, 4000, 9000, 18000, 35000, 65000)

    fun load() {
        if (loaded) return
        loaded = true
        specs.clear()
        loadGermany()
        loadUssr()
        loadUsa()
        loadUk()
        loadJapan()
    }

    fun get(id: String): TankSpec = specs[id] ?: specs.values.first()
    fun all(): List<TankSpec> = specs.values.toList()
    fun ofNation(nation: Nation): List<TankSpec> = specs.values.filter { it.nation == nation }
    fun contains(id: String): Boolean = specs.containsKey(id)

    // ------------------------------------------------------------ helpers

    private fun f(thickness: Float, slope: Float = 0f) = ArmorFace(thickness, slope)

    private fun gun(
        name: String,
        caliber: Int,
        lengthCal: Int,
        ap: Float,
        apcr: Float,
        reload: Float,
        speed: Float,
        damage: Float = -1f
    ): GunSpec {
        val dmg = if (damage > 0f) damage else 12f + caliber * 1.75f
        return GunSpec(name, caliber, lengthCal, dmg, ap, apcr, reload, speed)
    }

    private fun add(
        id: String,
        name: String,
        short: String,
        nation: Nation,
        tier: Int,
        cls: TankClass,
        weight: Float,
        crew: Int,
        power: Int,
        kmh: Float,
        armor: ArmorProfile,
        gun: GunSpec,
        design: TankDesign,
        parents: List<String>,
        desc: String,
        arc: Float = 0f
    ) {
        val hp = 120f + weight * 14f
        val hullTurn = (135f - weight * 1.1f).coerceIn(55f, 125f)
        val turretTurn = if (arc > 0f) 35f else (165f - weight * 0.9f).coerceIn(45f, 150f)
        val idx = (tier - 1).coerceIn(0, XP_COST.size - 1)
        specs[id] = TankSpec(
            id = id,
            name = name,
            shortName = short,
            nation = nation,
            tier = tier,
            tankClass = cls,
            weightTons = weight,
            crew = crew,
            enginePowerHp = power,
            maxSpeedKmh = kmh,
            maxHp = hp,
            moveSpeed = kmh * 3.2f,
            hullTurnSpeedDeg = hullTurn,
            turretTurnSpeedDeg = turretTurn,
            armor = armor,
            gun = gun,
            design = design,
            parents = parents,
            researchCostXp = XP_COST[idx],
            purchaseCostCredits = CREDIT_COST[idx],
            description = desc,
            casemateArcDeg = arc
        )
    }

    private fun armor(
        hullF: ArmorFace, hullS: ArmorFace, hullR: ArmorFace,
        turF: ArmorFace, turS: ArmorFace, turR: ArmorFace
    ) = ArmorProfile(hullF, hullS, hullR, turF, turS, turR)

    // ------------------------------------------------------------ Germany

    private fun loadGermany() {
        val g = Nation.GERMANY

        add(
            "pz2_c", "Pz.Kpfw. II Ausf. C", "Pz II C", g, 1, TankClass.LIGHT,
            9.5f, 3, 140, 40f,
            armor(f(30f, 10f), f(14f), f(14f), f(30f, 10f), f(14f), f(14f)),
            gun("2 cm KwK 38 L/55", 20, 55, 40f, 66f, 0.9f, 830f, damage = 38f),
            TankDesign(
                hullLenM = 4.81f, hullWidM = 2.22f, trackWidM = 0.30f, noseM = 0.7f, noseTaper = 0.12f,
                turretShape = TurretShape.ROUND, turretLenM = 1.3f, turretWidM = 1.3f, turretOffsetM = 0.1f,
                barrelM = 1.1f, barrelThickPx = 2, mantletWidM = 0.4f, paint = Paint.PANZER_GREY, seed = 11
            ),
            emptyList(),
            "Fast scout armed with an autocannon. Thin armour, but it shoots very quickly."
        )

        add(
            "pz3_j", "Pz.Kpfw. III Ausf. J", "Pz III J", g, 2, TankClass.MEDIUM,
            21.5f, 5, 300, 40f,
            armor(f(50f, 10f), f(30f), f(50f, 5f), f(50f, 10f), f(30f), f(30f)),
            gun("5 cm KwK 38 L/42", 50, 42, 59f, 84f, 2.0f, 685f),
            TankDesign(
                hullLenM = 5.52f, hullWidM = 2.95f, trackWidM = 0.36f, noseM = 0.85f, skirts = true,
                turretShape = TurretShape.BOX, turretLenM = 1.9f, turretWidM = 1.75f, turretOffsetM = 0.15f,
                bustleM = 0.25f, barrelM = 2.1f, barrelThickPx = 3, mantletWidM = 0.55f,
                paint = Paint.PANZER_GREY, seed = 12
            ),
            listOf("pz2_c"),
            "The Wehrmacht's main battle tank of 1941. Reliable, five-man crew with good radios."
        )

        add(
            "stug3_g", "StuG III Ausf. G", "StuG III G", g, 3, TankClass.TANK_DESTROYER,
            23.9f, 4, 300, 40f,
            armor(f(50f, 15f), f(30f), f(30f), f(80f, 10f), f(30f), f(30f)),
            gun("7.5 cm StuK 40 L/48", 75, 48, 99f, 135f, 3.0f, 750f),
            TankDesign(
                hullLenM = 5.40f, hullWidM = 2.95f, trackWidM = 0.40f, noseM = 0.7f, noseTaper = 0.08f,
                skirts = true, casemate = true, turretShape = TurretShape.MOUNT, turretOffsetM = 0.75f,
                barrelM = 2.9f, barrelThickPx = 3, muzzle = Muzzle.SINGLE, mantletWidM = 0.45f,
                paint = Paint.GERMAN_CAMO, engineDeckFrac = 0.24f, seed = 13
            ),
            listOf("pz3_j"),
            "Low, hard-hitting assault gun. Fixed casemate: you must turn the hull to aim.",
            arc = 12f
        )

        add(
            "pz4_f2", "Pz.Kpfw. IV Ausf. F2", "Pz IV F2", g, 3, TankClass.MEDIUM,
            23.6f, 5, 300, 40f,
            armor(f(50f, 10f), f(30f), f(20f), f(50f, 10f), f(30f), f(30f)),
            gun("7.5 cm KwK 40 L/43", 75, 43, 91f, 126f, 3.1f, 740f),
            TankDesign(
                hullLenM = 5.92f, hullWidM = 2.88f, trackWidM = 0.40f, noseM = 0.9f, noseTaper = 0.08f,
                skirts = true, turretShape = TurretShape.BOX, turretLenM = 2.0f, turretWidM = 1.85f,
                turretOffsetM = 0.1f, bustleM = 0.35f, barrelM = 3.2f, barrelThickPx = 3,
                muzzle = Muzzle.DOUBLE, mantletWidM = 0.6f, paint = Paint.PANZER_GREY, seed = 14
            ),
            listOf("pz3_j"),
            "Long 75 mm gun made the Panzer IV a match for the T-34. Weak sides and rear."
        )

        add(
            "panther_d", "Pz.Kpfw. V Panther Ausf. D", "Panther D", g, 4, TankClass.MEDIUM,
            43f, 5, 700, 46f,
            armor(f(80f, 55f), f(40f, 30f), f(40f, 30f), f(100f, 12f), f(45f, 25f), f(45f, 25f)),
            gun("7.5 cm KwK 42 L/70", 75, 70, 149f, 194f, 3.8f, 935f),
            TankDesign(
                hullLenM = 6.87f, hullWidM = 3.27f, trackWidM = 0.55f, noseM = 1.2f, noseTaper = 0.14f,
                skirts = true, turretShape = TurretShape.ANGULAR, turretLenM = 2.2f, turretWidM = 2.0f,
                turretOffsetM = 0.3f, bustleM = 0.3f, barrelM = 5.0f, barrelThickPx = 4,
                muzzle = Muzzle.DOUBLE, mantletWidM = 0.6f, paint = Paint.GERMAN_CAMO, seed = 15
            ),
            listOf("pz4_f2"),
            "Sloped glacis, fast and with a superb long gun. The best medium tank of its day."
        )

        add(
            "tiger_1", "Pz.Kpfw. VI Tiger I", "Tiger I", g, 4, TankClass.HEAVY,
            57f, 5, 700, 38f,
            armor(f(100f, 9f), f(60f), f(80f), f(100f, 8f), f(80f), f(80f)),
            gun("8.8 cm KwK 36 L/56", 88, 56, 156f, 203f, 4.6f, 773f),
            TankDesign(
                hullLenM = 6.32f, hullWidM = 3.55f, trackWidM = 0.72f, noseM = 0.7f, noseTaper = 0.05f,
                skirts = true, turretShape = TurretShape.CAST, turretLenM = 2.3f, turretWidM = 2.1f,
                turretOffsetM = 0.15f, bustleM = 0.5f, barrelM = 4.9f, barrelThickPx = 4,
                muzzle = Muzzle.PEPPERPOT, mantletWidM = 0.55f, paint = Paint.PANZER_GREY, seed = 16
            ),
            listOf("pz4_f2"),
            "Thick, flat armour and the legendary 88. Slow and heavy, but it kills at any range."
        )

        add(
            "jagdpanther", "Jagdpanther", "Jagdpanther", g, 5, TankClass.TANK_DESTROYER,
            45.5f, 5, 700, 46f,
            armor(f(60f, 55f), f(50f, 30f), f(40f, 30f), f(80f, 55f), f(50f, 30f), f(40f, 30f)),
            gun("8.8 cm PaK 43 L/71", 88, 71, 202f, 237f, 4.6f, 1000f),
            TankDesign(
                hullLenM = 6.87f, hullWidM = 3.42f, trackWidM = 0.55f, noseM = 1.1f, noseTaper = 0.12f,
                skirts = true, casemate = true, turretShape = TurretShape.MOUNT, turretOffsetM = 1.0f,
                barrelM = 4.6f, barrelThickPx = 4, muzzle = Muzzle.DOUBLE, mantletWidM = 0.5f,
                paint = Paint.GERMAN_CAMO, seed = 17
            ),
            listOf("stug3_g", "panther_d"),
            "Panther chassis with a monster 88 mm in a sloped casemate. Deadly from ambush.",
            arc = 13f
        )

        add(
            "tiger_2", "Pz.Kpfw. VI Tiger II", "Tiger II", g, 6, TankClass.HEAVY,
            69.8f, 5, 700, 38f,
            armor(f(150f, 50f), f(80f, 25f), f(80f, 30f), f(180f, 10f), f(80f, 20f), f(80f, 20f)),
            gun("8.8 cm KwK 43 L/71", 88, 71, 202f, 237f, 5.0f, 1000f),
            TankDesign(
                hullLenM = 7.38f, hullWidM = 3.75f, trackWidM = 0.80f, noseM = 1.3f, noseTaper = 0.12f,
                skirts = true, turretShape = TurretShape.ANGULAR, turretLenM = 2.6f, turretWidM = 2.2f,
                turretOffsetM = 0.05f, bustleM = 0.35f, barrelM = 5.0f, barrelThickPx = 5,
                muzzle = Muzzle.DOUBLE, mantletWidM = 0.7f, paint = Paint.GERMAN_CAMO, seed = 18
            ),
            listOf("tiger_1", "jagdpanther"),
            "The King Tiger. Sloped 150 mm glacis and a 180 mm turret: almost unstoppable head-on."
        )
    }

    // ------------------------------------------------------------ USSR

    private fun loadUssr() {
        val s = Nation.USSR

        add(
            "t26", "T-26 Model 1933", "T-26", s, 1, TankClass.LIGHT,
            9.4f, 3, 91, 31f,
            armor(f(15f), f(15f), f(15f), f(15f), f(15f), f(15f)),
            gun("45 mm 20K", 45, 46, 55f, 77f, 1.9f, 760f),
            TankDesign(
                hullLenM = 4.65f, hullWidM = 2.44f, trackWidM = 0.32f, noseM = 0.55f, noseTaper = 0.15f,
                turretShape = TurretShape.ROUND, turretLenM = 1.55f, turretWidM = 1.45f, turretOffsetM = 0.2f,
                cupola = false, barrelM = 2.0f, barrelThickPx = 2, mantletWidM = 0.45f,
                paint = Paint.SOVIET_GREEN, seed = 21
            ),
            emptyList(),
            "Light infantry-support tank with riveted armour. Cheap and fragile."
        )

        add(
            "bt7", "BT-7 Model 1937", "BT-7", s, 2, TankClass.LIGHT,
            13.8f, 3, 450, 53f,
            armor(f(22f, 20f), f(15f), f(15f), f(15f), f(15f), f(15f)),
            gun("45 mm 20K", 45, 46, 55f, 77f, 1.8f, 760f),
            TankDesign(
                hullLenM = 5.66f, hullWidM = 2.29f, trackWidM = 0.32f, noseM = 0.8f, noseTaper = 0.12f,
                turretShape = TurretShape.ROUND, turretLenM = 1.6f, turretWidM = 1.5f, turretOffsetM = 0.0f,
                cupola = false, barrelM = 2.0f, barrelThickPx = 2, mantletWidM = 0.45f,
                paint = Paint.SOVIET_GREEN, seed = 22
            ),
            listOf("t26"),
            "Christie-suspension cavalry tank. Very quick; armour is paper thin."
        )

        add(
            "t34_76", "T-34/76 Model 1941", "T-34/76", s, 3, TankClass.MEDIUM,
            26.5f, 4, 500, 53f,
            armor(f(45f, 60f), f(45f, 40f), f(40f, 48f), f(52f, 30f), f(52f, 30f), f(52f, 30f)),
            gun("76.2 mm F-34", 76, 41, 69f, 105f, 3.1f, 662f),
            TankDesign(
                hullLenM = 6.10f, hullWidM = 3.00f, trackWidM = 0.50f, noseM = 1.0f, noseTaper = 0.10f,
                turretShape = TurretShape.OCTAGON, turretLenM = 2.0f, turretWidM = 1.9f, turretOffsetM = 0.45f,
                bustleM = 0.1f, cupola = false, barrelM = 2.9f, barrelThickPx = 3, mantletWidM = 0.55f,
                paint = Paint.SOVIET_GREEN, seed = 23
            ),
            listOf("bt7"),
            "Revolutionary sloped armour, wide tracks and a powerful diesel. Changed tank design forever."
        )

        add(
            "kv1", "KV-1 Model 1941", "KV-1", s, 3, TankClass.HEAVY,
            45f, 5, 600, 35f,
            armor(f(75f, 30f), f(75f), f(70f), f(75f, 10f), f(75f, 10f), f(75f, 10f)),
            gun("76.2 mm ZiS-5", 76, 41, 80f, 120f, 3.4f, 680f),
            TankDesign(
                hullLenM = 6.70f, hullWidM = 3.32f, trackWidM = 0.65f, noseM = 0.9f, noseTaper = 0.08f,
                turretShape = TurretShape.CAST, turretLenM = 2.1f, turretWidM = 2.0f, turretOffsetM = 0.3f,
                bustleM = 0.45f, cupola = false, barrelM = 3.0f, barrelThickPx = 3, mantletWidM = 0.55f,
                paint = Paint.SOVIET_GREEN, seed = 24
            ),
            listOf("t26"),
            "Armoured so heavily that early German guns simply bounced off. Slow and thirsty."
        )

        add(
            "t34_85", "T-34-85", "T-34-85", s, 4, TankClass.MEDIUM,
            32f, 5, 500, 55f,
            armor(f(45f, 60f), f(45f, 40f), f(45f, 48f), f(90f, 30f), f(75f, 20f), f(52f, 30f)),
            gun("85 mm D-5T", 85, 54, 111f, 144f, 3.6f, 792f),
            TankDesign(
                hullLenM = 6.10f, hullWidM = 3.00f, trackWidM = 0.50f, noseM = 1.0f, noseTaper = 0.10f,
                turretShape = TurretShape.OCTAGON, turretLenM = 2.3f, turretWidM = 2.2f, turretOffsetM = 0.55f,
                bustleM = 0.25f, barrelM = 3.8f, barrelThickPx = 4, mantletWidM = 0.6f,
                paint = Paint.SOVIET_GREEN, seed = 25
            ),
            listOf("t34_76"),
            "Bigger turret, 85 mm gun and a five-man crew: the T-34 that won the war."
        )

        add(
            "su_100", "SU-100", "SU-100", s, 4, TankClass.TANK_DESTROYER,
            31.6f, 4, 500, 50f,
            armor(f(75f, 50f), f(45f, 40f), f(45f, 40f), f(75f, 50f), f(45f, 20f), f(45f, 20f)),
            gun("100 mm D-10S", 100, 56, 160f, 195f, 5.0f, 900f),
            TankDesign(
                hullLenM = 6.10f, hullWidM = 3.00f, trackWidM = 0.50f, noseM = 1.0f, noseTaper = 0.10f,
                casemate = true, turretShape = TurretShape.MOUNT, turretOffsetM = 0.5f,
                barrelM = 4.0f, barrelThickPx = 4, mantletWidM = 0.5f, paint = Paint.SOVIET_GREEN, seed = 26
            ),
            listOf("t34_76"),
            "T-34 chassis carrying a 100 mm naval-derived gun. Cheap, compact, lethal.",
            arc = 8f
        )

        add(
            "is_2", "IS-2 Model 1944", "IS-2", s, 5, TankClass.HEAVY,
            46f, 4, 520, 37f,
            armor(f(120f, 60f), f(90f, 15f), f(60f, 40f), f(160f, 30f), f(100f, 20f), f(100f, 20f)),
            gun("122 mm D-25T", 122, 43, 175f, 0f, 6.2f, 800f),
            TankDesign(
                hullLenM = 6.77f, hullWidM = 3.07f, trackWidM = 0.65f, noseM = 1.1f, noseTaper = 0.08f,
                turretShape = TurretShape.CAST, turretLenM = 2.5f, turretWidM = 2.3f, turretOffsetM = 0.3f,
                bustleM = 0.2f, barrelM = 4.2f, barrelThickPx = 5, muzzle = Muzzle.DOUBLE, mantletWidM = 0.7f,
                paint = Paint.SOVIET_GREEN, seed = 27
            ),
            listOf("kv1", "t34_85"),
            "122 mm gun with huge high-explosive shells. Slow reload, devastating hits."
        )

        add(
            "is_3", "IS-3", "IS-3", s, 6, TankClass.HEAVY,
            46.5f, 4, 520, 37f,
            armor(f(110f, 60f), f(90f, 30f), f(60f, 40f), f(220f, 25f), f(150f, 25f), f(150f, 25f)),
            gun("122 mm D-25T", 122, 43, 175f, 0f, 5.8f, 800f),
            TankDesign(
                hullLenM = 6.77f, hullWidM = 3.09f, trackWidM = 0.65f, noseM = 1.4f, noseTaper = 0.18f,
                turretShape = TurretShape.FLAT_CAST, turretLenM = 2.8f, turretWidM = 2.5f, turretOffsetM = 0.5f,
                bustleM = 0.1f, barrelM = 4.2f, barrelThickPx = 5, muzzle = Muzzle.DOUBLE, mantletWidM = 0.8f,
                paint = Paint.SOVIET_GREEN, seed = 28
            ),
            listOf("is_2"),
            "Pike-nosed hull and a 'frying pan' turret. Postwar shock to the Western Allies."
        )
    }

    // ------------------------------------------------------------ USA

    private fun loadUsa() {
        val u = Nation.USA

        add(
            "m2a4", "M2A4 Light Tank", "M2A4", u, 1, TankClass.LIGHT,
            10.3f, 4, 250, 58f,
            armor(f(25f), f(22f), f(25f), f(25f), f(22f), f(22f)),
            gun("37 mm M5", 37, 53, 56f, 83f, 1.7f, 880f),
            TankDesign(
                hullLenM = 4.43f, hullWidM = 2.46f, trackWidM = 0.32f, noseM = 0.6f, noseTaper = 0.12f,
                turretShape = TurretShape.ROUND, turretLenM = 1.6f, turretWidM = 1.4f, turretOffsetM = 0.1f,
                cupola = false, barrelM = 1.7f, barrelThickPx = 2, mantletWidM = 0.4f,
                paint = Paint.US_OLIVE, seed = 31
            ),
            emptyList(),
            "American pre-war light tank. Quick, but with only 25 mm of armour."
        )

        add(
            "m3_stuart", "M3 Stuart", "M3 Stuart", u, 2, TankClass.LIGHT,
            12.7f, 4, 250, 58f,
            armor(f(44f, 10f), f(25f), f(25f), f(38f), f(32f), f(32f)),
            gun("37 mm M6", 37, 53, 56f, 83f, 1.6f, 880f),
            TankDesign(
                hullLenM = 4.53f, hullWidM = 2.24f, trackWidM = 0.30f, noseM = 0.7f, noseTaper = 0.12f,
                turretShape = TurretShape.ROUND, turretLenM = 1.7f, turretWidM = 1.6f, turretOffsetM = 0.15f,
                barrelM = 1.7f, barrelThickPx = 2, mantletWidM = 0.4f, paint = Paint.US_OLIVE, seed = 32
            ),
            listOf("m2a4"),
            "Reliable and speedy 'Honey'. Great for scouting and finishing off wounded enemies."
        )

        add(
            "m4_sherman", "M4A1 Sherman", "M4A1", u, 3, TankClass.MEDIUM,
            30.3f, 5, 425, 38f,
            armor(f(51f, 56f), f(38f), f(38f, 10f), f(76f, 30f), f(51f, 20f), f(51f, 20f)),
            gun("75 mm M3", 75, 40, 80f, 0f, 2.8f, 619f),
            TankDesign(
                hullLenM = 5.84f, hullWidM = 2.62f, trackWidM = 0.42f, noseM = 1.1f, noseTaper = 0.08f,
                turretShape = TurretShape.CAST, turretLenM = 2.1f, turretWidM = 1.9f, turretOffsetM = 0.1f,
                bustleM = 0.15f, barrelM = 2.5f, barrelThickPx = 3, mantletWidM = 0.65f,
                paint = Paint.US_OLIVE, seed = 33
            ),
            listOf("m3_stuart"),
            "The Allied workhorse. Reliable, easy to repair, fast turret and a good HE shell."
        )

        add(
            "m10", "M10 Wolverine", "M10", u, 3, TankClass.TANK_DESTROYER,
            29f, 5, 375, 51f,
            armor(f(57f, 55f), f(19f), f(19f), f(57f, 30f), f(19f), f(19f)),
            gun("3-inch M7", 76, 50, 98f, 155f, 3.0f, 853f),
            TankDesign(
                hullLenM = 5.97f, hullWidM = 3.05f, trackWidM = 0.42f, noseM = 1.0f, noseTaper = 0.10f,
                turretShape = TurretShape.ANGULAR, turretLenM = 2.4f, turretWidM = 2.2f, turretOffsetM = -0.2f,
                cupola = false, openTop = true, barrelM = 3.2f, barrelThickPx = 3, muzzle = Muzzle.SINGLE,
                mantletWidM = 0.6f, paint = Paint.US_OLIVE, seed = 34
            ),
            listOf("m3_stuart"),
            "Fast tank destroyer with an open-top turret. Thin armour, keep moving."
        )

        add(
            "m4a3e8", "M4A3E8 Sherman 'Easy Eight'", "Easy Eight", u, 4, TankClass.MEDIUM,
            33.7f, 5, 500, 42f,
            armor(f(64f, 47f), f(38f), f(38f), f(76f, 30f), f(63f, 15f), f(63f, 15f)),
            gun("76 mm M1A2", 76, 55, 109f, 177f, 2.9f, 792f),
            TankDesign(
                hullLenM = 5.84f, hullWidM = 2.97f, trackWidM = 0.58f, noseM = 1.1f, noseTaper = 0.08f,
                turretShape = TurretShape.CAST, turretLenM = 2.3f, turretWidM = 2.0f, turretOffsetM = 0.15f,
                bustleM = 0.25f, barrelM = 3.6f, barrelThickPx = 3, muzzle = Muzzle.SINGLE, mantletWidM = 0.65f,
                paint = Paint.US_OLIVE, seed = 35
            ),
            listOf("m4_sherman"),
            "Late Sherman with wide tracks, a bigger turret and a much better 76 mm gun."
        )

        add(
            "m36", "M36 Jackson", "M36", u, 4, TankClass.TANK_DESTROYER,
            28f, 5, 500, 48f,
            armor(f(51f, 55f), f(19f), f(19f), f(76f, 30f), f(32f), f(32f)),
            gun("90 mm M3", 90, 50, 143f, 221f, 3.8f, 810f),
            TankDesign(
                hullLenM = 6.10f, hullWidM = 3.05f, trackWidM = 0.42f, noseM = 1.0f, noseTaper = 0.10f,
                turretShape = TurretShape.ANGULAR, turretLenM = 2.7f, turretWidM = 2.4f, turretOffsetM = -0.15f,
                cupola = false, openTop = true, barrelM = 4.2f, barrelThickPx = 4, muzzle = Muzzle.PEPPERPOT,
                mantletWidM = 0.7f, paint = Paint.US_OLIVE, seed = 36
            ),
            listOf("m10"),
            "90 mm anti-tank gun on a fast chassis. Hits hard, but a single hit can end it."
        )

        add(
            "m26", "M26 Pershing", "Pershing", u, 5, TankClass.HEAVY,
            41.9f, 5, 500, 48f,
            armor(f(102f, 46f), f(76f), f(51f), f(102f, 30f), f(76f, 15f), f(76f, 15f)),
            gun("90 mm M3", 90, 50, 143f, 221f, 3.6f, 810f),
            TankDesign(
                hullLenM = 6.31f, hullWidM = 3.51f, trackWidM = 0.60f, noseM = 1.1f, noseTaper = 0.08f,
                turretShape = TurretShape.CAST, turretLenM = 2.6f, turretWidM = 2.3f, turretOffsetM = 0.3f,
                bustleM = 0.35f, barrelM = 4.3f, barrelThickPx = 4, muzzle = Muzzle.PEPPERPOT, mantletWidM = 0.8f,
                paint = Paint.US_OLIVE, seed = 37
            ),
            listOf("m4a3e8", "m36"),
            "America's answer to the Tiger: torsion-bar suspension, 90 mm gun, 102 mm glacis."
        )
    }

    // ------------------------------------------------------------ United Kingdom

    private fun loadUk() {
        val b = Nation.UK

        add(
            "light_mk6", "Light Tank Mk. VIB", "Light Mk VI", b, 1, TankClass.LIGHT,
            5.2f, 3, 88, 56f,
            armor(f(14f), f(10f), f(10f), f(14f), f(10f), f(10f)),
            gun("Vickers .50 cal MG", 13, 0, 25f, 0f, 0.25f, 880f, damage = 14f),
            TankDesign(
                hullLenM = 3.96f, hullWidM = 2.08f, trackWidM = 0.28f, noseM = 0.5f, noseTaper = 0.15f,
                turretShape = TurretShape.ROUND, turretLenM = 1.1f, turretWidM = 1.0f, cupola = false,
                barrelM = 0.8f, barrelThickPx = 2, mantletWidM = 0.3f, paint = Paint.BRITISH_KHAKI, seed = 41
            ),
            emptyList(),
            "Tiny machine-gun tank. Fast, cheap and only good against other light tanks."
        )

        add(
            "crusader_3", "Crusader Mk. III", "Crusader III", b, 2, TankClass.MEDIUM,
            20f, 3, 340, 44f,
            armor(f(51f, 15f), f(30f), f(30f), f(51f, 15f), f(40f), f(40f)),
            gun("QF 6-pounder", 57, 43, 85f, 145f, 2.2f, 890f),
            TankDesign(
                hullLenM = 6.00f, hullWidM = 2.64f, trackWidM = 0.35f, noseM = 0.9f, noseTaper = 0.10f,
                turretShape = TurretShape.BOX, turretLenM = 2.0f, turretWidM = 1.8f, turretOffsetM = 0.1f,
                bustleM = 0.4f, barrelM = 2.4f, barrelThickPx = 3, mantletWidM = 0.5f,
                paint = Paint.BRITISH_KHAKI, seed = 42
            ),
            listOf("light_mk6"),
            "Desert cruiser tank with a fine 6-pounder. Fast, but cramped and fragile."
        )

        add(
            "matilda_2", "Matilda II", "Matilda II", b, 2, TankClass.HEAVY,
            26.9f, 4, 174, 25f,
            armor(f(78f, 10f), f(65f), f(55f), f(75f), f(75f), f(75f)),
            gun("QF 2-pounder", 40, 52, 53f, 85f, 1.2f, 790f),
            TankDesign(
                hullLenM = 5.61f, hullWidM = 2.59f, trackWidM = 0.55f, noseM = 0.7f, noseTaper = 0.10f,
                skirts = true, turretShape = TurretShape.ROUND, turretLenM = 1.65f, turretWidM = 1.55f,
                turretOffsetM = 0.2f, cupola = false, barrelM = 1.8f, barrelThickPx = 2, mantletWidM = 0.45f,
                paint = Paint.BRITISH_KHAKI, seed = 43
            ),
            listOf("light_mk6"),
            "'Queen of the Desert': nearly immune to early guns, but painfully slow."
        )

        add(
            "cromwell", "Cromwell Mk. IV", "Cromwell", b, 3, TankClass.MEDIUM,
            27.9f, 5, 600, 64f,
            armor(f(64f), f(32f), f(32f), f(76f), f(63f), f(57f)),
            gun("QF 75 mm Mk V", 75, 36, 92f, 0f, 2.7f, 617f),
            TankDesign(
                hullLenM = 6.35f, hullWidM = 2.91f, trackWidM = 0.38f, noseM = 1.0f, noseTaper = 0.10f,
                turretShape = TurretShape.BOX, turretLenM = 2.2f, turretWidM = 2.0f, turretOffsetM = 0.3f,
                bustleM = 0.3f, barrelM = 2.7f, barrelThickPx = 3, mantletWidM = 0.55f,
                paint = Paint.BRITISH_KHAKI, seed = 44
            ),
            listOf("crusader_3"),
            "The fastest tank of the war, with a powerful Meteor engine. Armour is just average."
        )

        add(
            "churchill_vii", "Churchill Mk. VII", "Churchill VII", b, 3, TankClass.HEAVY,
            40.7f, 5, 350, 20f,
            armor(f(152f), f(95f), f(50f), f(152f, 10f), f(95f), f(95f)),
            gun("QF 75 mm Mk V", 75, 36, 92f, 0f, 2.7f, 617f),
            TankDesign(
                hullLenM = 7.44f, hullWidM = 3.25f, trackWidM = 0.55f, noseM = 0.7f, noseTaper = 0.04f,
                skirts = true, turretShape = TurretShape.BOX, turretLenM = 2.4f, turretWidM = 2.1f,
                turretOffsetM = 0.25f, bustleM = 0.3f, barrelM = 2.7f, barrelThickPx = 3, mantletWidM = 0.6f,
                paint = Paint.BRITISH_KHAKI, seed = 45
            ),
            listOf("matilda_2"),
            "A walking fortress. 152 mm of frontal armour, but it crawls at 20 km/h."
        )

        add(
            "firefly", "Sherman Firefly", "Firefly", b, 4, TankClass.MEDIUM,
            34.1f, 4, 425, 38f,
            armor(f(51f, 56f), f(38f), f(38f), f(76f, 30f), f(51f), f(51f)),
            gun("QF 17-pounder", 76, 55, 150f, 228f, 3.9f, 884f),
            TankDesign(
                hullLenM = 5.84f, hullWidM = 2.67f, trackWidM = 0.42f, noseM = 1.1f, noseTaper = 0.08f,
                turretShape = TurretShape.CAST, turretLenM = 2.1f, turretWidM = 1.9f, turretOffsetM = 0.1f,
                bustleM = 0.5f, cupola = false, barrelM = 3.9f, barrelThickPx = 3, mantletWidM = 0.6f,
                paint = Paint.BRITISH_KHAKI, seed = 46
            ),
            listOf("cromwell"),
            "A Sherman with a 17-pounder: the only Allied gun that could kill a Tiger at range."
        )

        add(
            "comet", "Comet", "Comet", b, 4, TankClass.MEDIUM,
            33.5f, 5, 600, 47f,
            armor(f(101f, 10f), f(57f), f(14f), f(101f, 10f), f(63f), f(63f)),
            gun("77 mm HV", 77, 50, 137f, 200f, 3.5f, 790f),
            TankDesign(
                hullLenM = 6.55f, hullWidM = 3.04f, trackWidM = 0.45f, noseM = 1.0f, noseTaper = 0.10f,
                turretShape = TurretShape.ANGULAR, turretLenM = 2.4f, turretWidM = 2.1f, turretOffsetM = 0.3f,
                bustleM = 0.3f, barrelM = 3.4f, barrelThickPx = 3, mantletWidM = 0.6f,
                paint = Paint.BRITISH_KHAKI, seed = 47
            ),
            listOf("cromwell"),
            "Welded hull, 101 mm front and a great gun: Britain's best wartime cruiser."
        )

        add(
            "centurion_3", "Centurion Mk. III", "Centurion III", b, 5, TankClass.MEDIUM,
            51f, 4, 650, 35f,
            armor(f(76f, 57f), f(51f), f(38f), f(152f, 20f), f(76f), f(76f)),
            gun("OQF 20-pounder", 84, 66, 200f, 300f, 4.2f, 1020f),
            TankDesign(
                hullLenM = 7.00f, hullWidM = 3.38f, trackWidM = 0.60f, noseM = 1.1f, noseTaper = 0.10f,
                skirts = true, turretShape = TurretShape.ANGULAR, turretLenM = 2.6f, turretWidM = 2.3f,
                turretOffsetM = 0.25f, bustleM = 0.4f, barrelM = 4.4f, barrelThickPx = 4, muzzle = Muzzle.SINGLE,
                mantletWidM = 0.75f, paint = Paint.BRITISH_KHAKI, seed = 48
            ),
            listOf("comet", "firefly"),
            "The first 'main battle tank'. Stabilised, sloped armour and a deadly 20-pounder."
        )
    }

    // ------------------------------------------------------------ Japan

    private fun loadJapan() {
        val j = Nation.JAPAN

        add(
            "ha_go", "Type 95 Ha-Go", "Ha-Go", j, 1, TankClass.LIGHT,
            7.4f, 3, 120, 45f,
            armor(f(12f), f(12f), f(12f), f(12f), f(12f), f(12f)),
            gun("37 mm Type 94", 37, 37, 40f, 0f, 1.5f, 575f),
            TankDesign(
                hullLenM = 4.38f, hullWidM = 2.05f, trackWidM = 0.25f, noseM = 0.5f, noseTaper = 0.12f,
                turretShape = TurretShape.ROUND, turretLenM = 1.3f, turretWidM = 1.2f, barrelM = 1.0f,
                barrelThickPx = 2, mantletWidM = 0.35f, paint = Paint.JAPANESE_CAMO, seed = 51
            ),
            emptyList(),
            "Light tank that fought across the Pacific. Very thin armour."
        )

        add(
            "chi_ha", "Type 97 Chi-Ha", "Chi-Ha", j, 2, TankClass.MEDIUM,
            15.8f, 4, 170, 38f,
            armor(f(25f), f(20f), f(20f), f(25f), f(20f), f(20f)),
            gun("57 mm Type 97", 57, 18, 30f, 0f, 2.5f, 420f),
            TankDesign(
                hullLenM = 5.52f, hullWidM = 2.33f, trackWidM = 0.30f, noseM = 0.7f, noseTaper = 0.10f,
                turretShape = TurretShape.ROUND, turretLenM = 1.7f, turretWidM = 1.6f, turretOffsetM = 0.2f,
                barrelM = 1.0f, barrelThickPx = 3, mantletWidM = 0.4f, paint = Paint.JAPANESE_CAMO, seed = 52
            ),
            listOf("ha_go"),
            "Main Japanese medium tank. Short 57 mm gun: great HE, almost useless AP."
        )

        add(
            "chi_he", "Type 1 Chi-He", "Chi-He", j, 3, TankClass.MEDIUM,
            17.2f, 5, 240, 44f,
            armor(f(50f), f(25f), f(20f), f(50f), f(25f), f(25f)),
            gun("47 mm Type 1", 47, 48, 68f, 0f, 1.9f, 810f),
            TankDesign(
                hullLenM = 5.73f, hullWidM = 2.33f, trackWidM = 0.30f, noseM = 0.7f, noseTaper = 0.10f,
                turretShape = TurretShape.OCTAGON, turretLenM = 1.9f, turretWidM = 1.8f, turretOffsetM = 0.2f,
                barrelM = 2.0f, barrelThickPx = 3, mantletWidM = 0.45f, paint = Paint.JAPANESE_CAMO, seed = 53
            ),
            listOf("chi_ha"),
            "Improved Chi-Ha with welded armour and a high-velocity 47 mm gun."
        )

        add(
            "chi_nu", "Type 3 Chi-Nu", "Chi-Nu", j, 3, TankClass.MEDIUM,
            18.8f, 5, 240, 39f,
            armor(f(50f), f(25f), f(20f), f(50f), f(25f), f(25f)),
            gun("75 mm Type 3", 75, 38, 80f, 0f, 2.9f, 680f),
            TankDesign(
                hullLenM = 5.73f, hullWidM = 2.33f, trackWidM = 0.30f, noseM = 0.7f, noseTaper = 0.10f,
                turretShape = TurretShape.ANGULAR, turretLenM = 2.2f, turretWidM = 2.0f, turretOffsetM = 0.2f,
                barrelM = 2.4f, barrelThickPx = 3, mantletWidM = 0.55f, paint = Paint.JAPANESE_CAMO, seed = 54
            ),
            listOf("chi_ha"),
            "Chi-He hull with a big welded turret and a 75 mm gun to fight Shermans."
        )

        add(
            "ho_ni_iii", "Type 3 Ho-Ni III", "Ho-Ni III", j, 3, TankClass.TANK_DESTROYER,
            15f, 5, 240, 38f,
            armor(f(50f), f(25f), f(12f), f(50f), f(25f), f(12f)),
            gun("75 mm Type 3", 75, 38, 80f, 0f, 2.9f, 680f),
            TankDesign(
                hullLenM = 5.50f, hullWidM = 2.33f, trackWidM = 0.30f, noseM = 0.7f, noseTaper = 0.10f,
                casemate = true, openTop = true, turretShape = TurretShape.MOUNT, turretOffsetM = 0.45f,
                barrelM = 2.3f, barrelThickPx = 3, mantletWidM = 0.4f, paint = Paint.JAPANESE_CAMO, seed = 55
            ),
            listOf("chi_ha"),
            "Open-topped tank destroyer. Light, quick to hide, easy to kill.",
            arc = 10f
        )

        add(
            "chi_to", "Type 4 Chi-To", "Chi-To", j, 4, TankClass.MEDIUM,
            30f, 5, 400, 45f,
            armor(f(75f), f(50f), f(20f), f(75f), f(50f), f(50f)),
            gun("75 mm Type 5", 75, 56, 126f, 0f, 3.5f, 850f),
            TankDesign(
                hullLenM = 6.30f, hullWidM = 2.33f, trackWidM = 0.33f, noseM = 0.9f, noseTaper = 0.10f,
                turretShape = TurretShape.ANGULAR, turretLenM = 2.3f, turretWidM = 2.0f, turretOffsetM = 0.3f,
                barrelM = 3.4f, barrelThickPx = 3, mantletWidM = 0.55f, paint = Paint.JAPANESE_CAMO, seed = 56
            ),
            listOf("chi_he", "chi_nu"),
            "Japan's last serious medium tank: thick front plate and a long 75 mm gun."
        )

        add(
            "chi_ri", "Type 5 Chi-Ri (prototype)", "Chi-Ri", j, 5, TankClass.MEDIUM,
            37.8f, 5, 550, 40f,
            armor(f(75f, 15f), f(50f), f(20f), f(75f, 10f), f(50f), f(50f)),
            gun("105 mm Type 5 (planned)", 105, 52, 165f, 0f, 5.4f, 850f),
            TankDesign(
                hullLenM = 7.30f, hullWidM = 3.05f, trackWidM = 0.45f, noseM = 1.1f, noseTaper = 0.10f,
                turretShape = TurretShape.ANGULAR, turretLenM = 2.6f, turretWidM = 2.3f, turretOffsetM = 0.2f,
                bustleM = 0.3f, barrelM = 4.0f, barrelThickPx = 5, muzzle = Muzzle.DOUBLE, mantletWidM = 0.7f,
                paint = Paint.JAPANESE_CAMO, seed = 57
            ),
            listOf("chi_to"),
            "Paper design from 1945 that never entered service. A what-if super-medium."
        )
    }
}
