package com.ironfront.tanks

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector2
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.entities.Entity
import com.ironfront.entities.ProjectileEntity
import com.ironfront.equipment.EquipmentLoadout
import com.ironfront.teams.Team
import com.ironfront.weapons.WeaponSystem
import java.util.UUID
import kotlin.math.abs

/** Hull size on screen is the real hull length x width of the tank (10 px per metre). */
class TankEntity(
    id: String,
    val spec: TankSpec,
    x: Float,
    y: Float,
    val playerControlled: Boolean,
    val team: Team = if (playerControlled) Team.FRIEND else Team.ENEMY
) : Entity(id, x, y, spec.hullLengthM * GameConfig.PX_PER_M, spec.hullWidthM * GameConfig.PX_PER_M) {

    var currentHp: Float = spec.maxHp
    var turretRotation: Float = 0f
    var desiredTurretRotation: Float = 0f
    val weapon = WeaponSystem(spec.gun)
    val loadout = EquipmentLoadout()

    var throttleInput: Float = 0f
    var steerInput: Float = 0f

    /** Bounding box of the rotated hull. */
    val halfExtentX: Float
        get() = abs(MathUtils.cosDeg(rotation)) * width / 2f + abs(MathUtils.sinDeg(rotation)) * height / 2f
    val halfExtentY: Float
        get() = abs(MathUtils.sinDeg(rotation)) * width / 2f + abs(MathUtils.cosDeg(rotation)) * height / 2f
    val collisionRadius: Float get() = (width + height) / 4f

    override fun update(delta: Float) {
        if (!isAlive) return

        weapon.update(delta * (1f / loadout.getTotalReloadMultiplier()))

        if (abs(steerInput) > 0.05f) {
            rotation -= steerInput * spec.hullTurnSpeedDeg * delta
            rotation = (rotation % 360f + 360f) % 360f
        }

        val speed = spec.moveSpeed * loadout.getTotalSpeedMultiplier() * throttleInput
        velocity.set(MathUtils.cosDeg(rotation) * speed, MathUtils.sinDeg(rotation) * speed)
        position.mulAdd(velocity, delta)

        val angleDiff = shortestAngleDiff(turretRotation, desiredTurretRotation)
        val maxStep = spec.turretTurnSpeedDeg * delta
        turretRotation += MathUtils.clamp(angleDiff, -maxStep, maxStep)

        if (spec.limitedTraverse) {
            // Casemate tank destroyers can only swing the gun a few degrees; the hull has to do the rest.
            val rel = shortestAngleDiff(rotation, turretRotation)
            val lim = spec.traverseLimitDeg
            if (rel > lim) turretRotation = rotation + lim
            if (rel < -lim) turretRotation = rotation - lim
        }
        turretRotation = (turretRotation % 360f + 360f) % 360f
    }

    fun aimTurretAt(targetX: Float, targetY: Float) {
        desiredTurretRotation = MathUtils.atan2(targetY - position.y, targetX - position.x) * MathUtils.radiansToDegrees
    }

    fun fire(): ProjectileEntity? {
        if (!isAlive) return null
        val ammo = weapon.triggerFire() ?: return null
        val barrelPx = spec.gun.barrelLengthM * GameConfig.PX_PER_M
        val muzzleX = position.x + MathUtils.cosDeg(turretRotation) * barrelPx
        val muzzleY = position.y + MathUtils.sinDeg(turretRotation) * barrelPx

        return ProjectileEntity(
            id = UUID.randomUUID().toString(),
            x = muzzleX,
            y = muzzleY,
            angleDeg = turretRotation,
            ownerId = id,
            team = team,
            ammo = ammo
        )
    }

    fun takeDamage(amount: Float) {
        currentHp = (currentHp - amount).coerceAtLeast(0f)
        if (currentHp <= 0f) isAlive = false
    }

    /** World point -> tank-local coordinates (x along the hull, y across it). */
    fun toLocal(wx: Float, wy: Float, out: Vector2): Vector2 {
        val dx = wx - position.x
        val dy = wy - position.y
        val c = MathUtils.cosDeg(rotation)
        val s = MathUtils.sinDeg(rotation)
        return out.set(dx * c + dy * s, -dx * s + dy * c)
    }

    private val tmpLocal = Vector2()

    fun containsPoint(wx: Float, wy: Float): Boolean {
        toLocal(wx, wy, tmpLocal)
        return abs(tmpLocal.x) <= width / 2f && abs(tmpLocal.y) <= height / 2f
    }

    override fun render(batch: SpriteBatch) {
        if (!isAlive) return
        val nation = spec.nation
        val len = width
        val wid = height
        val pad = 4f
        val hullRegion = AssetManager.getRegion("hull_${nation.name}")
        val hullOutline = AssetManager.getRegion("tank_hull_outline")
        val circle = AssetManager.getRegion("circle_white")
        val pixel = AssetManager.getRegion("pixel")

        // Hull: team outline (blue = friend, red = enemy) behind the national paint scheme.
        batch.color = team.outline
        batch.draw(
            hullOutline, position.x - len / 2f - pad, position.y - wid / 2f - pad,
            len / 2f + pad, wid / 2f + pad, len + 2f * pad, wid + 2f * pad, 1f, 1f, rotation
        )
        batch.color = Color.WHITE
        batch.draw(hullRegion, position.x - len / 2f, position.y - wid / 2f, len / 2f, wid / 2f, len, wid, 1f, 1f, rotation)

        val barrelLen = spec.gun.barrelLengthM * GameConfig.PX_PER_M
        val barrelT = maxOf(3f, spec.gun.caliberMm / 22f)
        var pivotX = position.x
        var pivotY = position.y

        if (spec.hasTurret) {
            val r = spec.turretDiameterM * GameConfig.PX_PER_M / 2f
            batch.color = team.outline
            batch.draw(circle, pivotX - r - 3f, pivotY - r - 3f, 2f * r + 6f, 2f * r + 6f)
            drawBarrel(batch, pixel, pivotX, pivotY, barrelLen + 2f, barrelT + 4f, team.outline)
            batch.color = nation.turret
            batch.draw(circle, pivotX - r, pivotY - r, 2f * r, 2f * r)
        } else {
            val cl = len * 0.58f
            val cw = wid * 0.82f
            pivotX = position.x + MathUtils.cosDeg(rotation) * len * 0.08f
            pivotY = position.y + MathUtils.sinDeg(rotation) * len * 0.08f
            batch.color = team.outline
            batch.draw(pixel, pivotX - cl / 2f - 3f, pivotY - cw / 2f - 3f, cl / 2f + 3f, cw / 2f + 3f, cl + 6f, cw + 6f, 1f, 1f, rotation)
            drawBarrel(batch, pixel, pivotX, pivotY, barrelLen + 2f, barrelT + 4f, team.outline)
            batch.color = nation.turret
            batch.draw(pixel, pivotX - cl / 2f, pivotY - cw / 2f, cl / 2f, cw / 2f, cl, cw, 1f, 1f, rotation)
        }
        drawBarrel(batch, pixel, pivotX, pivotY, barrelLen, barrelT, Color.DARK_GRAY)
        batch.color = Color.WHITE

        val barWidth = wid.coerceAtLeast(40f)
        val barHeight = 6f
        val hpRatio = (currentHp / spec.maxHp).coerceIn(0f, 1f)
        val barY = position.y + maxOf(len, wid) / 2f + 10f
        val pxTex = AssetManager.getTexture("pixel")

        batch.color = Color.DARK_GRAY
        batch.draw(pxTex, position.x - barWidth / 2f, barY, barWidth, barHeight)
        batch.color = team.outline
        batch.draw(pxTex, position.x - barWidth / 2f, barY, barWidth * hpRatio, barHeight)
        batch.color = Color.WHITE

        if (playerControlled) {
            AssetManager.font.draw(batch, "YOU", position.x - 20f, barY + 30f)
        }
    }

    private fun drawBarrel(
        batch: SpriteBatch,
        pixel: com.badlogic.gdx.graphics.g2d.TextureRegion,
        px: Float,
        py: Float,
        length: Float,
        thickness: Float,
        color: Color
    ) {
        batch.color = color
        batch.draw(pixel, px, py - thickness / 2f, 0f, thickness / 2f, length, thickness, 1f, 1f, turretRotation)
    }

    private fun shortestAngleDiff(from: Float, to: Float): Float {
        var diff = (to - from) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return diff
    }
}
