package com.ironfront.tanks

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager
import com.ironfront.entities.Entity
import com.ironfront.entities.ProjectileEntity
import com.ironfront.equipment.EquipmentLoadout
import com.ironfront.teams.Team
import com.ironfront.weapons.WeaponSystem
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

class TankEntity(
    id: String,
    val spec: TankSpec,
    x: Float,
    y: Float,
    val playerControlled: Boolean,
    val team: Team = if (playerControlled) Team.FRIEND else Team.ENEMY
) : Entity(id, x, y, spec.design.hullLenPx * 0.92f, spec.design.hullWidPx * 0.92f) {

    var currentHp: Float = spec.maxHp
    var turretRotation: Float = 0f
    var desiredTurretRotation: Float = 0f
    val weapon = WeaponSystem(spec.gun)
    val loadout = EquipmentLoadout()

    var throttleInput: Float = 0f
    var steerInput: Float = 0f

    var repairUsed: Boolean = false
        private set
    var wreckTime: Float = 0f
        private set
    var wreckTurretOffset: Float = 0f
        private set

    private var currentSpeed = 0f
    private var recoil = 0f
    private val halfLen = spec.design.hullLenPx / 2f
    private val halfWid = spec.design.hullWidPx / 2f

    val speedNow: Float get() = abs(currentSpeed)

    val collisionRadius: Float = max(halfLen, halfWid) * 0.62f + 6f

    val turretX: Float get() = position.x + MathUtils.cosDeg(rotation) * spec.design.turretOffsetPx
    val turretY: Float get() = position.y + MathUtils.sinDeg(rotation) * spec.design.turretOffsetPx

    override fun update(delta: Float) {
        if (!isAlive) {
            if (wreckTime > 0f) wreckTime -= delta
            return
        }

        weapon.update(delta * (1f / loadout.getTotalReloadMultiplier()))
        if (recoil > 0f) recoil = (recoil - 30f * delta).coerceAtLeast(0f)

        if (abs(steerInput) > 0.05f) {
            rotation -= steerInput * spec.hullTurnSpeedDeg * delta
            rotation = (rotation + 360f) % 360f
        }

        val maxForward = spec.moveSpeed * loadout.getTotalSpeedMultiplier()
        val target = if (throttleInput >= 0f) maxForward * throttleInput else maxForward * 0.4f * throttleInput
        val step = spec.accel * delta
        currentSpeed += (target - currentSpeed).coerceIn(-step * 1.6f, step)

        velocity.set(MathUtils.cosDeg(rotation) * currentSpeed, MathUtils.sinDeg(rotation) * currentSpeed)
        position.mulAdd(velocity, delta)

        val angleDiff = shortestAngleDiff(turretRotation, desiredTurretRotation)
        val maxTurretStep = spec.turretTurnSpeedDeg * delta
        turretRotation += MathUtils.clamp(angleDiff, -maxTurretStep, maxTurretStep)
        turretRotation = (turretRotation + 360f) % 360f

        if (spec.isCasemate) {
            val rel = shortestAngleDiff(rotation, turretRotation).coerceIn(-spec.casemateArcDeg, spec.casemateArcDeg)
            turretRotation = (rotation + rel + 360f) % 360f
        }

        // collision box follows the hull direction
        val c = abs(MathUtils.cosDeg(rotation))
        val s = abs(MathUtils.sinDeg(rotation))
        width = (c * spec.design.hullLenPx + s * spec.design.hullWidPx) * 0.9f
        height = (s * spec.design.hullLenPx + c * spec.design.hullWidPx) * 0.9f
    }

    /** Called by the collision system when the hull is pushed out of a wall. */
    fun onCollision() {
        currentSpeed *= 0.6f
    }

    fun aimTurretAt(targetX: Float, targetY: Float) {
        desiredTurretRotation = MathUtils.atan2(targetY - turretY, targetX - turretX) * MathUtils.radiansToDegrees
    }

    fun fire(): ProjectileEntity? {
        if (!isAlive || !weapon.triggerFire()) return null
        val reach = spec.design.muzzleReachPx.toFloat()
        val muzzleX = turretX + MathUtils.cosDeg(turretRotation) * reach
        val muzzleY = turretY + MathUtils.sinDeg(turretRotation) * reach

        val ammo = weapon.currentAmmo
        val gun = spec.gun
        val dispersion = 0.5f + 1.2f * (speedNow / max(1f, spec.moveSpeed))
        val angle = turretRotation + MathUtils.random(-dispersion, dispersion)
        recoil = 4f

        return ProjectileEntity(
            id = UUID.randomUUID().toString(),
            x = muzzleX,
            y = muzzleY,
            angleDeg = angle,
            ownerId = id,
            team = team,
            ammoType = ammo,
            baseDamage = gun.baseDamage * ammo.dmgMultiplier,
            penetrationMm = gun.penFor(ammo),
            caliberMm = gun.caliberMm,
            speed = gun.shellSpeed * ammo.speedMultiplier
        )
    }

    val muzzleX: Float get() = turretX + MathUtils.cosDeg(turretRotation) * spec.design.muzzleReachPx
    val muzzleY: Float get() = turretY + MathUtils.sinDeg(turretRotation) * spec.design.muzzleReachPx

    fun takeDamage(amount: Float) {
        currentHp = (currentHp - amount).coerceAtLeast(0f)
        if (currentHp <= 0f) {
            isAlive = false
            wreckTime = 25f
            wreckTurretOffset = MathUtils.random(-25f, 25f)
            throttleInput = 0f
            steerInput = 0f
        }
    }

    val repairCharges: Int
        get() = if (loadout.has(com.ironfront.equipment.EquipmentType.REPAIR_KIT) && !repairUsed) 1 else 0

    fun useRepairKit(): Boolean {
        if (!isAlive || repairCharges == 0) return false
        repairUsed = true
        currentHp = (currentHp + spec.maxHp * 0.30f).coerceAtMost(spec.maxHp)
        return true
    }

    /** Is this world point inside the hull rectangle (rotated with the tank)? */
    fun containsPoint(px: Float, py: Float): Boolean {
        val dx = px - position.x
        val dy = py - position.y
        val c = MathUtils.cosDeg(rotation)
        val s = MathUtils.sinDeg(rotation)
        val u = dx * c + dy * s
        val v = -dx * s + dy * c
        return abs(u) <= halfLen && abs(v) <= halfWid
    }

    /** Distance of a world point along the hull's forward axis, measured from the tank centre. */
    fun localU(px: Float, py: Float): Float {
        val dx = px - position.x
        val dy = py - position.y
        return dx * MathUtils.cosDeg(rotation) + dy * MathUtils.sinDeg(rotation)
    }

    override fun render(batch: SpriteBatch) {
        val id = spec.id
        val hull = AssetManager.getRegion("hull_$id")
        val turret = AssetManager.getRegion("turret_$id")
        val hw = hull.regionWidth.toFloat()
        val hh = hull.regionHeight.toFloat()
        val tw = turret.regionWidth.toFloat()
        val th = turret.regionHeight.toFloat()
        val pivot = AssetManager.pivotX(id)

        if (!isAlive) {
            if (wreckTime <= 0f) return
            val fade = (wreckTime / 6f).coerceIn(0.35f, 1f)
            batch.setColor(0.17f, 0.15f, 0.14f, fade)
            batch.draw(hull, position.x - hw / 2f, position.y - hh / 2f, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
            batch.draw(
                turret, turretX - pivot, turretY - th / 2f, pivot, th / 2f, tw, th, 1f, 1f,
                turretRotation + wreckTurretOffset
            )
            batch.setColor(1f, 1f, 1f, 1f)
            return
        }

        val hullOutline = AssetManager.getRegion("hullo_$id")
        val turretOutline = AssetManager.getRegion("turreto_$id")
        val rx = MathUtils.cosDeg(turretRotation) * recoil
        val ry = MathUtils.sinDeg(turretRotation) * recoil
        val tx = turretX - rx
        val ty = turretY - ry

        // team outline: blue = friend, red = enemy
        batch.color = team.outline
        batch.draw(hullOutline, position.x - hw / 2f, position.y - hh / 2f, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
        batch.color = Color.WHITE
        batch.draw(hull, position.x - hw / 2f, position.y - hh / 2f, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)

        batch.color = team.outline
        batch.draw(turretOutline, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, 1f, 1f, turretRotation)
        batch.color = Color.WHITE
        batch.draw(turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, 1f, 1f, turretRotation)

        val barWidth = 60f
        val barHeight = 6f
        val barY = position.y + halfLen * 0.6f + 22f
        val hpRatio = (currentHp / spec.maxHp).coerceIn(0f, 1f)
        val pixel = AssetManager.getTexture("pixel")

        batch.color = Color.DARK_GRAY
        batch.draw(pixel, position.x - barWidth / 2f, barY, barWidth, barHeight)
        batch.color = team.outline
        batch.draw(pixel, position.x - barWidth / 2f, barY, barWidth * hpRatio, barHeight)
        batch.color = Color.WHITE

        val label = if (playerControlled) "YOU" else "T${spec.tier} ${spec.shortName}"
        val font = AssetManager.fontSmall
        font.color = team.outline
        font.draw(batch, label, position.x - barWidth / 2f, barY + 24f)
        font.color = Color.WHITE
    }

    private fun shortestAngleDiff(from: Float, to: Float): Float {
        var diff = (to - from) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return diff
    }
}
