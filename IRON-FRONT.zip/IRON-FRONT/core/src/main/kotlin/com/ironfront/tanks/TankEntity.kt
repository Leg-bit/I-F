package com.ironfront.tanks

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager
import com.ironfront.core.Shaders
import com.ironfront.entities.Entity
import com.ironfront.entities.ProjectileEntity
import com.ironfront.equipment.EquipmentLoadout
import com.ironfront.teams.Team
import com.ironfront.weapons.WeaponSystem
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

class TankEntity(
    id: String,
    val spec: TankSpec,
    x: Float,
    y: Float,
    val playerControlled: Boolean,
    val team: Team = if (playerControlled) Team.FRIEND else Team.ENEMY
) : Entity(id, x, y, spec.design.hullLenPx * 0.92f, spec.design.hullWidPx * 0.92f) {

    /** Elite Field Modification: +8% HP, +6% speed, +6% reload (player tank only). */
    val isElite: Boolean = playerControlled && com.ironfront.core.GameManager.techTree.isElite(spec.id)
    val maxHealth: Float = if (isElite) spec.maxHp * 1.08f else spec.maxHp
    var currentHp: Float = maxHealth

    /** The health bar is only shown for a few seconds after a hit, to keep the screen clean. */
    private var barTimer = 0f
    var turretRotation: Float = 0f
    var desiredTurretRotation: Float = 0f
    val weapon = WeaponSystem(spec.gun)
    val loadout = EquipmentLoadout()

    var throttleInput: Float = 0f
    var steerInput: Float = 0f

    var repairUsed: Boolean = false
        private set
    var wreckTime: Float = 0f
        private set
    var wreckTurretOffset: Float = 0f
        private set

    /** 1 on firm ground, lower in mud, sand or on thin ice. Set by the world every frame. */
    var terrainFactor: Float = 1f

    /** While > 0 the tank is visible to the enemy even in the dark (it just fired). */
    var revealTimer: Float = 0f
        private set

    /** How hard the last shot kicked the player's screen. */
    var lastRecoilPower: Float = 0f
        private set

    /** Distance driven since the last tread mark, and a timer for exhaust puffs (used by the world). */
    var markAccum: Float = 0f
    var exhaustTimer: Float = 0f

    private var steerSmooth = 0f
    private var currentSpeed = 0f
    private var recoil = 0f
    private var kickX = 0f
    private var kickY = 0f
    private val halfLen = spec.design.hullLenPx / 2f
    private val halfWid = spec.design.hullWidPx / 2f

    val speedNow: Float get() = abs(currentSpeed)

    /** Current barrel recoil in pixels (for the 3D view). */
    val recoilPx: Float get() = recoil

    /** Show the floating health bar: a few seconds after a hit, or on a damaged enemy. */
    val showHealthBar: Boolean get() = barTimer > 0f || (currentHp < maxHealth && !playerControlled)

    /** Vision cone range in pixels (includes optics equipment). */
    val viewRange: Float get() = spec.viewRangePx * loadout.getTotalViewMultiplier()
    val awareness: Float get() = spec.awarenessPx * (0.5f + loadout.getTotalViewMultiplier() * 0.5f)

    val collisionRadius: Float = max(halfLen, halfWid) * 0.62f + 6f

    val turretX: Float get() = position.x + MathUtils.cosDeg(rotation) * spec.design.turretOffsetPx
    val turretY: Float get() = position.y + MathUtils.sinDeg(rotation) * spec.design.turretOffsetPx

    override fun update(delta: Float) {
        if (!isAlive) {
            if (wreckTime > 0f) wreckTime -= delta
            return
        }

        weapon.update(delta * (if (isElite) 1.06f else 1f) * (1f / loadout.getTotalReloadMultiplier()))
        if (recoil > 0f) recoil = (recoil - 38f * delta).coerceAtLeast(0f)
        if (revealTimer > 0f) revealTimer -= delta
        if (barTimer > 0f) barTimer -= delta

        // steering eases in and out, and a fast-moving heavy hull turns a bit slower
        steerSmooth += (steerInput - steerSmooth) * (1f - kotlin.math.exp(-9f * delta))
        if (abs(steerSmooth) > 0.02f) {
            val speedRatio = (abs(currentSpeed) / max(1f, spec.moveSpeed)).coerceIn(0f, 1f)
            val turnRate = spec.hullTurnSpeedDeg * (1.12f - 0.30f * speedRatio)
            rotation -= steerSmooth * turnRate * delta
            rotation = (rotation + 360f) % 360f
        }

        val maxForward = spec.moveSpeed * (if (isElite) 1.06f else 1f) * loadout.getTotalSpeedMultiplier() * terrainFactor
        val target = if (throttleInput >= 0f) maxForward * throttleInput else maxForward * 0.4f * throttleInput
        val step = spec.accel * delta
        currentSpeed += (target - currentSpeed).coerceIn(-step * 1.6f, step)

        velocity.set(MathUtils.cosDeg(rotation) * currentSpeed, MathUtils.sinDeg(rotation) * currentSpeed)
        position.mulAdd(velocity, delta)

        // hull kicked backwards by the last shot
        if (kickX != 0f || kickY != 0f) {
            position.add(kickX * delta, kickY * delta)
            val decay = (1f - 6f * delta).coerceAtLeast(0f)
            kickX *= decay
            kickY *= decay
            if (abs(kickX) < 0.5f && abs(kickY) < 0.5f) {
                kickX = 0f
                kickY = 0f
            }
        }

        val angleDiff = shortestAngleDiff(turretRotation, desiredTurretRotation)
        val maxTurretStep = spec.turretTurnSpeedDeg * delta
        turretRotation += MathUtils.clamp(angleDiff, -maxTurretStep, maxTurretStep)
        turretRotation = (turretRotation + 360f) % 360f

        if (spec.isCasemate) {
            val rel = shortestAngleDiff(rotation, turretRotation).coerceIn(-spec.casemateArcDeg, spec.casemateArcDeg)
            turretRotation = (rotation + rel + 360f) % 360f
        }

        // collision box follows the hull direction
        val c = abs(MathUtils.cosDeg(rotation))
        val s = abs(MathUtils.sinDeg(rotation))
        width = (c * spec.design.hullLenPx + s * spec.design.hullWidPx) * 0.9f
        height = (s * spec.design.hullLenPx + c * spec.design.hullWidPx) * 0.9f
    }

    /** Called by the collision system when the hull is pushed out of a wall. */
    fun onCollision() {
        currentSpeed *= 0.6f
    }

    fun aimTurretAt(targetX: Float, targetY: Float) {
        desiredTurretRotation = MathUtils.atan2(targetY - turretY, targetX - turretX) * MathUtils.radiansToDegrees
    }

    fun fire(): ProjectileEntity? {
        if (!isAlive || !weapon.triggerFire()) return null
        val reach = spec.design.muzzleReachPx.toFloat()
        val muzzleX = turretX + MathUtils.cosDeg(turretRotation) * reach
        val muzzleY = turretY + MathUtils.sinDeg(turretRotation) * reach

        val ammo = weapon.currentAmmo
        val gun = spec.gun
        val dispersion = 0.5f + 1.2f * (speedNow / max(1f, spec.moveSpeed))
        val angle = turretRotation + MathUtils.random(-dispersion, dispersion)
        // bigger guns kick harder: turret slides back, the whole hull is shoved backwards
        recoil = 3f + gun.caliberMm / 9f
        val impulse = gun.caliberMm * 4f / kotlin.math.sqrt(spec.weightTons)
        kickX = -MathUtils.cosDeg(turretRotation) * impulse
        kickY = -MathUtils.sinDeg(turretRotation) * impulse
        lastRecoilPower = 2f + gun.caliberMm / 14f
        revealTimer = 1.5f

        return ProjectileEntity(
            id = UUID.randomUUID().toString(),
            x = muzzleX,
            y = muzzleY,
            angleDeg = angle,
            ownerId = id,
            team = team,
            ammoType = ammo,
            baseDamage = gun.baseDamage * ammo.dmgMultiplier,
            penetrationMm = gun.penFor(ammo),
            caliberMm = gun.caliberMm,
            speed = gun.shellSpeed * ammo.speedMultiplier
        )
    }

    val muzzleX: Float get() = turretX + MathUtils.cosDeg(turretRotation) * spec.design.muzzleReachPx
    val muzzleY: Float get() = turretY + MathUtils.sinDeg(turretRotation) * spec.design.muzzleReachPx

    fun takeDamage(amount: Float) {
        barTimer = 4f
        currentHp = (currentHp - amount).coerceAtLeast(0f)
        if (currentHp <= 0f) {
            isAlive = false
            wreckTime = 25f
            wreckTurretOffset = MathUtils.random(-25f, 25f)
            throttleInput = 0f
            steerInput = 0f
        }
    }

    val repairCharges: Int
        get() = if (loadout.has(com.ironfront.equipment.EquipmentType.REPAIR_KIT) && !repairUsed) 1 else 0

    fun useRepairKit(): Boolean {
        if (!isAlive || repairCharges == 0) return false
        repairUsed = true
        currentHp = (currentHp + maxHealth * 0.30f).coerceAtMost(maxHealth)
        return true
    }

    /** Is this world point inside the hull rectangle (rotated with the tank)? */
    fun containsPoint(px: Float, py: Float): Boolean {
        val dx = px - position.x
        val dy = py - position.y
        val c = MathUtils.cosDeg(rotation)
        val s = MathUtils.sinDeg(rotation)
        val u = dx * c + dy * s
        val v = -dx * s + dy * c
        return abs(u) <= halfLen && abs(v) <= halfWid
    }

    /** Distance of a world point along the hull's forward axis, measured from the tank centre. */
    fun localU(px: Float, py: Float): Float {
        val dx = px - position.x
        val dy = py - position.y
        return dx * MathUtils.cosDeg(rotation) + dy * MathUtils.sinDeg(rotation)
    }

    override fun render(batch: SpriteBatch) {
        val id = spec.id
        val hull = AssetManager.getRegion("hull_$id")
        val turret = AssetManager.getRegion("turret_$id")
        val hw = hull.regionWidth.toFloat()
        val hh = hull.regionHeight.toFloat()
        val tw = turret.regionWidth.toFloat()
        val th = turret.regionHeight.toFloat()
        val pivot = AssetManager.pivotX(id)

        if (!isAlive) {
            if (wreckTime <= 0f) return
            val fade = (wreckTime / 6f).coerceIn(0.35f, 1f)
            batch.setColor(0.17f, 0.15f, 0.14f, fade)
            batch.draw(hull, position.x - hw / 2f, position.y - hh / 2f, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
            batch.draw(
                turret, turretX - pivot, turretY - th / 2f, pivot, th / 2f, tw, th, 1f, 1f,
                turretRotation + wreckTurretOffset
            )
            batch.setColor(1f, 1f, 1f, 1f)
            return
        }

        val hullOutline = AssetManager.getRegion("hullo_$id")
        val turretOutline = AssetManager.getRegion("turreto_$id")
        val rx = MathUtils.cosDeg(turretRotation) * recoil
        val ry = MathUtils.sinDeg(turretRotation) * recoil
        val tx = turretX - rx
        val ty = turretY - ry
        val hx = position.x - hw / 2f
        val hy = position.y - hh / 2f

        // soft drop shadow on the ground
        batch.setColor(0f, 0f, 0f, 0.34f)
        batch.draw(hullOutline, hx + 5f, hy - 6f, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
        batch.draw(turretOutline, tx - pivot + 5f, ty - th / 2f - 6f, pivot, th / 2f, tw, th, 1f, 1f, turretRotation)

        // team outline: blue = friend, red = enemy
        batch.color = team.outline
        batch.draw(hullOutline, hx, hy, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
        batch.draw(turretOutline, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, 1f, 1f, turretRotation)
        batch.color = Color.WHITE

        // the tank itself, bump-lit by the tank shader when available
        if (Shaders.beginLit(batch)) {
            Shaders.drawLit(batch, hull, hx, hy, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
            Shaders.drawLit(batch, turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, 1f, 1f, turretRotation)
            Shaders.endLit(batch)
        } else {
            batch.draw(hull, hx, hy, hw / 2f, hh / 2f, hw, hh, 1f, 1f, rotation)
            batch.draw(turret, tx - pivot, ty - th / 2f, pivot, th / 2f, tw, th, 1f, 1f, turretRotation)
        }

        // minimal floating status: appears for a few seconds after a hit, or while the tank is damaged and close
        val showBar = barTimer > 0f || (currentHp < maxHealth && !playerControlled)
        if (showBar) {
            val barWidth = 60f
            val barHeight = 5f
            val barY = position.y + halfLen * 0.6f + 22f
            val hpRatio = (currentHp / maxHealth).coerceIn(0f, 1f)
            val pixel = AssetManager.getTexture("pixel")

            batch.color = Color(0f, 0f, 0f, 0.6f)
            batch.draw(pixel, position.x - barWidth / 2f - 1f, barY - 1f, barWidth + 2f, barHeight + 2f)
            batch.color = team.outline
            batch.draw(pixel, position.x - barWidth / 2f, barY, barWidth * hpRatio, barHeight)
            batch.color = Color.WHITE

            val label = if (playerControlled) "YOU" else "T${spec.tier} ${spec.shortName}"
            val font = AssetManager.fontSmall
            font.color = team.outline
            font.draw(batch, label, position.x - barWidth / 2f, barY + 24f)
            font.color = Color.WHITE
        }
    }

    private fun shortestAngleDiff(from: Float, to: Float): Float {
        var diff = (to - from) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return diff
    }
}
