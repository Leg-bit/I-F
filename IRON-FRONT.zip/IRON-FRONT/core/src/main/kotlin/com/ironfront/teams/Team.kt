package com.ironfront.teams

import com.badlogic.gdx.graphics.Color

/**
 * Every tank belongs to a team.
 * FRIEND = blue outline, ENEMY = red outline.
 */
enum class Team(val label: String, val outline: Color) {
    FRIEND("FRIEND", Color(0.20f, 0.55f, 1.00f, 1f)),
    ENEMY("ENEMY", Color(1.00f, 0.15f, 0.12f, 1f))
}
