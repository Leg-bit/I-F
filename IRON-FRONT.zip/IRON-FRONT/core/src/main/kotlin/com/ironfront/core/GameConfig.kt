package com.ironfront.core

object GameConfig {
    const val GAME_TITLE = "IRON FRONT"
    const val VIRTUAL_WIDTH = 1280f
    const val VIRTUAL_HEIGHT = 720f
    const val PIXELS_PER_METER = 32f
    const val MAP_WIDTH = 2560f
    const val MAP_HEIGHT = 2560f
    const val TILE_SIZE = 64f
    const val MAX_DT = 0.05f

    // ---- Real-life scaling ----
    /** Tank drawing/collision scale: 1 metre of real hull = 10 pixels. */
    const val PX_PER_M = 10f
    /** Range compression: 1 pixel = 1.5 m of flight distance (used for muzzle velocity and penetration fall-off). */
    const val METERS_PER_PX = 1.5f
    /** Real top speeds are on roads; cross-country is slower. */
    const val TERRAIN_SPEED_FACTOR = 0.75f
    /** Gameplay speed-ups for a phone screen (1.0 = fully realistic). */
    const val ARCADE_RELOAD = 0.5f
    const val ARCADE_TRAVERSE = 3f
    const val MAX_RANGE_M = 2500f
    /** Chance that a shell crossing the turret footprint hits the turret instead of the hull. */
    const val TURRET_HIT_CHANCE = 0.45f
}
