package com.ironfront.core

object GameConfig {
    const val GAME_TITLE = "IRON FRONT"
    const val VERSION = "3.0.1"
    const val VIRTUAL_WIDTH = 1280f
    const val VIRTUAL_HEIGHT = 720f
    const val PIXELS_PER_METER = 32f
    const val MAP_WIDTH = 2560f
    const val MAP_HEIGHT = 2560f
    const val TILE_SIZE = 64f
    const val MAX_DT = 0.05f
}
