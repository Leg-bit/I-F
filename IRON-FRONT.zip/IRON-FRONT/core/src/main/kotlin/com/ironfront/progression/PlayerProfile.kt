package com.ironfront.progression

class PlayerProfile(
    var commanderName: String = "Commander",
    var level: Int = 1,
    var freeXp: Int = 600,
    var totalXp: Int = 600,
    var battlesPlayed: Int = 0,
    var battlesWon: Int = 0,
    var totalKills: Int = 0
) {
    fun recordBattleResult(kills: Int, earnedXp: Int, won: Boolean) {
        battlesPlayed++
        if (won) battlesWon++
        totalKills += kills
        addXp(earnedXp)
    }

    fun addXp(amount: Int) {
        val a = amount.coerceAtLeast(0)
        freeXp += a
        totalXp += a
        refreshLevel()
    }

    /** Raises the commander level without adding spendable Free XP. */
    fun addLevelXp(amount: Int) {
        totalXp += amount.coerceAtLeast(0)
        refreshLevel()
    }

    fun refreshLevel() {
        level = 1 + totalXp / XP_PER_LEVEL
    }

    val xpIntoLevel: Int get() = totalXp % XP_PER_LEVEL

    companion object {
        const val XP_PER_LEVEL = 1500
    }
}
