package com.ironfront.progression

class PlayerProfile(
    var commanderName: String = "Commander",
    var level: Int = 1,
    var freeXp: Int = 600,
    var battlesPlayed: Int = 0,
    var totalKills: Int = 0
) {
    fun recordBattleResult(kills: Int, earnedXp: Int) {
        battlesPlayed++
        totalKills += kills
        freeXp += earnedXp
        level = 1 + (freeXp / 1000)
    }
}
