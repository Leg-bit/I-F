package com.ironfront.ui

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.ScreenAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.FitViewport
import com.ironfront.IronFront
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.tanks.TankDatabase

class MainMenuScreen(private val game: IronFront) : ScreenAdapter() {
    private val camera = OrthographicCamera()
    private val viewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, camera)
    private val touchPos = Vector3()

    private val headerColor = Color(0.18f, 0.22f, 0.18f, 1f)
    private val panelColor = Color(0.16f, 0.19f, 0.16f, 1f)
    private val playColor = Color(0.75f, 0.25f, 0.15f, 1f)
    private val garageColor = Color(0.22f, 0.38f, 0.25f, 1f)

    override fun render(delta: Float) {
        Gdx.gl.glClearColor(0.11f, 0.13f, 0.11f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)

        viewport.apply()
        game.batch.projectionMatrix = camera.combined

        val t = TankDatabase.get(GameManager.selectedTankId)
        val a = t.armor
        val ammo = t.gun.mainAmmo
        val b = game.batch

        b.begin()
        UiDraw.fillRect(b, 0f, 620f, 1280f, 100f, headerColor)
        UiDraw.text(b, "IRON FRONT // 2D ARMORED WARFARE", 40f, 680f)
        UiDraw.text(
            b,
            "Credits: ${GameManager.wallet.credits}  |  Gold: ${GameManager.wallet.gold}  |  XP: ${GameManager.playerProfile.freeXp}",
            680f, 680f
        )

        UiDraw.fillRect(b, 80f, 240f, 560f, 320f, panelColor)
        UiDraw.text(b, "ACTIVE: ${t.name}", 110f, 540f)
        UiDraw.text(b, "${t.nation.label} | Tier ${t.tier} | ${t.tankClass.label} | ${t.year}", 110f, 500f)
        UiDraw.text(b, "HP ${t.maxHp.toInt()} | ${t.massT} t | ${t.maxSpeedKmh.toInt()} km/h | crew ${t.crew}", 110f, 460f)
        UiDraw.text(
            b,
            "Hull armor F/S/R: ${a.hullFront.thicknessMm.toInt()}/${a.hullSide.thicknessMm.toInt()}/${a.hullRear.thicknessMm.toInt()} mm",
            110f, 420f
        )
        UiDraw.text(b, "Gun: ${t.gun.name}", 110f, 380f)
        UiDraw.text(b, "${ammo.kind.code} pen ${ammo.pen100Mm.toInt()} mm @100 m, ${ammo.pen1000Mm.toInt()} mm @1 km", 110f, 340f)

        UiDraw.button(b, 760f, 420f, 420f, 110f, playColor, "PLAY")
        UiDraw.button(b, 760f, 270f, 420f, 110f, garageColor, "GARAGE & TECH TREE")
        b.end()

        if (Gdx.input.justTouched()) {
            touchPos.set(Gdx.input.x.toFloat(), Gdx.input.y.toFloat(), 0f)
            viewport.unproject(touchPos)

            if (UiDraw.hit(touchPos.x, touchPos.y, 760f, 420f, 420f, 110f)) {
                ScreenManager.setScreen(BattleSetupScreen(game))
            } else if (UiDraw.hit(touchPos.x, touchPos.y, 760f, 270f, 420f, 110f)) {
                ScreenManager.setScreen(TechTreeScreen(game))
            }
        }
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }
}
