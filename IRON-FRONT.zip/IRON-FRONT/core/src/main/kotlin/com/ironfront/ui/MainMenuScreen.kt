package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.progression.PlayerProfile
import com.ironfront.tanks.TankDatabase

class MainMenuScreen(game: IronFront) : UiScreen(game) {
    private var time = 0f

    private class MenuButton(
        val label: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val color: Color,
        val action: () -> Unit
    )

    private val buttons = listOf(
        MenuButton("PLAY", 760f, 470f, 480f, 120f, Color(0.75f, 0.27f, 0.14f, 1f)) {
            ScreenManager.setScreen(BattleSetupScreen(game))
        },
        MenuButton("GARAGE", 760f, 360f, 480f, 90f, Color(0.20f, 0.38f, 0.26f, 1f)) {
            ScreenManager.setScreen(GarageScreen(game))
        },
        MenuButton("TECH TREE", 760f, 265f, 480f, 80f, Color(0.18f, 0.30f, 0.45f, 1f)) {
            ScreenManager.setScreen(TechTreeScreen(game))
        },
        MenuButton("EXCHANGE & DAILY SUPPLY", 760f, 170f, 480f, 80f, Color(0.45f, 0.35f, 0.12f, 1f)) {
            ScreenManager.setScreen(ShopScreen(game))
        }
    )

    override fun update(delta: Float) {
        time += delta
    }

    override fun draw(b: SpriteBatch) {
        val spec = TankDatabase.get(GameManager.selectedTankId)
        val p = GameManager.playerProfile

        // header
        UiDraw.fillRect(b, 0f, 640f, 1280f, 80f, Theme.header)
        UiDraw.fillRect(b, 0f, 638f, 1280f, 2f, Theme.border)
        UiDraw.big(b, "IRON FRONT", 30f, 706f, Theme.gold)
        UiDraw.small(b, "2D ARMORED WARFARE  v" + GameConfig.VERSION, 32f, 660f, Theme.textDim)
        UiDraw.currencyBar(b, 1250f, 668f)

        // active tank showcase
        UiDraw.panel(b, 40f, 100f, 680f, 520f)
        UiDraw.fillRect(b, 42f, 102f, 676f, 6f, spec.nation.primary)
        UiDraw.small(b, "ACTIVE TANK", 60f, 600f, Theme.textDim)
        UiDraw.text(b, spec.name, 60f, 575f)
        UiDraw.small(
            b,
            spec.nation.label + "  |  Tier " + spec.tier + "  |  " + spec.tankClass.label,
            60f, 543f, spec.nation.primary
        )

        val scale = UiDraw.iconScale(spec, 330f).coerceAtMost(4.2f)
        val sway = MathUtils.sin(time * 0.8f) * 25f
        UiDraw.tankIcon(b, spec, 380f, 385f, scale, 0f, sway)

        val a = spec.armor
        val infoY = 235f
        UiDraw.small(b, "HP " + spec.maxHp.toInt() + "    Speed " + spec.maxSpeedKmh.toInt() + " km/h    Weight " + spec.weightTons + " t", 60f, infoY, Theme.text)
        UiDraw.small(
            b,
            "Hull armour (F/S/R): " + a.hullFront.thicknessMm.toInt() + "/" + a.hullSide.thicknessMm.toInt() + "/" + a.hullRear.thicknessMm.toInt() + " mm",
            60f, infoY - 26f, Theme.text
        )
        UiDraw.small(
            b,
            "Turret armour (F/S/R): " + a.turretFront.thicknessMm.toInt() + "/" + a.turretSide.thicknessMm.toInt() + "/" + a.turretRear.thicknessMm.toInt() + " mm",
            60f, infoY - 52f, Theme.text
        )
        UiDraw.small(b, spec.gun.name + "   Pen " + spec.gun.apPen.toInt() + " mm   Reload " + spec.gun.reloadTimeSec + " s", 60f, infoY - 78f, Theme.gold)
        UiDraw.smallWrapped(b, spec.description, 60f, infoY - 106f, 640f)

        // buttons
        for (btn in buttons) {
            UiDraw.button(b, btn.x, btn.y, btn.w, btn.h, btn.color, btn.label)
        }

        // commander card
        UiDraw.panel(b, 760f, 100f, 480f, 55f)
        UiDraw.small(b, "COMMANDER  Lv " + p.level, 775f, 140f, Theme.text)
        UiDraw.bar(b, 775f, 108f, 300f, 12f, p.xpIntoLevel.toFloat() / PlayerProfile.XP_PER_LEVEL, Theme.xpColor)
        val sfx = if (com.ironfront.audio.AudioManager.sfxEnabled) "SOUND ON" else "SOUND OFF"
        UiDraw.smallButton(b, 1090f, 108f, 140f, 38f, Theme.panelLight, sfx)
        UiDraw.small(b, "Battles " + p.battlesPlayed + "  Wins " + p.battlesWon + "  Kills " + p.totalKills, 1090f, 90f, Theme.textDim)
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 1090f, 108f, 140f, 38f)) {
            AudioManager.sfxEnabled = !AudioManager.sfxEnabled
            AudioManager.playClick()
            return
        }
        for (btn in buttons) {
            if (UiDraw.hit(x, y, btn.x, btn.y, btn.w, btn.h)) {
                AudioManager.playClick()
                btn.action()
                return
            }
        }
    }
}
