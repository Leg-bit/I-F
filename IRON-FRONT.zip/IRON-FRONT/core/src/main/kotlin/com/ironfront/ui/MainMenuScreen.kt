package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.progression.PlayerProfile
import com.ironfront.save.SaveManager
import com.ironfront.tanks.TankDatabase

class MainMenuScreen(game: IronFront) : UiScreen(game) {
    private var time = 0f
    private var toast = ""
    private var toastTimer = 0f

    private class MenuButton(
        val label: String, val sub: String,
        val x: Float, val y: Float, val w: Float, val h: Float,
        val color: Color, val action: () -> Unit
    )

    private val buttons = listOf(
        MenuButton("DEPLOY TO BATTLE", "SKIRMISH & TACTICAL OPERATIONS", 760f, 505f, 480f, 105f, Theme.primary) {
            ScreenManager.setScreen(BattleSetupScreen(game))
        },
        MenuButton("ARMORED GARAGE", "LOADOUTS, AMMO & SPEC SHEET", 760f, 412f, 480f, 78f, Theme.darkGreen) {
            ScreenManager.setScreen(GarageScreen(game))
        },
        MenuButton("NATIONS TECH TREE", "RESEARCH & ELITE FIELD MODS", 760f, 322f, 480f, 78f, Color(0.15f, 0.28f, 0.44f, 1f)) {
            ScreenManager.setScreen(TechTreeScreen(game))
        },
        MenuButton("SUPPLY & EXCHANGE", "DAILY REWARDS, WAR BONDS & PACKS", 760f, 232f, 480f, 78f, Color(0.46f, 0.34f, 0.10f, 1f)) {
            ScreenManager.setScreen(ShopScreen(game))
        }
    )

    init {
        GameManager.refreshDailyContract()
    }

    override fun update(delta: Float) {
        time += delta
        if (toastTimer > 0f) toastTimer -= delta
    }

    override fun draw(b: SpriteBatch) {
        val spec = TankDatabase.get(GameManager.selectedTankId)
        val p = GameManager.playerProfile
        val isElite = GameManager.techTree.isElite(spec.id)

        UiDraw.tacticalBackdrop(b, time)

        // Header
        UiDraw.fillRect(b, 0f, 636f, 1280f, 84f, Theme.header)
        UiDraw.fillRect(b, 0f, 634f, 1280f, 2f, Theme.borderBright)
        UiDraw.fillRect(b, 26f, 650f, 6f, 54f, Theme.gold)
        UiDraw.big(b, "IRON FRONT", 44f, 704f, Theme.gold)
        UiDraw.small(b, "TACTICAL ARMORED WARFARE  |  BUILD v" + GameConfig.VERSION, 46f, 658f, Theme.textDim)
        UiDraw.currencyBar(b, 1254f, 666f)

        // Left Active Vehicle Hangar Showcase
        UiDraw.panel(b, 36f, 34f, 696f, 580f, Theme.panel, Theme.border, spec.nation.primary)
        UiDraw.badge(b, 56f, 574f, "TIER " + UiDraw.romanTier(spec.tier), Theme.panelLight, Theme.gold)
        UiDraw.badge(b, 148f, 574f, spec.nation.label.uppercase(), Theme.panelLight, spec.nation.primary)
        UiDraw.badge(b, 276f, 574f, spec.tankClass.label.uppercase(), Theme.panelLight, Theme.cyan)
        if (isElite) {
            UiDraw.badge(b, 444f, 574f, "ELITE FIELD MOD", Color(0.28f, 0.14f, 0.36f, 1f), Theme.warBonds)
        }

        UiDraw.big(b, spec.name, 56f, 556f, Theme.text)
        UiDraw.small(b, "Tank Mastery XP: " + GameManager.techTree.getTankXp(spec.id) + " XP", 56f, 514f, Theme.xpColor)

        // Turntable ring visual
        val cx = 384f
        val cy = 385f
        val circle = AssetManager.getRegion("circle")
        b.color = Color(spec.nation.primary.r, spec.nation.primary.g, spec.nation.primary.b, 0.10f)
        b.draw(circle, cx - 145f, cy - 145f, 290f, 290f)
        b.color = Color(1f, 1f, 1f, 0.06f)
        b.draw(circle, cx - 110f, cy - 110f, 220f, 220f)
        b.color = Color.WHITE

        val scale = UiDraw.iconScale(spec, 340f).coerceAtMost(4.3f)
        val sway = MathUtils.sin(time * 0.85f) * 26f
        UiDraw.tankIcon(b, spec, cx, cy, scale, 0f, sway, Color.WHITE, true)

        // Segmented Quick Performance Bars
        val barX = 56f
        val barW = 290f
        val hpMult = if (isElite) 1.08f else 1f
        val spdMult = if (isElite) 1.06f else 1f
        val rldMult = if (isElite) 1.06f else 1f

        UiDraw.small(b, "FIREPOWER  (Pen ${spec.gun.apPen.toInt()} mm | Dmg ${spec.gun.baseDamage.toInt()})", barX, 248f, Theme.gold)
        UiDraw.segmentedBar(b, barX, 218f, barW, 11f, spec.gun.apPen / 260f, Theme.gold)

        UiDraw.small(b, "ARMOR  (Hull ${spec.armor.hullFront.effective(0f).toInt()} mm | HP ${(spec.maxHp * hpMult).toInt()})", barX + 325f, 248f, Theme.green)
        UiDraw.segmentedBar(b, barX + 325f, 218f, barW, 11f, spec.armor.hullFront.effective(0f) / 220f, Theme.green)

        UiDraw.small(b, "MOBILITY  (${(spec.maxSpeedKmh * spdMult).toInt()} km/h | ${String.format("%.1f", spec.powerToWeight)} hp/t)", barX, 192f, Theme.cyan)
        UiDraw.segmentedBar(b, barX, 162f, barW, 11f, (spec.maxSpeedKmh * spdMult) / 72f, Theme.cyan)

        UiDraw.small(b, "RELOAD & OPTICS  (${String.format("%.2f", spec.gun.reloadTimeSec / rldMult)}s | ${spec.viewRangePx.toInt()}m)", barX + 325f, 192f, Theme.orange)
        UiDraw.segmentedBar(b, barX + 325f, 162f, barW, 11f, (1f - (spec.gun.reloadTimeSec / rldMult) / 14f).coerceIn(0.15f, 1f), Theme.orange)

        UiDraw.fillRect(b, 56f, 144f, 656f, 1f, Theme.border)
        UiDraw.smallWrapped(b, spec.description, 56f, 132f, 656f, Theme.textDim)

        for (btn in buttons) {
            UiDraw.button(b, btn.x, btn.y, btn.w, btn.h, btn.color, btn.label, btn.sub)
        }

        // Daily Combat Contract Card
        val targetKills = 5
        val progress = GameManager.dailyContractKills.coerceAtMost(targetKills)
        val readyToClaim = progress >= targetKills && !GameManager.dailyContractClaimed
        UiDraw.panel(b, 760f, 144f, 480f, 74f, Theme.panelLight, if (readyToClaim) Theme.gold else Theme.border)
        UiDraw.small(b, "DAILY CONTRACT: DESTROY 5 ENEMY TANKS", 776f, 206f, Theme.gold)
        UiDraw.bar(b, 776f, 162f, 270f, 14f, progress.toFloat() / targetKills, Theme.green)
        UiDraw.small(b, "$progress / $targetKills KILLS  (+15 WAR BONDS, +2,500 CR)", 776f, 188f, Theme.textDim)
        if (GameManager.dailyContractClaimed) {
            UiDraw.smallButton(b, 1068f, 156f, 156f, 46f, Theme.dark, "COMPLETED")
        } else if (readyToClaim) {
            UiDraw.smallButton(b, 1068f, 156f, 156f, 46f, Theme.darkGreen, "CLAIM REWARD", Theme.gold)
        } else {
            UiDraw.smallButton(b, 1068f, 156f, 156f, 46f, Theme.panel, "IN PROGRESS")
        }

        // Commander Service Record Footer
        UiDraw.panel(b, 760f, 34f, 480f, 96f)
        val winRate = if (p.battlesPlayed > 0) (p.battlesWon * 100 / p.battlesPlayed) else 0
        UiDraw.small(b, "COMMANDER RANK Lv.${p.level}  |  WIN RATE $winRate%  |  ${p.totalKills} KILLS", 776f, 118f, Theme.text)
        UiDraw.bar(b, 776f, 88f, 448f, 10f, p.xpIntoLevel.toFloat() / PlayerProfile.XP_PER_LEVEL, Theme.xpColor)

        val sfx = if (AudioManager.sfxEnabled) "AUDIO: ON" else "AUDIO: OFF"
        val ctrl = if (GameManager.controlDirect) "STEERING: DIRECT" else "STEERING: TANK"
        UiDraw.smallButton(b, 776f, 44f, 180f, 34f, Theme.panelLight, sfx)
        UiDraw.smallButton(b, 968f, 44f, 256f, 34f, Theme.panelLight, ctrl)

        if (toastTimer > 0f) {
            UiDraw.panel(b, 430f, 330f, 420f, 54f, Theme.panelLight, Theme.gold)
            UiDraw.centered(b, AssetManager.font, toast, 640f, 357f, Theme.gold)
        }
    }

    private fun say(msg: String) {
        toast = msg
        toastTimer = 2.4f
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 1068f, 156f, 156f, 46f)) {
            if (GameManager.dailyContractKills >= 5 && !GameManager.dailyContractClaimed) {
                GameManager.dailyContractClaimed = true
                GameManager.wallet.addWarBonds(15)
                GameManager.wallet.addCredits(2500)
                SaveManager.save()
                AudioManager.playClick()
                say("Contract Claimed: +15 War Bonds & +2,500 CR!")
            }
            return
        }
        if (UiDraw.hit(x, y, 776f, 44f, 180f, 34f)) {
            AudioManager.sfxEnabled = !AudioManager.sfxEnabled
            AudioManager.playClick()
            return
        }
        if (UiDraw.hit(x, y, 968f, 44f, 256f, 34f)) {
            GameManager.controlDirect = !GameManager.controlDirect
            SaveManager.save()
            AudioManager.playClick()
            return
        }
        for (btn in buttons) {
            if (UiDraw.hit(x, y, btn.x, btn.y, btn.w, btn.h)) {
                AudioManager.playClick()
                btn.action()
                return
            }
        }
    }
}
