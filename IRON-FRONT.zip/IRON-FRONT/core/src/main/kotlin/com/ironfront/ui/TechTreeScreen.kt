package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.nations.Nation
import com.ironfront.research.NodeStatus
import com.ironfront.save.SaveManager
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec

class TechTreeScreen(game: IronFront) : UiScreen(game) {
    private var nation: Nation = TankDatabase.get(GameManager.selectedTankId).nation
    private var selectedId: String = GameManager.selectedTankId
    private var scrollX = 0f
    private var toast = ""
    private var toastTimer = 0f

    private val nodeW = 196f
    private val nodeH = 108f
    private val colW = 230f
    private val rowH = 116f
    private val areaTop = 568f
    private val areaBottom = 246f
    private val treeX0 = 34f

    private class Node(val spec: TankSpec, val x: Float, val y: Float)

    private fun layout(): Map<String, Node> {
        val list = TankDatabase.ofNation(nation)
        val result = linkedMapOf<String, Node>()
        val centerY = (areaTop + areaBottom) / 2f
        for (tier in 1..6) {
            val group = list.filter { it.tier == tier }
            group.forEachIndexed { i, spec ->
                val x = treeX0 + (tier - 1) * colW - scrollX
                val y = centerY + ((group.size - 1) / 2f - i) * rowH - nodeH / 2f
                result[spec.id] = Node(spec, x, y)
            }
        }
        return result
    }

    private fun maxScroll(): Float = (treeX0 + 6 * colW - 1245f).coerceAtLeast(0f)

    override fun update(delta: Float) {
        if (toastTimer > 0f) toastTimer -= delta
    }

    private fun statusColor(spec: TankSpec): Color = when {
        GameManager.techTree.isElite(spec.id) -> Theme.warBonds
        GameManager.techTree.status(spec) == NodeStatus.OWNED -> Theme.green
        GameManager.techTree.status(spec) == NodeStatus.AVAILABLE -> Theme.gold
        else -> Theme.grey
    }

    override fun draw(b: SpriteBatch) {
        scrollX = MathUtils.clamp(scrollX, 0f, maxScroll())
        UiDraw.tacticalBackdrop(b)

        UiDraw.fillRect(b, 0f, 646f, 1280f, 74f, Theme.header)
        UiDraw.fillRect(b, 0f, 644f, 1280f, 2f, Theme.borderBright)
        UiDraw.smallButton(b, 20f, 660f, 118f, 46f, Theme.darkRed, "< HANGAR")
        UiDraw.big(b, "TECH TREE", 156f, 702f, Theme.gold)
        UiDraw.currencyBar(b, 1260f, 666f)

        val tabW = 240f
        for ((i, n) in Nation.values().withIndex()) {
            val x = 20f + i * (tabW + 5f)
            val sel = n == nation
            UiDraw.fillRect(b, x, 588f, tabW, 48f, if (sel) Theme.panelLight else Theme.panel)
            UiDraw.fillRect(b, x, 588f, tabW, 4f, n.primary)
            if (sel) UiDraw.outlineRect(b, x, 588f, tabW, 48f, 2f, Theme.gold)
            val owned = GameManager.techTree.ownedCount(n)
            val total = TankDatabase.ofNation(n).size
            UiDraw.centered(b, AssetManager.fontSmall, "${n.label.uppercase()}  ($owned/$total)", x + tabW / 2f, 616f, if (sel) Theme.text else Theme.textDim)
        }

        UiDraw.panel(b, 20f, areaBottom - 12f, 1240f, areaTop - areaBottom + 24f)

        for (tier in 1..6) {
            val colX = treeX0 + (tier - 1) * colW - scrollX
            if (tier % 2 == 0) {
                UiDraw.fillRect(b, colX - 12f, areaBottom - 8f, colW, areaTop - areaBottom + 16f, Color(1f, 1f, 1f, 0.02f))
            }
            UiDraw.badge(b, colX, areaTop - 16f, "TIER " + UiDraw.romanTier(tier), Theme.panelLight, Theme.textDim)
        }

        val nodes = layout()
        for (node in nodes.values) {
            for (pid in node.spec.parents) {
                val parent = nodes[pid] ?: continue
                val c = statusColor(node.spec)
                val x1 = parent.x + nodeW
                val y1 = parent.y + nodeH / 2f
                val x2 = node.x
                val y2 = node.y + nodeH / 2f
                val mid = (x1 + x2) / 2f
                UiDraw.line(b, x1, y1, mid, y1, 3f, c)
                UiDraw.line(b, mid, y1, mid, y2, 3f, c)
                UiDraw.line(b, mid, y2, x2, y2, 3f, c)
            }
        }
        for (node in nodes.values) drawNode(b, node)

        drawDetail(b)

        if (toastTimer > 0f) {
            UiDraw.panel(b, 430f, 520f, 420f, 50f, Theme.panelLight, Theme.gold)
            UiDraw.centered(b, AssetManager.font, toast, 640f, 545f, Theme.gold)
        }
    }

    private fun drawNode(b: SpriteBatch, node: Node) {
        val spec = node.spec
        val tree = GameManager.techTree
        val status = tree.status(spec)
        val isElite = tree.isElite(spec.id)
        val selected = spec.id == selectedId
        val active = spec.id == GameManager.selectedTankId
        val sColor = statusColor(spec)

        val fill = when {
            isElite -> Color(0.18f, 0.11f, 0.24f, 1f)
            status == NodeStatus.OWNED -> Color(0.11f, 0.24f, 0.17f, 1f)
            status == NodeStatus.AVAILABLE -> Color(0.22f, 0.18f, 0.10f, 1f)
            else -> Color(0.09f, 0.11f, 0.14f, 1f)
        }

        UiDraw.fillRect(b, node.x + 3f, node.y - 3f, nodeW, nodeH, Color(0f, 0f, 0f, 0.4f))
        UiDraw.fillRect(b, node.x, node.y, nodeW, nodeH, fill)
        UiDraw.fillRect(b, node.x, node.y + nodeH - 3f, nodeW, 3f, sColor)
        UiDraw.outlineRect(b, node.x, node.y, nodeW, nodeH, if (selected) 3f else 1.5f, if (selected) Color.WHITE else sColor)

        val tint = if (status == NodeStatus.LOCKED) Color(0.42f, 0.45f, 0.50f, 1f) else Color.WHITE
        UiDraw.tankIcon(b, spec, node.x + nodeW / 2f, node.y + nodeH - 40f, UiDraw.iconScale(spec, 102f), 0f, 0f, tint)
        UiDraw.centered(b, AssetManager.fontSmall, spec.shortName, node.x + nodeW / 2f, node.y + 38f, Theme.text)

        val label = when {
            active && isElite -> "ACTIVE * ELITE"
            active -> "ACTIVE"
            isElite -> "ELITE"
            status == NodeStatus.OWNED -> "OWNED"
            status == NodeStatus.AVAILABLE -> UiDraw.formatNumber(spec.purchaseCostCredits) + " CR"
            else -> "LOCKED"
        }
        UiDraw.centered(b, AssetManager.fontSmall, label, node.x + nodeW / 2f, node.y + 16f, sColor)

        val clsCode = when (spec.tankClass.name) {
            "LIGHT" -> "LT"
            "MEDIUM" -> "MT"
            "HEAVY" -> "HT"
            else -> "TD"
        }
        UiDraw.small(b, clsCode, node.x + 8f, node.y + nodeH - 8f, Theme.textDim)
        val tXp = tree.getTankXp(spec.id)
        if (tXp > 0) UiDraw.rightText(b, AssetManager.fontSmall, "${tXp}XP", node.x + nodeW - 8f, node.y + nodeH - 8f, Theme.xpColor)
    }

    private fun drawDetail(b: SpriteBatch) {
        val spec = TankDatabase.get(selectedId)
        val tree = GameManager.techTree
        val status = tree.status(spec)
        val isElite = tree.isElite(spec.id)

        UiDraw.panel(b, 20f, 18f, 1240f, 204f, Theme.panel, Theme.border, spec.nation.primary)
        UiDraw.fillRect(b, 36f, 34f, 270f, 172f, Theme.panelLight)
        UiDraw.outlineRect(b, 36f, 34f, 270f, 172f, 1f, Theme.border)
        UiDraw.tankIcon(b, spec, 171f, 125f, UiDraw.iconScale(spec, 215f).coerceAtMost(3.3f), 0f, 0f, Color.WHITE, true)
        UiDraw.centered(b, AssetManager.fontSmall, "Mastery XP: " + tree.getTankXp(spec.id), 171f, 52f, Theme.xpColor)

        UiDraw.text(b, spec.name, 326f, 206f)
        UiDraw.badge(b, 326f, 158f, "TIER " + UiDraw.romanTier(spec.tier), Theme.panelLight, Theme.gold)
        UiDraw.badge(b, 416f, 158f, spec.tankClass.label.uppercase(), Theme.panelLight, Theme.cyan)
        if (isElite) {
            UiDraw.badge(b, 566f, 158f, "ELITE +8% HP / +6% SPD / +6% RLD", Color(0.28f, 0.14f, 0.36f, 1f), Theme.warBonds)
        }
        UiDraw.smallWrapped(b, spec.description, 326f, 144f, 430f, Theme.textDim)

        val a = spec.armor
        val x2 = 776f
        UiDraw.small(b, "HP ${spec.maxHp.toInt()}  |  Speed ${spec.maxSpeedKmh.toInt()} km/h  |  Weight ${spec.weightTons} t", x2, 204f, Theme.text)
        UiDraw.small(b, "Hull Armor ${a.hullFront.thicknessMm.toInt()}/${a.hullSide.thicknessMm.toInt()}/${a.hullRear.thicknessMm.toInt()} mm  |  Turret ${a.turretFront.thicknessMm.toInt()} mm", x2, 180f, Theme.text)
        UiDraw.small(b, "${spec.gun.name}  (Pen ${spec.gun.apPen.toInt()} mm | Dmg ${spec.gun.baseDamage.toInt()} | ${spec.gun.reloadTimeSec}s)", x2, 156f, Theme.gold)

        val parentNames = spec.parents.joinToString(" or ") { TankDatabase.get(it).shortName }
        val req = if (spec.parents.isEmpty()) "Starting Vehicle (No prerequisites)" else "Prerequisite: $parentNames"
        UiDraw.small(b, req, x2, 126f, if (status == NodeStatus.LOCKED) Theme.red else Theme.textDim)

        if (status != NodeStatus.OWNED) {
            val availXp = tree.availableXpFor(spec)
            UiDraw.small(b, "Research Cost: ${spec.researchCostXp} XP (Pool: $availXp)", x2, 98f, if (availXp >= spec.researchCostXp) Theme.green else Theme.red)
            UiDraw.small(b, "Purchase Cost: ${UiDraw.formatNumber(spec.purchaseCostCredits)} CR", x2, 74f, if (GameManager.wallet.credits >= spec.purchaseCostCredits) Theme.green else Theme.red)
        } else if (!isElite) {
            val bondCost = tree.eliteUpgradeCostBonds(spec)
            UiDraw.small(b, "Field Modification: $bondCost War Bonds (+8% HP, +6% Speed, +6% Reload)", x2, 90f, Theme.warBonds)
        } else {
            UiDraw.small(b, "Vehicle fully upgraded to Elite Field Modification!", x2, 90f, Theme.warBonds)
        }

        when (status) {
            NodeStatus.OWNED -> {
                if (!isElite) {
                    val bondCost = tree.eliteUpgradeCostBonds(spec)
                    val canElite = GameManager.wallet.canAffordWarBonds(bondCost)
                    UiDraw.button(b, 1030f, 114f, 210f, 54f, Color(0.38f, 0.18f, 0.50f, 1f), "ELITE UPGRADE", "$bondCost WAR BONDS", canElite)
                }
                if (spec.id == GameManager.selectedTankId) {
                    UiDraw.button(b, 1030f, 40f, 210f, 60f, Theme.grey, "SELECTED", null, false)
                } else {
                    UiDraw.button(b, 1030f, 40f, 210f, 60f, Theme.darkGreen, "DEPLOY TANK")
                }
            }
            NodeStatus.AVAILABLE -> {
                UiDraw.button(b, 1030f, 45f, 210f, 76f, Color(0.75f, 0.52f, 0.10f, 1f), "RESEARCH & BUY", null, tree.canAfford(spec))
            }
            NodeStatus.LOCKED -> {
                UiDraw.button(b, 1030f, 45f, 210f, 76f, Theme.dark, "LOCKED", "UNLOCK PARENT FIRST", false)
            }
        }
    }

    private fun say(text: String) {
        toast = text
        toastTimer = 2.4f
    }

    override fun onDrag(dx: Float, dy: Float) {
        scrollX -= dx
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 20f, 660f, 118f, 46f)) {
            SaveManager.save()
            AudioManager.playClick()
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }
        val tabW = 240f
        for ((i, n) in Nation.values().withIndex()) {
            if (UiDraw.hit(x, y, 20f + i * (tabW + 5f), 588f, tabW, 48f)) {
                nation = n
                scrollX = 0f
                TankDatabase.ofNation(n).firstOrNull()?.let { selectedId = it.id }
                AudioManager.playClick()
                return
            }
        }
        val spec = TankDatabase.get(selectedId)
        val tree = GameManager.techTree
        val status = tree.status(spec)

        if (status == NodeStatus.OWNED && !tree.isElite(spec.id) && UiDraw.hit(x, y, 1030f, 114f, 210f, 54f)) {
            AudioManager.playClick()
            if (tree.upgradeToElite(spec.id)) {
                SaveManager.save()
                say("${spec.shortName} upgraded to ELITE!")
            } else {
                say("Need ${tree.eliteUpgradeCostBonds(spec)} War Bonds")
            }
            return
        }
        if (UiDraw.hit(x, y, 1030f, 40f, 210f, 80f)) {
            when (status) {
                NodeStatus.OWNED -> {
                    GameManager.selectedTankId = spec.id
                    SaveManager.save()
                    say("${spec.shortName} set as active tank")
                }
                NodeStatus.AVAILABLE -> {
                    if (tree.researchAndBuy(spec.id)) {
                        GameManager.selectedTankId = spec.id
                        SaveManager.save()
                        say("Researched & Purchased ${spec.shortName}!")
                    } else if (tree.availableXpFor(spec) < spec.researchCostXp) {
                        say("Not enough XP (need ${spec.researchCostXp})")
                    } else {
                        say("Not enough Credits (need ${spec.purchaseCostCredits})")
                    }
                }
                NodeStatus.LOCKED -> say("Research prerequisite tank first")
            }
            AudioManager.playClick()
            return
        }
        if (y >= areaBottom - 12f && y <= areaTop + 12f) {
            for (node in layout().values) {
                if (UiDraw.hit(x, y, node.x, node.y, nodeW, nodeH)) {
                    selectedId = node.spec.id
                    AudioManager.playClick()
                    return
                }
            }
        }
    }
}
