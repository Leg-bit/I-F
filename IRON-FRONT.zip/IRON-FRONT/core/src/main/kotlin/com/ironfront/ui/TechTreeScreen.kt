package com.ironfront.ui

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.IronFront
import com.ironfront.audio.AudioManager
import com.ironfront.core.AssetManager
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.nations.Nation
import com.ironfront.research.NodeStatus
import com.ironfront.save.SaveManager
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec

/** One tree per nation: columns are tiers, lines connect parent to child. Drag sideways to scroll. */
class TechTreeScreen(game: IronFront) : UiScreen(game) {
    private var nation: Nation = TankDatabase.get(GameManager.selectedTankId).nation
    private var selectedId: String = GameManager.selectedTankId
    private var scrollX = 0f
    private var toast = ""
    private var toastTimer = 0f

    private val nodeW = 186f
    private val nodeH = 104f
    private val colW = 222f
    private val rowH = 114f
    private val areaTop = 575f
    private val areaBottom = 240f
    private val treeX0 = 30f

    private class Node(val spec: TankSpec, val x: Float, val y: Float)

    private fun layout(): Map<String, Node> {
        val list = TankDatabase.ofNation(nation)
        val result = linkedMapOf<String, Node>()
        val centerY = (areaTop + areaBottom) / 2f
        for (tier in 1..6) {
            val group = list.filter { it.tier == tier }
            group.forEachIndexed { i, spec ->
                val x = treeX0 + (tier - 1) * colW - scrollX
                val y = centerY + ((group.size - 1) / 2f - i) * rowH - nodeH / 2f
                result[spec.id] = Node(spec, x, y)
            }
        }
        return result
    }

    private fun maxScroll(): Float = (treeX0 + 6 * colW - 1250f).coerceAtLeast(0f)

    override fun update(delta: Float) {
        if (toastTimer > 0f) toastTimer -= delta
    }

    private fun statusColor(spec: TankSpec): Color = when (GameManager.techTree.status(spec)) {
        NodeStatus.OWNED -> Theme.green
        NodeStatus.AVAILABLE -> Theme.gold
        NodeStatus.LOCKED -> Theme.grey
    }

    override fun draw(b: SpriteBatch) {
        scrollX = MathUtils.clamp(scrollX, 0f, maxScroll())

        UiDraw.fillRect(b, 0f, 650f, 1280f, 70f, Theme.header)
        UiDraw.fillRect(b, 0f, 648f, 1280f, 2f, Theme.border)
        UiDraw.smallButton(b, 20f, 662f, 120f, 46f, Theme.darkRed, "< BACK")
        UiDraw.big(b, "TECH TREE", 165f, 703f, Theme.gold)
        UiDraw.currencyBar(b, 1250f, 668f)

        // nation tabs
        val tabW = 238f
        for ((i, n) in Nation.values().withIndex()) {
            val x = 20f + i * (tabW + 5f)
            val sel = n == nation
            UiDraw.fillRect(b, x, 592f, tabW, 50f, if (sel) Theme.panelLight else Theme.panel)
            UiDraw.fillRect(b, x, 592f, tabW, 5f, n.primary)
            if (sel) UiDraw.outlineRect(b, x, 592f, tabW, 50f, 2f, Theme.gold)
            val owned = GameManager.techTree.ownedCount(n)
            val total = TankDatabase.ofNation(n).size
            UiDraw.centered(b, AssetManager.font, n.label + "  " + owned + "/" + total, x + tabW / 2f, 622f, if (sel) Theme.text else Theme.textDim)
        }

        // tree
        UiDraw.panel(b, 20f, areaBottom - 10f, 1240f, areaTop - areaBottom + 25f)
        val nodes = layout()
        for (tier in 1..6) {
            UiDraw.small(b, "TIER " + tier, treeX0 + (tier - 1) * colW - scrollX + 4f, areaTop + 5f, Theme.textDim)
        }

        // connection lines first
        for (node in nodes.values) {
            for (pid in node.spec.parents) {
                val parent = nodes[pid] ?: continue
                val c = statusColor(node.spec)
                val x1 = parent.x + nodeW
                val y1 = parent.y + nodeH / 2f
                val x2 = node.x
                val y2 = node.y + nodeH / 2f
                val mid = (x1 + x2) / 2f
                UiDraw.line(b, x1, y1, mid, y1, 3f, c)
                UiDraw.line(b, mid, y1, mid, y2, 3f, c)
                UiDraw.line(b, mid, y2, x2, y2, 3f, c)
            }
        }
        for (node in nodes.values) drawNode(b, node)

        drawDetail(b)

        if (toastTimer > 0f) {
            UiDraw.centered(b, AssetManager.font, toast, 640f, 560f, Theme.gold)
        }
    }

    private fun drawNode(b: SpriteBatch, node: Node) {
        val spec = node.spec
        val status = GameManager.techTree.status(spec)
        val selected = spec.id == selectedId
        val active = spec.id == GameManager.selectedTankId
        val fill = when (status) {
            NodeStatus.OWNED -> Color(0.13f, 0.27f, 0.17f, 1f)
            NodeStatus.AVAILABLE -> Color(0.20f, 0.19f, 0.10f, 1f)
            NodeStatus.LOCKED -> Color(0.11f, 0.12f, 0.13f, 1f)
        }
        UiDraw.fillRect(b, node.x, node.y, nodeW, nodeH, fill)
        UiDraw.outlineRect(b, node.x, node.y, nodeW, nodeH, if (selected) 3f else 2f, if (selected) Color.WHITE else statusColor(spec))
        val tint = if (status == NodeStatus.LOCKED) Color(0.45f, 0.45f, 0.5f, 1f) else Color.WHITE
        UiDraw.tankIcon(b, spec, node.x + nodeW / 2f, node.y + nodeH - 38f, UiDraw.iconScale(spec, 100f), 0f, 0f, tint)
        UiDraw.centered(b, AssetManager.fontSmall, spec.shortName, node.x + nodeW / 2f, node.y + 36f, Theme.text)
        val label = when {
            active -> "ACTIVE"
            status == NodeStatus.OWNED -> "OWNED"
            status == NodeStatus.AVAILABLE -> spec.purchaseCostCredits.toString() + " CR"
            else -> "LOCKED"
        }
        UiDraw.centered(b, AssetManager.fontSmall, label, node.x + nodeW / 2f, node.y + 14f, statusColor(spec))
        UiDraw.small(b, spec.tankClass.label.substring(0, 1), node.x + 8f, node.y + nodeH - 6f, Theme.textDim)
    }

    private fun drawDetail(b: SpriteBatch) {
        val spec = TankDatabase.get(selectedId)
        val tree = GameManager.techTree
        val status = tree.status(spec)
        UiDraw.panel(b, 20f, 20f, 1240f, 200f)
        UiDraw.fillRect(b, 22f, 22f, 6f, 196f, spec.nation.primary)

        UiDraw.tankIcon(b, spec, 190f, 120f, UiDraw.iconScale(spec, 220f).coerceAtMost(3.4f))
        UiDraw.text(b, spec.name, 340f, 205f)
        UiDraw.small(b, spec.nation.label + "  |  Tier " + spec.tier + "  |  " + spec.tankClass.label, 340f, 175f, spec.nation.primary)
        UiDraw.smallWrapped(b, spec.description, 340f, 150f, 420f)

        val a = spec.armor
        val x2 = 790f
        UiDraw.small(b, "Weight " + spec.weightTons + " t   HP " + spec.maxHp.toInt() + "   Speed " + spec.maxSpeedKmh.toInt() + " km/h", x2, 205f, Theme.text)
        UiDraw.small(
            b,
            "Hull F/S/R " + a.hullFront.thicknessMm.toInt() + "/" + a.hullSide.thicknessMm.toInt() + "/" + a.hullRear.thicknessMm.toInt() +
                " mm   Turret F " + a.turretFront.thicknessMm.toInt() + " mm",
            x2, 180f, Theme.text
        )
        UiDraw.small(b, "Front slope " + a.hullFront.slopeDeg.toInt() + " deg   Crew " + spec.crew + "   Engine " + spec.enginePowerHp + " hp", x2, 155f, Theme.text)
        UiDraw.small(b, spec.gun.name, x2, 130f, Theme.gold)
        UiDraw.small(b, "Pen " + spec.gun.apPen.toInt() + " mm   Dmg " + spec.gun.baseDamage.toInt() + "   Reload " + spec.gun.reloadTimeSec + " s", x2, 105f, Theme.gold)

        // requirements
        val parentNames = spec.parents.joinToString(" or ") { TankDatabase.get(it).shortName }
        val req = if (spec.parents.isEmpty()) "No prerequisites" else "Requires: " + parentNames
        UiDraw.small(b, req, x2, 78f, if (status == NodeStatus.LOCKED) Theme.red else Theme.textDim)
        if (status != NodeStatus.OWNED) {
            val xpOk = GameManager.playerProfile.freeXp >= spec.researchCostXp
            val crOk = GameManager.wallet.credits >= spec.purchaseCostCredits
            UiDraw.small(b, "XP " + spec.researchCostXp, x2, 52f, if (xpOk) Theme.green else Theme.red)
            UiDraw.small(b, "CR " + spec.purchaseCostCredits, x2 + 140f, 52f, if (crOk) Theme.green else Theme.red)
        }

        // action button
        when (status) {
            NodeStatus.OWNED -> {
                if (spec.id == GameManager.selectedTankId) {
                    UiDraw.button(b, 1040f, 40f, 200f, 60f, Theme.grey, "ACTIVE")
                } else {
                    UiDraw.button(b, 1040f, 40f, 200f, 60f, Theme.darkGreen, "SET ACTIVE")
                }
            }
            NodeStatus.AVAILABLE -> UiDraw.button(b, 1040f, 40f, 200f, 60f, Color(0.70f, 0.50f, 0.10f, 1f), "RESEARCH")
            NodeStatus.LOCKED -> UiDraw.button(b, 1040f, 40f, 200f, 60f, Theme.dark, "LOCKED")
        }
    }

    private fun say(text: String) {
        toast = text
        toastTimer = 2.4f
    }

    override fun onDrag(dx: Float, dy: Float) {
        scrollX -= dx
    }

    override fun onTap(x: Float, y: Float) {
        if (UiDraw.hit(x, y, 20f, 662f, 120f, 46f)) {
            SaveManager.save()
            AudioManager.playClick()
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }

        // nation tabs
        val tabW = 238f
        for ((i, n) in Nation.values().withIndex()) {
            if (UiDraw.hit(x, y, 20f + i * (tabW + 5f), 592f, tabW, 50f)) {
                nation = n
                scrollX = 0f
                val first = TankDatabase.ofNation(n).firstOrNull()
                if (first != null) selectedId = first.id
                AudioManager.playClick()
                return
            }
        }

        // action button
        if (UiDraw.hit(x, y, 1040f, 40f, 200f, 60f)) {
            val spec = TankDatabase.get(selectedId)
            val tree = GameManager.techTree
            when (tree.status(spec)) {
                NodeStatus.OWNED -> {
                    GameManager.selectedTankId = spec.id
                    SaveManager.save()
                    say(spec.shortName + " is now your active tank")
                }
                NodeStatus.AVAILABLE -> {
                    if (tree.researchAndBuy(spec.id)) {
                        GameManager.selectedTankId = spec.id
                        SaveManager.save()
                        say("Researched " + spec.shortName + "!")
                    } else if (GameManager.playerProfile.freeXp < spec.researchCostXp) {
                        say("Not enough XP (need " + spec.researchCostXp + ")")
                    } else {
                        say("Not enough credits (need " + spec.purchaseCostCredits + ")")
                    }
                }
                NodeStatus.LOCKED -> say("Research a previous tank first")
            }
            AudioManager.playClick()
            return
        }

        // nodes
        if (y >= areaBottom - 10f && y <= areaTop + 15f) {
            for (node in layout().values) {
                if (UiDraw.hit(x, y, node.x, node.y, nodeW, nodeH)) {
                    selectedId = node.spec.id
                    AudioManager.playClick()
                    return
                }
            }
        }
    }
}
