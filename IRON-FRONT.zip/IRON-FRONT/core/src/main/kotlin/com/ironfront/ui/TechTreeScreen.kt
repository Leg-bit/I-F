package com.ironfront.ui

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.ScreenAdapter
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.viewport.FitViewport
import com.ironfront.IronFront
import com.ironfront.core.GameConfig
import com.ironfront.core.GameManager
import com.ironfront.core.ScreenManager
import com.ironfront.save.SaveManager
import com.ironfront.tanks.Nation
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec

/**
 * Garage + tech tree. Pick a nation, tap a tank to see its real specs,
 * then RESEARCH (XP) -> BUY (credits) -> SELECT.
 */
class TechTreeScreen(private val game: IronFront) : ScreenAdapter() {
    private val camera = OrthographicCamera()
    private val viewport = FitViewport(GameConfig.VIRTUAL_WIDTH, GameConfig.VIRTUAL_HEIGHT, camera)
    private val touchPos = Vector3()

    private val nations = Nation.values()
    private var nation: Nation = TankDatabase.get(GameManager.selectedTankId).nation
    private var selectedId: String = GameManager.selectedTankId
    private var message: String = ""

    private enum class State { EQUIPPED, OWNED, RESEARCHED, AVAILABLE, LOCKED }

    private val bg = Color(0.09f, 0.11f, 0.10f, 1f)
    private val header = Color(0.18f, 0.22f, 0.18f, 1f)
    private val panel = Color(0.13f, 0.15f, 0.15f, 1f)
    private val grey = Color(0.45f, 0.48f, 0.48f, 1f)
    private val gold = Color(1f, 0.85f, 0.25f, 1f)
    private val tabOn = Color(0.28f, 0.42f, 0.30f, 1f)
    private val tabOff = Color(0.20f, 0.23f, 0.22f, 1f)
    private val cEquipped = Color(0.20f, 0.45f, 0.25f, 1f)
    private val cOwned = Color(0.20f, 0.28f, 0.38f, 1f)
    private val cResearched = Color(0.45f, 0.38f, 0.15f, 1f)
    private val cAvailable = Color(0.22f, 0.24f, 0.26f, 1f)
    private val cLocked = Color(0.11f, 0.11f, 0.12f, 1f)
    private val lineOn = Color(0.75f, 0.75f, 0.75f, 1f)
    private val lineOff = Color(0.30f, 0.30f, 0.30f, 1f)
    private val backColor = Color(0.40f, 0.20f, 0.20f, 1f)

    private val nodeW = 140f
    private val nodeH = 56f
    private val colStep = 156f
    private val x0 = 52f
    private val rowStep = 105f
    private val row0Y = 460f

    private fun nodeX(s: TankSpec) = x0 + (s.tier - 1) * colStep
    private fun nodeY(s: TankSpec) = row0Y - s.treeRow * rowStep

    private fun stateOf(s: TankSpec): State {
        val t = GameManager.techTree
        return when {
            t.isUnlocked(s.id) && GameManager.selectedTankId == s.id -> State.EQUIPPED
            t.isUnlocked(s.id) -> State.OWNED
            t.isResearched(s.id) -> State.RESEARCHED
            t.canResearch(s.id) -> State.AVAILABLE
            else -> State.LOCKED
        }
    }

    private fun colorOf(st: State): Color = when (st) {
        State.EQUIPPED -> cEquipped
        State.OWNED -> cOwned
        State.RESEARCHED -> cResearched
        State.AVAILABLE -> cAvailable
        State.LOCKED -> cLocked
    }

    override fun render(delta: Float) {
        Gdx.gl.glClearColor(bg.r, bg.g, bg.b, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        viewport.apply()
        game.batch.projectionMatrix = camera.combined

        val b = game.batch
        b.begin()
        drawHeader(b)
        drawTabs(b)
        drawTree(b)
        drawDetails(b)
        drawLegend(b)
        UiDraw.button(b, 40f, 25f, 220f, 70f, backColor, "< BACK")
        drawActionButton(b)
        if (message.isNotEmpty()) UiDraw.coloredText(b, message, 290f, 75f, gold)
        b.end()

        handleInput()
    }

    // ------------------------------------------------------------- drawing

    private fun drawHeader(b: SpriteBatch) {
        UiDraw.fillRect(b, 0f, 650f, 1280f, 70f, header)
        UiDraw.text(b, "TECH TREE & GARAGE", 40f, 695f)
        UiDraw.text(b, "Credits ${GameManager.wallet.credits}  |  XP ${GameManager.playerProfile.freeXp}", 720f, 695f)
    }

    private fun drawTabs(b: SpriteBatch) {
        nations.forEachIndexed { i, n ->
            UiDraw.button(b, 40f + i * 195f, 590f, 185f, 50f, if (n == nation) tabOn else tabOff, n.label)
        }
    }

    private fun drawTree(b: SpriteBatch) {
        UiDraw.fillRect(b, 40f, 235f, 780f, 340f, panel)
        UiDraw.outlineRect(b, 40f, 235f, 780f, 340f, 2f, grey)
        for (t in 1..5) UiDraw.text(b, "TIER $t", x0 + (t - 1) * colStep + 28f, 568f)

        val tanks = TankDatabase.byNation(nation)

        // Connection lines parent -> child
        for (child in tanks) {
            for (pid in child.parents) {
                val parent = TankDatabase.get(pid)
                if (parent.nation != nation) continue
                val on = GameManager.techTree.isResearched(child.id) || GameManager.techTree.isResearched(pid)
                val col = if (on) lineOn else lineOff
                val x1 = nodeX(parent) + nodeW
                val y1 = nodeY(parent) + nodeH / 2f
                val x2 = nodeX(child)
                val y2 = nodeY(child) + nodeH / 2f
                val xm = (x1 + x2) / 2f
                UiDraw.fillRect(b, x1, y1 - 1.5f, xm - x1, 3f, col)
                UiDraw.fillRect(b, xm - 1.5f, minOf(y1, y2) - 1.5f, 3f, Math.abs(y2 - y1) + 3f, col)
                UiDraw.fillRect(b, xm, y2 - 1.5f, x2 - xm, 3f, col)
            }
        }

        // Tank nodes
        for (s in tanks) {
            val st = stateOf(s)
            val x = nodeX(s)
            val y = nodeY(s)
            UiDraw.fillRect(b, x, y, nodeW, nodeH, colorOf(st))
            UiDraw.outlineRect(b, x, y, nodeW, nodeH, if (s.id == selectedId) 4f else 2f, if (s.id == selectedId) gold else grey)
            val textColor = if (st == State.LOCKED) grey else Color.WHITE
            UiDraw.coloredText(b, s.shortName, x + 8f, y + nodeH - 8f, textColor)
            UiDraw.coloredText(b, "T${s.tier} ${s.tankClass.label}", x + 8f, y + 28f, textColor)
        }
    }

    private fun drawDetails(b: SpriteBatch) {
        UiDraw.fillRect(b, 840f, 115f, 400f, 460f, panel)
        UiDraw.outlineRect(b, 840f, 115f, 400f, 460f, 2f, grey)
        val s = TankDatabase.get(selectedId)
        val a = s.armor
        val x = 855f
        UiDraw.wrapped(b, s.name, x, 560f, 370f)
        UiDraw.text(b, "Tier ${s.tier} | ${s.nation.label} | ${s.tankClass.label}", x, 500f)
        UiDraw.text(b, "Year ${s.year} | Crew ${s.crew}", x, 472f)
        UiDraw.text(b, "Mass ${s.massT} t | ${s.enginePowerHp} hp", x, 444f)
        UiDraw.text(b, "Hull ${s.hullLengthM}x${s.hullWidthM}x${s.hullHeightM} m", x, 416f)
        UiDraw.text(b, "${s.maxSpeedKmh} km/h | HP ${s.maxHp.toInt()}", x, 388f)
        UiDraw.text(b, "Hull F/S/R: ${a.hullFront.thicknessMm.toInt()}/${a.hullSide.thicknessMm.toInt()}/${a.hullRear.thicknessMm.toInt()} mm", x, 360f)
        UiDraw.text(b, "Slope F/S/R: ${a.hullFront.slopeDeg.toInt()}/${a.hullSide.slopeDeg.toInt()}/${a.hullRear.slopeDeg.toInt()} deg", x, 332f)
        val tLabel = if (s.hasTurret) "Turret" else "Casemate"
        UiDraw.text(b, "$tLabel F/S/R: ${a.turretFront.thicknessMm.toInt()}/${a.turretSide.thicknessMm.toInt()}/${a.turretRear.thicknessMm.toInt()} mm", x, 304f)
        UiDraw.text(b, "Gun: ${s.gun.name}", x, 276f)
        UiDraw.text(b, "Reload ${s.gun.reloadSec} s", x, 248f)
        var y = 220f
        for (ammo in s.gun.ammo) {
            val pen = if (ammo.pen100Mm == ammo.pen1000Mm) "${ammo.pen100Mm.toInt()}" else "${ammo.pen100Mm.toInt()}>${ammo.pen1000Mm.toInt()}"
            UiDraw.text(b, "${ammo.kind.code} $pen mm x${ammo.stock}", x, y)
            y -= 28f
        }
    }

    private fun drawLegend(b: SpriteBatch) {
        legend(b, 40f, 195f, cEquipped, "EQUIPPED")
        legend(b, 250f, 195f, cOwned, "OWNED")
        legend(b, 420f, 195f, cResearched, "RESEARCHED")
        legend(b, 40f, 155f, cAvailable, "RESEARCH (XP)")
        legend(b, 250f, 155f, cLocked, "LOCKED")
    }

    private fun legend(b: SpriteBatch, x: Float, y: Float, c: Color, label: String) {
        UiDraw.fillRect(b, x, y, 24f, 24f, c)
        UiDraw.outlineRect(b, x, y, 24f, 24f, 2f, grey)
        UiDraw.text(b, label, x + 32f, y + 22f)
    }

    private fun actionLabel(s: TankSpec): String = when (stateOf(s)) {
        State.EQUIPPED -> "EQUIPPED"
        State.OWNED -> "SELECT"
        State.RESEARCHED -> "BUY ${s.purchaseCostCredits} CR"
        State.AVAILABLE -> "RESEARCH ${s.researchCostXp} XP"
        State.LOCKED -> "LOCKED"
    }

    private fun drawActionButton(b: SpriteBatch) {
        val s = TankDatabase.get(selectedId)
        val col = when (stateOf(s)) {
            State.OWNED, State.RESEARCHED, State.AVAILABLE -> Color(0.20f, 0.50f, 0.25f, 1f)
            else -> Color(0.25f, 0.27f, 0.28f, 1f)
        }
        UiDraw.button(b, 860f, 25f, 380f, 80f, col, actionLabel(s))
    }

    // --------------------------------------------------------------- input

    private fun handleInput() {
        if (!Gdx.input.justTouched()) return
        touchPos.set(Gdx.input.x.toFloat(), Gdx.input.y.toFloat(), 0f)
        viewport.unproject(touchPos)
        val tx = touchPos.x
        val ty = touchPos.y

        if (UiDraw.hit(tx, ty, 40f, 25f, 220f, 70f)) {
            SaveManager.save()
            ScreenManager.setScreen(MainMenuScreen(game))
            return
        }

        nations.forEachIndexed { i, n ->
            if (UiDraw.hit(tx, ty, 40f + i * 195f, 590f, 185f, 50f) && n != nation) {
                nation = n
                val list = TankDatabase.byNation(n)
                selectedId = (list.firstOrNull { GameManager.techTree.isUnlocked(it.id) } ?: list.first()).id
                message = ""
            }
        }

        for (s in TankDatabase.byNation(nation)) {
            if (UiDraw.hit(tx, ty, nodeX(s), nodeY(s), nodeW, nodeH)) {
                selectedId = s.id
                message = ""
            }
        }

        if (UiDraw.hit(tx, ty, 860f, 25f, 380f, 80f)) doAction()
    }

    private fun doAction() {
        val s = TankDatabase.get(selectedId)
        val tree = GameManager.techTree
        when (stateOf(s)) {
            State.OWNED -> {
                GameManager.selectedTankId = s.id
                message = "${s.shortName} selected"
                SaveManager.save()
            }
            State.RESEARCHED -> {
                message = if (tree.buy(s.id)) "Bought ${s.shortName}" else "Not enough credits"
                SaveManager.save()
            }
            State.AVAILABLE -> {
                message = if (tree.research(s.id)) "Researched ${s.shortName}" else "Not enough XP"
                SaveManager.save()
            }
            State.LOCKED -> {
                val names = s.parents.joinToString(" or ") { TankDatabase.get(it).shortName }
                message = "Research $names first"
            }
            State.EQUIPPED -> {}
        }
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }
}
