package com.ironfront.entities

import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager
import com.ironfront.core.GameConfig
import com.ironfront.teams.Team
import com.ironfront.weapons.AmmoKind
import com.ironfront.weapons.AmmoSpec

/** A real shell: muzzle velocity and range come from the ammo, penetration falls with distance travelled. */
class ProjectileEntity(
    id: String,
    x: Float,
    y: Float,
    angleDeg: Float,
    val ownerId: String,
    val team: Team,
    val ammo: AmmoSpec
) : Entity(id, x, y, 14f, 6f) {

    val speedPx: Float = ammo.velocityMps / GameConfig.METERS_PER_PX
    var travelledPx: Float = 0f
        private set
    private var lifeTime = GameConfig.MAX_RANGE_M / ammo.velocityMps

    val distanceMeters: Float get() = travelledPx * GameConfig.METERS_PER_PX

    init {
        rotation = angleDeg
        velocity.set(MathUtils.cosDeg(angleDeg) * speedPx, MathUtils.sinDeg(angleDeg) * speedPx)
    }

    fun advance(dt: Float) {
        position.mulAdd(velocity, dt)
        travelledPx += speedPx * dt
        lifeTime -= dt
        if (lifeTime <= 0f) isAlive = false
    }

    override fun update(delta: Float) = advance(delta)

    override fun render(batch: SpriteBatch) {
        val explosive = ammo.kind == AmmoKind.HE || ammo.kind == AmmoKind.HEAT
        val region = AssetManager.getRegion(if (explosive) "shell_he" else "shell_ap")
        batch.draw(
            region,
            position.x - width / 2f, position.y - height / 2f,
            width / 2f, height / 2f, width, height, 1f, 1f, rotation
        )
    }
}
