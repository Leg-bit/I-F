package com.ironfront.entities

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.AssetManager
import com.ironfront.teams.Team
import com.ironfront.weapons.AmmoType

/**
 * A shell in flight. The world moves it in small steps and asks the damage model what happens on impact.
 * A shell that ricochets keeps flying with less speed and less penetration.
 */
class ProjectileEntity(
    id: String,
    x: Float,
    y: Float,
    angleDeg: Float,
    val ownerId: String,
    val team: Team,
    val ammoType: AmmoType,
    val baseDamage: Float,
    penetrationMm: Float,
    val caliberMm: Int,
    speed: Float
) : Entity(id, x, y, 10f + caliberMm / 8f, 3f + caliberMm / 30f) {

    var penetrationMm: Float = penetrationMm
        private set
    var speed: Float = speed
        private set
    var traveled: Float = 0f
    var bounces: Int = 0
        private set
    var ignoreTankId: String? = null
        private set
    var ignoreTimer: Float = 0f
        private set

    private var lifeTime = 2.6f

    init {
        rotation = angleDeg
    }

    /** Penetration drops a little over distance. */
    fun currentPenetration(): Float = penetrationMm * (1f - (traveled / 7000f).coerceAtMost(0.3f))

    fun ricochet(newAngleDeg: Float, tankId: String) {
        rotation = (newAngleDeg + 720f) % 360f
        speed *= 0.55f
        penetrationMm *= 0.5f
        bounces++
        ignoreTankId = tankId
        ignoreTimer = 0.25f
    }

    fun tick(delta: Float) {
        lifeTime -= delta
        if (ignoreTimer > 0f) ignoreTimer -= delta
        if (lifeTime <= 0f) isAlive = false
    }

    override fun update(delta: Float) {
        tick(delta)
    }

    override fun render(batch: SpriteBatch) {
        val region = AssetManager.getRegion("pixel")
        val c: Color = ammoType.color
        val dx = MathUtils.cosDeg(rotation)
        val dy = MathUtils.sinDeg(rotation)
        // faint tracer trail
        for (i in 1..3) {
            val back = i * width * 0.9f
            batch.setColor(c.r, c.g, c.b, 0.35f / i)
            batch.draw(
                region, position.x - dx * back - width / 2f, position.y - dy * back - height / 2f,
                width / 2f, height / 2f, width, height * 0.8f, 1f, 1f, rotation
            )
        }
        batch.setColor(c.r, c.g, c.b, 1f)
        batch.draw(region, position.x - width / 2f, position.y - height / 2f, width / 2f, height / 2f, width, height, 1f, 1f, rotation)
        batch.setColor(1f, 1f, 1f, 1f)
    }
}
