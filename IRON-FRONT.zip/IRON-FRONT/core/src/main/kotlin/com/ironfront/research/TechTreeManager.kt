package com.ironfront.research

import com.ironfront.core.GameManager
import com.ironfront.tanks.TankDatabase

/**
 * Two steps like a real tech tree:
 *  1. RESEARCH with XP (needs a researched parent tank)
 *  2. BUY with credits
 */
class TechTreeManager {
    val researchedTanks = mutableSetOf<String>()
    val unlockedTanks = mutableSetOf<String>()   // owned

    fun unlockTank(tankId: String) {
        researchedTanks.add(tankId)
        unlockedTanks.add(tankId)
    }

    fun isUnlocked(tankId: String): Boolean = unlockedTanks.contains(tankId)
    fun isResearched(tankId: String): Boolean = researchedTanks.contains(tankId)

    fun canResearch(tankId: String): Boolean {
        if (isResearched(tankId)) return false
        val spec = TankDatabase.get(tankId)
        return spec.parents.isEmpty() || spec.parents.any { researchedTanks.contains(it) }
    }

    fun research(tankId: String): Boolean {
        if (!canResearch(tankId)) return false
        val spec = TankDatabase.get(tankId)
        val profile = GameManager.playerProfile
        if (profile.freeXp < spec.researchCostXp) return false
        profile.freeXp -= spec.researchCostXp
        researchedTanks.add(tankId)
        return true
    }

    fun buy(tankId: String): Boolean {
        if (!isResearched(tankId) || isUnlocked(tankId)) return false
        val spec = TankDatabase.get(tankId)
        if (!GameManager.wallet.spendCredits(spec.purchaseCostCredits)) return false
        unlockedTanks.add(tankId)
        return true
    }
}
