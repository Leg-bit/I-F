package com.ironfront.research

import com.ironfront.core.GameManager
import com.ironfront.nations.Nation
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec

enum class NodeStatus { OWNED, AVAILABLE, LOCKED }

class TechTreeManager {
    val unlockedTanks = mutableSetOf<String>()

    fun unlockTank(tankId: String) {
        unlockedTanks.add(tankId)
    }

    fun isUnlocked(tankId: String): Boolean = unlockedTanks.contains(tankId)

    /** A tank can be researched once at least one of its parents is owned (or it has none). */
    fun parentsOwned(spec: TankSpec): Boolean = spec.parents.isEmpty() || spec.parents.any { isUnlocked(it) }

    fun status(spec: TankSpec): NodeStatus = when {
        isUnlocked(spec.id) -> NodeStatus.OWNED
        parentsOwned(spec) -> NodeStatus.AVAILABLE
        else -> NodeStatus.LOCKED
    }

    fun canAfford(spec: TankSpec): Boolean =
        GameManager.playerProfile.freeXp >= spec.researchCostXp &&
            GameManager.wallet.credits >= spec.purchaseCostCredits

    fun ownedCount(nation: Nation): Int = TankDatabase.ofNation(nation).count { isUnlocked(it.id) }

    fun researchAndBuy(tankId: String): Boolean {
        if (isUnlocked(tankId)) return true
        val spec = TankDatabase.get(tankId)
        if (!parentsOwned(spec)) return false
        if (GameManager.playerProfile.freeXp < spec.researchCostXp) return false
        if (!GameManager.wallet.spendCredits(spec.purchaseCostCredits)) return false
        GameManager.playerProfile.freeXp -= spec.researchCostXp
        unlockedTanks.add(tankId)
        return true
    }
}
