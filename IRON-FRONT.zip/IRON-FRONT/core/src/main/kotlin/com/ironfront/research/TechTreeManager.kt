package com.ironfront.research

import com.ironfront.core.GameManager
import com.ironfront.nations.Nation
import com.ironfront.tanks.TankDatabase
import com.ironfront.tanks.TankSpec

enum class NodeStatus { OWNED, AVAILABLE, LOCKED }

class TechTreeManager {
    val unlockedTanks = mutableSetOf<String>()
    val eliteTanks = mutableSetOf<String>()
    val tankXp = mutableMapOf<String, Int>()

    fun unlockTank(tankId: String) {
        unlockedTanks.add(tankId)
    }

    fun isUnlocked(tankId: String): Boolean = unlockedTanks.contains(tankId)
    fun isElite(tankId: String): Boolean = eliteTanks.contains(tankId)
    fun getTankXp(tankId: String): Int = tankXp[tankId] ?: 0

    fun addTankXp(tankId: String, amount: Int) {
        if (amount > 0) tankXp[tankId] = getTankXp(tankId) + amount
    }

    fun parentsOwned(spec: TankSpec): Boolean = spec.parents.isEmpty() || spec.parents.any { isUnlocked(it) }

    fun status(spec: TankSpec): NodeStatus = when {
        isUnlocked(spec.id) -> NodeStatus.OWNED
        parentsOwned(spec) -> NodeStatus.AVAILABLE
        else -> NodeStatus.LOCKED
    }

    /** XP you can spend on [spec]: your Free XP plus the Mastery XP of its parent tanks. */
    fun availableXpFor(spec: TankSpec): Int {
        var total = GameManager.playerProfile.freeXp
        for (pid in spec.parents) total += getTankXp(pid)
        return total
    }

    fun canAfford(spec: TankSpec): Boolean =
        availableXpFor(spec) >= spec.researchCostXp && GameManager.wallet.credits >= spec.purchaseCostCredits

    fun ownedCount(nation: Nation): Int = TankDatabase.ofNation(nation).count { isUnlocked(it.id) }

    fun researchAndBuy(tankId: String): Boolean {
        if (isUnlocked(tankId)) return true
        val spec = TankDatabase.get(tankId)
        if (!parentsOwned(spec)) return false
        if (availableXpFor(spec) < spec.researchCostXp) return false
        if (!GameManager.wallet.spendCredits(spec.purchaseCostCredits)) return false

        // Mastery XP of the parent tanks is spent first, then Free XP
        var remainingXp = spec.researchCostXp
        for (pid in spec.parents) {
            if (remainingXp <= 0) break
            val pXp = getTankXp(pid)
            val used = minOf(pXp, remainingXp)
            if (used > 0) {
                tankXp[pid] = pXp - used
                remainingXp -= used
            }
        }
        if (remainingXp > 0) {
            GameManager.playerProfile.freeXp = (GameManager.playerProfile.freeXp - remainingXp).coerceAtLeast(0)
        }
        unlockedTanks.add(tankId)
        return true
    }

    fun eliteUpgradeCostBonds(spec: TankSpec): Int = 10 + spec.tier * 8

    fun upgradeToElite(tankId: String): Boolean {
        if (!isUnlocked(tankId) || isElite(tankId)) return false
        val spec = TankDatabase.get(tankId)
        val cost = eliteUpgradeCostBonds(spec)
        if (!GameManager.wallet.spendWarBonds(cost)) return false
        eliteTanks.add(tankId)
        return true
    }
}
