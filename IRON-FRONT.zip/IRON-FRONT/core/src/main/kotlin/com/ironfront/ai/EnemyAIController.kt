package com.ironfront.ai

import com.badlogic.gdx.math.MathUtils
import com.ironfront.entities.ProjectileEntity
import com.ironfront.tanks.TankEntity
import com.ironfront.weapons.AmmoType
import kotlin.math.abs

/**
 * Works for both teams. A bot attacks the nearest tank of the opposing team.
 * Friendly bots follow [leader] (the player) when nothing is in range.
 * Casemate tank destroyers turn their whole hull towards the target.
 */
class EnemyAIController(val tank: TankEntity) {
    private var decisionTimer = 0f
    private var wanderAngle = MathUtils.random(0f, 360f)

    private var lastX = tank.position.x
    private var lastY = tank.position.y
    private var stuckTimer = 0f
    private var unstickTimer = 0f
    private var unstickSteer = 1f

    fun update(delta: Float, targets: List<TankEntity>, leader: TankEntity?): ProjectileEntity? {
        if (!tank.isAlive) return null
        decisionTimer -= delta

        var nearest: TankEntity? = null
        var nearestDist = Float.MAX_VALUE
        for (t in targets) {
            val d = tank.position.dst(t.position)
            if (d < nearestDist) {
                nearest = t
                nearestDist = d
            }
        }
        val target = nearest
        var shot: ProjectileEntity? = null

        if (target != null && nearestDist < ENGAGE_RANGE) {
            chooseAmmo(target)
            shot = engage(target, nearestDist)
        } else {
            tank.desiredTurretRotation = tank.rotation
            val boss = if (leader != null && leader.isAlive) leader else null
            when {
                boss != null && tank.position.dst(boss.position) > FOLLOW_DISTANCE -> {
                    steerTowards(angleTo(boss))
                    tank.throttleInput = 0.7f
                }
                boss != null -> {
                    tank.throttleInput = 0f
                    tank.steerInput = 0f
                }
                target != null -> {
                    steerTowards(angleTo(target))
                    tank.throttleInput = 0.55f
                }
                else -> wander()
            }
        }

        applyUnstick(delta)
        return shot
    }

    /** Use the best shell against the target's frontal armour. */
    private fun chooseAmmo(target: TankEntity) {
        val gun = tank.spec.gun
        val armor = target.spec.armor.hullFront.effective(0f)
        val ap = gun.availableAmmo.contains(AmmoType.AP)
        tank.weapon.selectAmmo(
            when {
                gun.apcrPen > 0f && gun.apPen < armor * 1.15f -> AmmoType.APCR
                gun.availableAmmo.contains(AmmoType.HE) && gun.hePen > armor * 0.95f -> AmmoType.HE
                ap -> AmmoType.AP
                else -> tank.weapon.currentAmmo
            }
        )
    }

    private fun engage(target: TankEntity, dist: Float): ProjectileEntity? {
        tank.aimTurretAt(target.position.x, target.position.y)
        val angle = angleTo(target)
        if (tank.spec.isCasemate) {
            steerTowards(angle)
            tank.throttleInput = if (dist > PREFERRED_DISTANCE) 0.5f else 0f
        } else {
            steerTowards(if (dist > PREFERRED_DISTANCE) angle else angle + 90f)
            tank.throttleInput = 0.7f
        }

        val turretDiff = abs(((tank.turretRotation - tank.desiredTurretRotation + 540f) % 360f) - 180f)
        return if (turretDiff < 6f) tank.fire() else null
    }

    private fun wander() {
        if (decisionTimer <= 0f) {
            wanderAngle = MathUtils.random(0f, 360f)
            decisionTimer = MathUtils.random(2.0f, 4.0f)
        }
        steerTowards(wanderAngle)
        tank.throttleInput = 0.45f
    }

    private fun angleTo(other: TankEntity): Float =
        MathUtils.atan2(
            other.position.y - tank.position.y,
            other.position.x - tank.position.x
        ) * MathUtils.radiansToDegrees

    private fun steerTowards(targetAngle: Float) {
        var diff = (targetAngle - tank.rotation) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f

        tank.steerInput = when {
            diff > 8f -> -1f
            diff < -8f -> 1f
            else -> 0f
        }
    }

    /** If the bot is pushing against something and not moving, back out for a moment. */
    private fun applyUnstick(delta: Float) {
        if (unstickTimer > 0f) {
            unstickTimer -= delta
            tank.throttleInput = -0.8f
            tank.steerInput = unstickSteer
            return
        }
        stuckTimer += delta
        if (stuckTimer >= 0.8f) {
            val moved = tank.position.dst(lastX, lastY)
            if (abs(tank.throttleInput) > 0.3f && moved < 12f) {
                unstickTimer = 0.7f
                unstickSteer = if (MathUtils.randomBoolean()) 1f else -1f
            }
            lastX = tank.position.x
            lastY = tank.position.y
            stuckTimer = 0f
        }
    }

    companion object {
        private const val ENGAGE_RANGE = 700f
        private const val PREFERRED_DISTANCE = 340f
        private const val FOLLOW_DISTANCE = 320f
    }
}
