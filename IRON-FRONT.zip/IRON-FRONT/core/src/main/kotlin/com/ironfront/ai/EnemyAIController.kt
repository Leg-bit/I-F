package com.ironfront.ai

import com.badlogic.gdx.math.MathUtils
import com.ironfront.core.GameConfig
import com.ironfront.entities.ProjectileEntity
import com.ironfront.tanks.TankEntity
import kotlin.math.abs

/**
 * Works for both teams. A bot attacks the nearest tank of the opposing team.
 * Friendly bots follow [leader] (the player) when nothing is in range.
 */
class EnemyAIController(val tank: TankEntity) {
    private var decisionTimer = 0f
    private var wanderAngle = MathUtils.random(0f, 360f)

    private var lastX = tank.position.x
    private var lastY = tank.position.y
    private var stuckTimer = 0f
    private var unstickTimer = 0f
    private var unstickSteer = 1f

    fun update(delta: Float, targets: List<TankEntity>, leader: TankEntity?): ProjectileEntity? {
        if (!tank.isAlive) return null
        decisionTimer -= delta

        var nearest: TankEntity? = null
        var nearestDist = Float.MAX_VALUE
        for (t in targets) {
            val d = tank.position.dst(t.position)
            if (d < nearestDist) {
                nearest = t
                nearestDist = d
            }
        }
        val target = nearest
        var shot: ProjectileEntity? = null

        if (target != null && nearestDist < ENGAGE_RANGE) {
            shot = engage(target, nearestDist)
        } else {
            tank.desiredTurretRotation = tank.rotation
            val boss = if (leader != null && leader.isAlive) leader else null
            when {
                boss != null && tank.position.dst(boss.position) > FOLLOW_DISTANCE -> {
                    steerTowards(angleTo(boss))
                    tank.throttleInput = 0.7f
                }
                boss != null -> {
                    tank.throttleInput = 0f
                    tank.steerInput = 0f
                }
                target != null -> {
                    steerTowards(angleTo(target))
                    tank.throttleInput = 0.55f
                }
                else -> wander()
            }
        }

        applyUnstick(delta)
        return shot
    }

    private fun engage(target: TankEntity, dist: Float): ProjectileEntity? {
        val distM = dist * GameConfig.METERS_PER_PX
        tank.weapon.selectBest(distM)

        // Lead the target: aim where it will be when the shell arrives.
        val shellSpeedPx = tank.weapon.currentAmmo.velocityMps / GameConfig.METERS_PER_PX
        val flightTime = dist / shellSpeedPx
        tank.aimTurretAt(
            target.position.x + target.velocity.x * flightTime,
            target.position.y + target.velocity.y * flightTime
        )

        val angle = angleTo(target)
        if (tank.spec.limitedTraverse) {
            // Casemate tank destroyer: point the whole hull at the target.
            steerTowards(angle)
            tank.throttleInput = if (dist > PREFERRED_DISTANCE) 0.6f else 0f
        } else {
            steerTowards(if (dist > PREFERRED_DISTANCE) angle else angle + 90f)
            tank.throttleInput = 0.7f
        }

        val turretDiff = abs(((tank.turretRotation - tank.desiredTurretRotation + 540f) % 360f) - 180f)
        return if (turretDiff < 5f) tank.fire() else null
    }

    private fun wander() {
        if (decisionTimer <= 0f) {
            wanderAngle = MathUtils.random(0f, 360f)
            decisionTimer = MathUtils.random(2.0f, 4.0f)
        }
        steerTowards(wanderAngle)
        tank.throttleInput = 0.45f
    }

    private fun angleTo(other: TankEntity): Float =
        MathUtils.atan2(
            other.position.y - tank.position.y,
            other.position.x - tank.position.x
        ) * MathUtils.radiansToDegrees

    private fun steerTowards(targetAngle: Float) {
        var diff = (targetAngle - tank.rotation) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f

        tank.steerInput = when {
            diff > 8f -> -1f
            diff < -8f -> 1f
            else -> 0f
        }
    }

    /** If the bot is pushing against something and not moving, back out for a moment. */
    private fun applyUnstick(delta: Float) {
        if (unstickTimer > 0f) {
            unstickTimer -= delta
            tank.throttleInput = -0.8f
            tank.steerInput = unstickSteer
            return
        }
        stuckTimer += delta
        if (stuckTimer >= 0.8f) {
            val moved = tank.position.dst(lastX, lastY)
            if (abs(tank.throttleInput) > 0.3f && moved < 12f) {
                unstickTimer = 0.7f
                unstickSteer = if (MathUtils.randomBoolean()) 1f else -1f
            }
            lastX = tank.position.x
            lastY = tank.position.y
            stuckTimer = 0f
        }
    }

    companion object {
        private const val ENGAGE_RANGE = 650f
        private const val PREFERRED_DISTANCE = 320f
        private const val FOLLOW_DISTANCE = 320f
    }
}
