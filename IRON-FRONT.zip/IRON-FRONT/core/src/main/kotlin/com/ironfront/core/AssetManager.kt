package com.ironfront.core

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.ironfront.art.TankArt
import com.ironfront.art.disc
import com.ironfront.art.fillPoly
import com.ironfront.art.outlinePoly
import com.ironfront.art.rect
import com.ironfront.art.shade
import com.ironfront.art.silhouette
import com.ironfront.maps.MapRegistry
import com.ironfront.tanks.TankDatabase
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Everything is painted in code, so the game needs no image files. */
object AssetManager {
    private val textures = mutableMapOf<String, Texture>()
    private val regions = mutableMapOf<String, TextureRegion>()
    private val pivots = mutableMapOf<String, Float>()

    lateinit var font: BitmapFont
        private set
    lateinit var fontSmall: BitmapFont
        private set
    lateinit var fontBig: BitmapFont
        private set

    fun loadAll() {
        TankDatabase.load()

        font = makeFont(1.35f)
        fontSmall = makeFont(1.0f)
        fontBig = makeFont(2.1f)

        textures["pixel"] = createRectTexture(2, 2, Color.WHITE)
        textures["circle"] = createCircleTexture()
        textures["glow"] = createGlowTexture()

        for (spec in TankDatabase.all()) {
            val built = TankArt.build(spec)
            val hullOutline = silhouette(built.hull, 2)
            val turretOutline = silhouette(built.turret, 2)
            textures["hull_${spec.id}"] = smooth(Texture(built.hull))
            textures["turret_${spec.id}"] = smooth(Texture(built.turret))
            textures["hullo_${spec.id}"] = smooth(Texture(hullOutline))
            textures["turreto_${spec.id}"] = smooth(Texture(turretOutline))
            pivots[spec.id] = built.pivotX.toFloat()
            built.hull.dispose()
            built.turret.dispose()
            hullOutline.dispose()
            turretOutline.dispose()
        }

        for (map in MapRegistry.all()) {
            for (v in 0 until 3) {
                textures["ground_${map.id}_$v"] = createGroundTile(map.groundColor, map.groundDetail, map.id.hashCode() * 7L + v)
            }
        }

        textures["obstacle_rock"] = createRockTexture(Color(0.42f, 0.42f, 0.45f, 1f), 11L, null)
        textures["obstacle_sandrock"] = createRockTexture(Color(0.70f, 0.58f, 0.38f, 1f), 12L, null)
        textures["obstacle_snowrock"] = createRockTexture(Color(0.45f, 0.47f, 0.52f, 1f), 13L, Color(0.93f, 0.96f, 1f, 1f))
        textures["obstacle_cliff"] = createCliffTexture()
        textures["obstacle_rubble"] = createRubbleTexture()
        textures["obstacle_building"] = createBuildingTexture()
        textures["obstacle_tree"] = createTreeTexture(false)
        textures["obstacle_pine"] = createTreeTexture(true)
    }

    fun getTexture(key: String): Texture = textures[key] ?: textures["pixel"]!!

    fun getRegion(key: String): TextureRegion = regions.getOrPut(key) { TextureRegion(getTexture(key)) }

    fun hasTexture(key: String): Boolean = textures.containsKey(key)

    fun pivotX(tankId: String): Float = pivots[tankId] ?: 0f

    // ----------------------------------------------------------------- fonts

    private fun makeFont(scale: Float): BitmapFont {
        val f = BitmapFont()
        f.data.setScale(scale)
        f.setUseIntegerPositions(false)
        f.region.texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        return f
    }

    private fun smooth(t: Texture): Texture {
        t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        return t
    }

    // -------------------------------------------------------------- textures

    private fun newPixmap(w: Int, h: Int): Pixmap {
        val pm = Pixmap(w, h, Pixmap.Format.RGBA8888)
        pm.setBlending(Pixmap.Blending.None)
        return pm
    }

    private fun toTexture(pm: Pixmap, linear: Boolean = false): Texture {
        val t = Texture(pm)
        if (linear) smooth(t)
        pm.dispose()
        return t
    }

    private fun createRectTexture(w: Int, h: Int, color: Color): Texture {
        val pm = newPixmap(w, h)
        pm.setColor(color)
        pm.fill()
        return toTexture(pm)
    }

    private fun createCircleTexture(): Texture {
        val pm = newPixmap(64, 64)
        pm.setColor(Color.WHITE)
        pm.fillCircle(32, 32, 31)
        return toTexture(pm, true)
    }

    private fun createGlowTexture(): Texture {
        val size = 32
        val pm = newPixmap(size, size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (x - size / 2f + 0.5f) / (size / 2f)
                val dy = (y - size / 2f + 0.5f) / (size / 2f)
                val d = sqrt(dx * dx + dy * dy)
                val a = (1f - d).coerceIn(0f, 1f)
                pm.setColor(1f, 1f, 1f, a * a)
                pm.drawPixel(x, y)
            }
        }
        return toTexture(pm, true)
    }

    private fun createGroundTile(base: Color, detail: Color, seed: Long): Texture {
        val pm = newPixmap(64, 64)
        pm.setColor(base)
        pm.fill()
        val rnd = Random(seed)
        // soft blotches, wrapped so the tile repeats without seams
        for (i in 0 until 7) {
            val c = shade(base, 0.93f + rnd.nextFloat() * 0.14f)
            val cx = rnd.nextInt(64)
            val cy = rnd.nextInt(64)
            val r = 4 + rnd.nextInt(9)
            for (ox in -64..64 step 64) {
                for (oy in -64..64 step 64) {
                    pm.disc(cx + ox, cy + oy, r, c)
                }
            }
        }
        pm.setColor(detail)
        for (i in 0 until 30) pm.drawPixel(rnd.nextInt(64), rnd.nextInt(64))
        pm.setColor(shade(base, 1.18f))
        for (i in 0 until 10) pm.drawPixel(rnd.nextInt(64), rnd.nextInt(64))
        return toTexture(pm)
    }

    private fun createRockTexture(base: Color, seed: Long, cap: Color?): Texture {
        val pm = newPixmap(64, 64)
        val rnd = Random(seed)
        val pts = IntArray(18)
        pts[0] = 32
        pts[1] = 32
        for (i in 0 until 8) {
            val ang = i * Math.PI / 4.0 + 0.2
            val rad = 25.0 + rnd.nextInt(6)
            pts[2 + i * 2] = 32 + (cos(ang) * rad).toInt()
            pts[3 + i * 2] = 32 + (sin(ang) * rad).toInt()
        }
        // shadow, body, highlight
        val shadow = IntArray(18)
        for (i in pts.indices) shadow[i] = pts[i] + (if (i % 2 == 0) 3 else -3)
        shadow[0] = 35
        shadow[1] = 29
        pm.fillPoly(Color(0f, 0f, 0f, 0.35f), *shadow)
        pm.fillPoly(base, *pts)
        val inner = IntArray(18)
        for (i in pts.indices) inner[i] = if (i % 2 == 0) 28 + (pts[i] - 32) * 6 / 10 else 36 + (pts[i] - 32) * 6 / 10
        inner[0] = 28
        inner[1] = 36
        pm.fillPoly(shade(base, 1.22f), *inner)
        pm.outlinePoly(shade(base, 0.55f), pts.copyOfRange(2, pts.size))
        pm.setColor(shade(base, 0.6f))
        pm.drawLine(22, 24, 30, 34)
        pm.drawLine(40, 44, 46, 36)
        if (cap != null) {
            pm.fillPoly(cap, 26, 24, 38, 18, 46, 26, 38, 32, 28, 34)
        }
        return toTexture(pm, true)
    }

    private fun createCliffTexture(): Texture {
        val pm = newPixmap(64, 64)
        val base = Color(0.52f, 0.34f, 0.22f, 1f)
        pm.setColor(base)
        pm.fill()
        val rnd = Random(21L)
        for (i in 0 until 6) {
            pm.rect(0, i * 11, 64, 5, shade(base, 0.88f + rnd.nextFloat() * 0.2f))
        }
        pm.setColor(shade(base, 0.55f))
        pm.drawRectangle(0, 0, 64, 64)
        pm.drawRectangle(1, 1, 62, 62)
        for (i in 0 until 5) {
            val x = rnd.nextInt(54)
            val y = rnd.nextInt(54)
            pm.rect(x, y, 6 + rnd.nextInt(6), 4, shade(base, 0.7f))
        }
        return toTexture(pm)
    }

    private fun createRubbleTexture(): Texture {
        val pm = newPixmap(64, 64)
        val base = Color(0.40f, 0.36f, 0.32f, 1f)
        pm.setColor(shade(base, 0.7f))
        pm.fill()
        val rnd = Random(31L)
        for (i in 0 until 18) {
            val w = 8 + rnd.nextInt(14)
            val h = 6 + rnd.nextInt(10)
            val x = rnd.nextInt(64 - w)
            val y = rnd.nextInt(64 - h)
            val c = shade(base, 0.8f + rnd.nextFloat() * 0.5f)
            pm.rect(x, y, w, h, c)
            pm.setColor(shade(c, 0.6f))
            pm.drawRectangle(x, y, w, h)
        }
        pm.setColor(shade(base, 0.5f))
        pm.drawRectangle(0, 0, 64, 64)
        return toTexture(pm)
    }

    private fun createBuildingTexture(): Texture {
        val pm = newPixmap(64, 64)
        val roof = Color(0.34f, 0.31f, 0.30f, 1f)
        pm.setColor(roof)
        pm.fill()
        pm.rect(3, 3, 58, 58, shade(roof, 1.12f))
        pm.setColor(shade(roof, 0.55f))
        pm.drawRectangle(0, 0, 64, 64)
        pm.drawRectangle(1, 1, 62, 62)
        pm.drawRectangle(3, 3, 58, 58)
        pm.rect(31, 3, 2, 58, shade(roof, 0.7f))
        pm.rect(3, 31, 58, 2, shade(roof, 0.7f))
        pm.rect(9, 9, 12, 10, Color(0.50f, 0.50f, 0.52f, 1f))
        pm.rect(40, 40, 14, 12, Color(0.28f, 0.27f, 0.27f, 1f))
        pm.rect(42, 10, 8, 8, Color(0.45f, 0.30f, 0.25f, 1f))
        pm.rect(10, 42, 9, 9, Color(0.50f, 0.50f, 0.52f, 1f))
        return toTexture(pm)
    }

    private fun createTreeTexture(pine: Boolean): Texture {
        val pm = newPixmap(64, 64)
        val base = if (pine) Color(0.12f, 0.30f, 0.22f, 1f) else Color(0.20f, 0.42f, 0.16f, 1f)
        pm.disc(35, 29, 25, Color(0f, 0f, 0f, 0.30f))
        pm.disc(32, 32, 25, shade(base, 0.7f))
        pm.disc(30, 34, 19, base)
        pm.disc(27, 37, 12, shade(base, 1.25f))
        val rnd = Random(if (pine) 41L else 42L)
        pm.setColor(shade(base, 1.5f))
        for (i in 0 until 14) pm.drawPixel(18 + rnd.nextInt(24), 22 + rnd.nextInt(24))
        pm.setColor(shade(base, 0.5f))
        for (i in 0 until 10) pm.drawPixel(18 + rnd.nextInt(30), 20 + rnd.nextInt(26))
        return toTexture(pm, true)
    }

    fun dispose() {
        regions.clear()
        textures.values.forEach { it.dispose() }
        textures.clear()
        font.dispose()
        fontSmall.dispose()
        fontBig.dispose()
    }
}
