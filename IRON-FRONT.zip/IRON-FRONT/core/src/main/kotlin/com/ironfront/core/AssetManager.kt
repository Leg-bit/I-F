package com.ironfront.core

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.ironfront.maps.MapRegistry
import com.ironfront.tanks.Nation

object AssetManager {
    private val textures = mutableMapOf<String, Texture>()
    private val regions = mutableMapOf<String, TextureRegion>()
    lateinit var font: BitmapFont
        private set

    fun loadAll() {
        font = BitmapFont()
        font.data.setScale(1.4f)

        textures["pixel"] = createRectTexture(2, 2, Color.WHITE)
        // One paint scheme per nation (stretched to each tank's real hull size when drawn).
        for (n in Nation.values()) {
            textures["hull_${n.name}"] = createTankHullTexture(n.body, n.track)
        }
        textures["circle_white"] = createCircleTexture()

        // White silhouette, tinted blue (friend) or red (enemy) at draw time.
        textures["tank_hull_outline"] = createRectTexture(72, 52, Color.WHITE)

        textures["shell_ap"] = createRectTexture(12, 4, Color(1f, 0.85f, 0.2f, 1f))
        textures["shell_he"] = createRectTexture(14, 6, Color(1f, 0.4f, 0.1f, 1f))

        textures["ground_tile"] = createGroundTileTexture(Color(0.32f, 0.30f, 0.24f, 1f), Color(0.28f, 0.26f, 0.20f, 1f))
        for (map in MapRegistry.all()) {
            textures["ground_${map.id}"] = createGroundTileTexture(map.groundColor, map.groundDetail)
        }

        textures["obstacle_rock"] = createBlockTexture(Color(0.35f, 0.35f, 0.38f, 1f), Color(0.22f, 0.22f, 0.25f, 1f))
        textures["obstacle_cliff"] = createBlockTexture(Color(0.50f, 0.33f, 0.22f, 1f), Color(0.32f, 0.20f, 0.13f, 1f))
        textures["obstacle_rubble"] = createBlockTexture(Color(0.38f, 0.34f, 0.30f, 1f), Color(0.24f, 0.21f, 0.18f, 1f))
        textures["obstacle_building"] = createBuildingTexture()
    }

    fun getTexture(key: String): Texture = textures[key] ?: textures["pixel"]!!

    fun getRegion(key: String): TextureRegion = regions.getOrPut(key) { TextureRegion(getTexture(key)) }

    private fun createRectTexture(w: Int, h: Int, color: Color): Texture {
        val pixmap = Pixmap(w, h, Pixmap.Format.RGBA8888)
        pixmap.setColor(color)
        pixmap.fill()
        val tex = Texture(pixmap)
        pixmap.dispose()
        return tex
    }

    private fun createTankHullTexture(bodyColor: Color, trackColor: Color): Texture {
        val pixmap = Pixmap(64, 44, Pixmap.Format.RGBA8888)
        pixmap.setColor(trackColor)
        pixmap.fillRectangle(0, 0, 64, 8)
        pixmap.fillRectangle(0, 36, 64, 8)
        pixmap.setColor(bodyColor)
        pixmap.fillRectangle(4, 7, 56, 30)
        pixmap.setColor(Color(1f, 1f, 1f, 0.25f))
        pixmap.fillRectangle(52, 9, 6, 26)
        val tex = Texture(pixmap)
        pixmap.dispose()
        return tex
    }

    private fun createCircleTexture(): Texture {
        val pixmap = Pixmap(64, 64, Pixmap.Format.RGBA8888)
        pixmap.setColor(Color.WHITE)
        pixmap.fillCircle(32, 32, 31)
        val tex = Texture(pixmap)
        pixmap.dispose()
        return tex
    }

    private fun createGroundTileTexture(base: Color, detail: Color): Texture {
        val pixmap = Pixmap(64, 64, Pixmap.Format.RGBA8888)
        pixmap.setColor(base)
        pixmap.fill()
        pixmap.setColor(detail)
        pixmap.drawRectangle(0, 0, 64, 64)
        pixmap.fillCircle(18, 22, 3)
        pixmap.fillCircle(46, 48, 2)
        val tex = Texture(pixmap)
        pixmap.dispose()
        return tex
    }

    private fun createBlockTexture(base: Color, edge: Color): Texture {
        val pixmap = Pixmap(64, 64, Pixmap.Format.RGBA8888)
        pixmap.setColor(base)
        pixmap.fill()
        pixmap.setColor(edge)
        pixmap.drawRectangle(0, 0, 64, 64)
        pixmap.drawRectangle(1, 1, 62, 62)
        pixmap.fillRectangle(14, 16, 10, 8)
        pixmap.fillRectangle(38, 38, 12, 10)
        val tex = Texture(pixmap)
        pixmap.dispose()
        return tex
    }

    private fun createBuildingTexture(): Texture {
        val pixmap = Pixmap(64, 64, Pixmap.Format.RGBA8888)
        pixmap.setColor(Color(0.30f, 0.28f, 0.27f, 1f))
        pixmap.fill()
        pixmap.setColor(Color(0.18f, 0.17f, 0.16f, 1f))
        pixmap.drawRectangle(0, 0, 64, 64)
        pixmap.drawRectangle(1, 1, 62, 62)
        pixmap.setColor(Color(0.45f, 0.42f, 0.38f, 1f))
        for (wx in 0 until 3) {
            for (wy in 0 until 3) {
                pixmap.fillRectangle(10 + wx * 18, 10 + wy * 18, 10, 10)
            }
        }
        val tex = Texture(pixmap)
        pixmap.dispose()
        return tex
    }

    fun dispose() {
        regions.clear()
        textures.values.forEach { it.dispose() }
        textures.clear()
        font.dispose()
    }
}
