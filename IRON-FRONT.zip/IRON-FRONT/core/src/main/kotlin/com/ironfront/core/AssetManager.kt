package com.ironfront.core

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.ironfront.art.TankArt
import com.ironfront.art.disc
import com.ironfront.art.fillPoly
import com.ironfront.art.outlinePoly
import com.ironfront.art.rect
import com.ironfront.art.shade
import com.ironfront.art.silhouette
import com.ironfront.maps.MapRegistry
import com.ironfront.tanks.TankDatabase
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Everything is painted in code, so the game needs no image files. */
object AssetManager {
    private val textures = mutableMapOf<String, Texture>()
    private val regions = mutableMapOf<String, TextureRegion>()
    private val pivots = mutableMapOf<String, Float>()

    lateinit var font: BitmapFont
        private set
    lateinit var fontSmall: BitmapFont
        private set
    lateinit var fontBig: BitmapFont
        private set

    fun loadAll() {
        TankDatabase.load()
        Shaders.init()

        font = makeFont(1.35f)
        fontSmall = makeFont(1.0f)
        fontBig = makeFont(2.1f)

        textures["pixel"] = createRectTexture(2, 2, Color.WHITE)
        textures["circle"] = createCircleTexture()
        textures["glow"] = createGlowTexture()

        for (spec in TankDatabase.all()) {
            val built = TankArt.build(spec)
            val hullOutline = silhouette(built.hull, 2)
            val turretOutline = silhouette(built.turret, 2)
            textures["hull_${spec.id}"] = smooth(Texture(built.hull))
            textures["turret_${spec.id}"] = smooth(Texture(built.turret))
            textures["hullo_${spec.id}"] = smooth(Texture(hullOutline))
            textures["turreto_${spec.id}"] = smooth(Texture(turretOutline))
            pivots[spec.id] = built.pivotX.toFloat()
            built.hull.dispose()
            built.turret.dispose()
            hullOutline.dispose()
            turretOutline.dispose()
        }

        for (map in MapRegistry.all()) {
            for (v in 0 until 3) {
                textures["ground_${map.id}_$v"] = createGroundTile(map.groundColor, map.groundDetail, map.id.hashCode() * 7L + v)
            }
        }

        textures["obstacle_rock"] = createRockTexture(Color(0.42f, 0.42f, 0.45f, 1f), 11L, null)
        textures["obstacle_sandrock"] = createRockTexture(Color(0.70f, 0.58f, 0.38f, 1f), 12L, null)
        textures["obstacle_snowrock"] = createRockTexture(Color(0.45f, 0.47f, 0.52f, 1f), 13L, Color(0.93f, 0.96f, 1f, 1f))
        textures["obstacle_cliff"] = createCliffTexture()
        textures["obstacle_rubble"] = createRubbleTexture()
        textures["obstacle_building"] = createBuildingTexture()
        textures["obstacle_tree"] = createTreeTexture(false)
        textures["obstacle_pine"] = createTreeTexture(true)

        // ruins, forest, flat decoration
        val wallH0 = createWallPixmap(31L)
        val wallH1 = createWallPixmap(32L)
        textures["obstacle_wallv0"] = toTexture(transpose(wallH0), true)
        textures["obstacle_wallv1"] = toTexture(transpose(wallH1), true)
        textures["obstacle_wallh0"] = toTexture(wallH0, true)
        textures["obstacle_wallh1"] = toTexture(wallH1, true)
        val bags = createSandbagPixmap()
        textures["obstacle_sandbag_v"] = toTexture(transpose(bags), true)
        textures["obstacle_sandbag"] = toTexture(bags, true)
        textures["obstacle_bush"] = createBushTexture()
        textures["obstacle_deadtree"] = createDeadTreeTexture()
        textures["obstacle_debris"] = createDebrisTexture()
        textures["obstacle_hedgehog"] = createHedgehogTexture()
        textures["decor_crater"] = createCraterTexture()
        textures["decor_road"] = createRoadTexture()
        textures["decor_floor"] = createFloorTexture()
        textures["decor_ice"] = createLakeTexture(Color(0.72f, 0.86f, 0.95f, 1f), true)
        textures["decor_sand"] = createLakeTexture(Color(0.55f, 0.43f, 0.26f, 1f), false)
        textures["decor_dune"] = createDuneTexture()
    }

    fun getTexture(key: String): Texture = textures[key] ?: textures["pixel"]!!

    fun getRegion(key: String): TextureRegion = regions.getOrPut(key) { TextureRegion(getTexture(key)) }

    fun hasTexture(key: String): Boolean = textures.containsKey(key)

    fun pivotX(tankId: String): Float = pivots[tankId] ?: 0f

    // ----------------------------------------------------------------- fonts

    private fun makeFont(scale: Float): BitmapFont {
        val f = BitmapFont()
        f.data.setScale(scale)
        f.setUseIntegerPositions(false)
        f.region.texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        return f
    }

    private fun smooth(t: Texture): Texture {
        t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        return t
    }

    // -------------------------------------------------------------- textures

    private fun newPixmap(w: Int, h: Int): Pixmap {
        val pm = Pixmap(w, h, Pixmap.Format.RGBA8888)
        pm.setBlending(Pixmap.Blending.None)
        return pm
    }

    private fun toTexture(pm: Pixmap, linear: Boolean = false): Texture {
        val t = Texture(pm)
        if (linear) smooth(t)
        pm.dispose()
        return t
    }

    private fun createRectTexture(w: Int, h: Int, color: Color): Texture {
        val pm = newPixmap(w, h)
        pm.setColor(color)
        pm.fill()
        return toTexture(pm)
    }

    private fun createCircleTexture(): Texture {
        val pm = newPixmap(64, 64)
        pm.setColor(Color.WHITE)
        pm.fillCircle(32, 32, 31)
        return toTexture(pm, true)
    }

    private fun createGlowTexture(): Texture {
        val size = 32
        val pm = newPixmap(size, size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (x - size / 2f + 0.5f) / (size / 2f)
                val dy = (y - size / 2f + 0.5f) / (size / 2f)
                val d = sqrt(dx * dx + dy * dy)
                val a = (1f - d).coerceIn(0f, 1f)
                pm.setColor(1f, 1f, 1f, a * a)
                pm.drawPixel(x, y)
            }
        }
        return toTexture(pm, true)
    }

    private fun createGroundTile(base: Color, detail: Color, seed: Long): Texture {
        val pm = newPixmap(64, 64)
        pm.setColor(base)
        pm.fill()
        val rnd = Random(seed)
        // soft blotches, wrapped so the tile repeats without seams
        for (i in 0 until 7) {
            val c = shade(base, 0.93f + rnd.nextFloat() * 0.14f)
            val cx = rnd.nextInt(64)
            val cy = rnd.nextInt(64)
            val r = 4 + rnd.nextInt(9)
            for (ox in -64..64 step 64) {
                for (oy in -64..64 step 64) {
                    pm.disc(cx + ox, cy + oy, r, c)
                }
            }
        }
        pm.setColor(detail)
        for (i in 0 until 30) pm.drawPixel(rnd.nextInt(64), rnd.nextInt(64))
        pm.setColor(shade(base, 1.18f))
        for (i in 0 until 10) pm.drawPixel(rnd.nextInt(64), rnd.nextInt(64))
        return toTexture(pm)
    }

    private fun createRockTexture(base: Color, seed: Long, cap: Color?): Texture {
        val pm = newPixmap(64, 64)
        val rnd = Random(seed)
        val pts = IntArray(18)
        pts[0] = 32
        pts[1] = 32
        for (i in 0 until 8) {
            val ang = i * Math.PI / 4.0 + 0.2
            val rad = 25.0 + rnd.nextInt(6)
            pts[2 + i * 2] = 32 + (cos(ang) * rad).toInt()
            pts[3 + i * 2] = 32 + (sin(ang) * rad).toInt()
        }
        // shadow, body, highlight
        val shadow = IntArray(18)
        for (i in pts.indices) shadow[i] = pts[i] + (if (i % 2 == 0) 3 else -3)
        shadow[0] = 35
        shadow[1] = 29
        pm.fillPoly(Color(0f, 0f, 0f, 0.35f), *shadow)
        pm.fillPoly(base, *pts)
        val inner = IntArray(18)
        for (i in pts.indices) inner[i] = if (i % 2 == 0) 28 + (pts[i] - 32) * 6 / 10 else 36 + (pts[i] - 32) * 6 / 10
        inner[0] = 28
        inner[1] = 36
        pm.fillPoly(shade(base, 1.22f), *inner)
        pm.outlinePoly(shade(base, 0.55f), pts.copyOfRange(2, pts.size))
        pm.setColor(shade(base, 0.6f))
        pm.drawLine(22, 24, 30, 34)
        pm.drawLine(40, 44, 46, 36)
        if (cap != null) {
            pm.fillPoly(cap, 26, 24, 38, 18, 46, 26, 38, 32, 28, 34)
        }
        return toTexture(pm, true)
    }

    private fun createCliffTexture(): Texture {
        val pm = newPixmap(64, 64)
        val base = Color(0.52f, 0.34f, 0.22f, 1f)
        pm.setColor(base)
        pm.fill()
        val rnd = Random(21L)
        for (i in 0 until 6) {
            pm.rect(0, i * 11, 64, 5, shade(base, 0.88f + rnd.nextFloat() * 0.2f))
        }
        pm.setColor(shade(base, 0.55f))
        pm.drawRectangle(0, 0, 64, 64)
        pm.drawRectangle(1, 1, 62, 62)
        for (i in 0 until 5) {
            val x = rnd.nextInt(54)
            val y = rnd.nextInt(54)
            pm.rect(x, y, 6 + rnd.nextInt(6), 4, shade(base, 0.7f))
        }
        return toTexture(pm)
    }

    private fun createRubbleTexture(): Texture {
        val pm = newPixmap(64, 64)
        val base = Color(0.40f, 0.36f, 0.32f, 1f)
        pm.setColor(shade(base, 0.7f))
        pm.fill()
        val rnd = Random(31L)
        for (i in 0 until 18) {
            val w = 8 + rnd.nextInt(14)
            val h = 6 + rnd.nextInt(10)
            val x = rnd.nextInt(64 - w)
            val y = rnd.nextInt(64 - h)
            val c = shade(base, 0.8f + rnd.nextFloat() * 0.5f)
            pm.rect(x, y, w, h, c)
            pm.setColor(shade(c, 0.6f))
            pm.drawRectangle(x, y, w, h)
        }
        pm.setColor(shade(base, 0.5f))
        pm.drawRectangle(0, 0, 64, 64)
        return toTexture(pm)
    }

    private fun createBuildingTexture(): Texture {
        val pm = newPixmap(64, 64)
        val roof = Color(0.34f, 0.31f, 0.30f, 1f)
        pm.setColor(roof)
        pm.fill()
        pm.rect(3, 3, 58, 58, shade(roof, 1.12f))
        pm.setColor(shade(roof, 0.55f))
        pm.drawRectangle(0, 0, 64, 64)
        pm.drawRectangle(1, 1, 62, 62)
        pm.drawRectangle(3, 3, 58, 58)
        pm.rect(31, 3, 2, 58, shade(roof, 0.7f))
        pm.rect(3, 31, 58, 2, shade(roof, 0.7f))
        pm.rect(9, 9, 12, 10, Color(0.50f, 0.50f, 0.52f, 1f))
        pm.rect(40, 40, 14, 12, Color(0.28f, 0.27f, 0.27f, 1f))
        pm.rect(42, 10, 8, 8, Color(0.45f, 0.30f, 0.25f, 1f))
        pm.rect(10, 42, 9, 9, Color(0.50f, 0.50f, 0.52f, 1f))
        return toTexture(pm)
    }

    private fun createTreeTexture(pine: Boolean): Texture {
        val pm = newPixmap(64, 64)
        val base = if (pine) Color(0.12f, 0.30f, 0.22f, 1f) else Color(0.20f, 0.42f, 0.16f, 1f)
        pm.disc(35, 29, 25, Color(0f, 0f, 0f, 0.30f))
        pm.disc(32, 32, 25, shade(base, 0.7f))
        pm.disc(30, 34, 19, base)
        pm.disc(27, 37, 12, shade(base, 1.25f))
        val rnd = Random(if (pine) 41L else 42L)
        pm.setColor(shade(base, 1.5f))
        for (i in 0 until 14) pm.drawPixel(18 + rnd.nextInt(24), 22 + rnd.nextInt(24))
        pm.setColor(shade(base, 0.5f))
        for (i in 0 until 10) pm.drawPixel(18 + rnd.nextInt(30), 20 + rnd.nextInt(26))
        return toTexture(pm, true)
    }

    private fun transpose(src: Pixmap): Pixmap {
        val out = newPixmap(src.height, src.width)
        for (y in 0 until src.height) {
            for (x in 0 until src.width) {
                out.drawPixel(y, x, src.getPixel(x, y))
            }
        }
        return out
    }

    /** Broken brick wall piece, 96x24, with a ragged top edge. */
    private fun createWallPixmap(seed: Long): Pixmap {
        val pm = newPixmap(96, 24)
        val rnd = Random(seed)
        val base = Color(0.52f, 0.40f, 0.33f, 1f)
        pm.setColor(shade(base, 0.55f))
        pm.fill()
        var row = 0
        var y = 0
        while (y < 24) {
            var x = -(if (row % 2 == 0) 0 else 7)
            while (x < 96) {
                val c = shade(base, 0.82f + rnd.nextFloat() * 0.38f)
                pm.rect(x + 1, y + 1, 13, 5, c)
                x += 14
            }
            y += 6
            row++
        }
        // ragged top edge
        var cut = 3
        for (x in 0 until 96) {
            cut = (cut + rnd.nextInt(3) - 1).coerceIn(0, 7)
            for (yy in 0 until cut) {
                pm.setColor(0f, 0f, 0f, 0f)
                pm.drawPixel(x, yy)
            }
            pm.setColor(shade(base, 1.3f))
            pm.drawPixel(x, cut)
        }
        // dark shadow along the bottom
        pm.rect(0, 22, 96, 2, shade(base, 0.40f))
        // chipped bricks
        for (i in 0 until 7) {
            pm.rect(rnd.nextInt(90), 6 + rnd.nextInt(14), 3 + rnd.nextInt(4), 3, shade(base, 0.45f))
        }
        return pm
    }

    private fun createSandbagPixmap(): Pixmap {
        val pm = newPixmap(64, 28)
        val bag = Color(0.68f, 0.60f, 0.42f, 1f)
        for (row in 0 until 2) {
            val y = 3 + row * 11
            var x = if (row == 0) 2 else 10
            while (x < 58) {
                pm.disc(x + 6, y + 6, 6, shade(bag, 0.7f))
                pm.rect(x + 2, y + 1, 12, 10, shade(bag, 0.7f))
                pm.rect(x + 3, y + 2, 10, 7, bag)
                pm.rect(x + 3, y + 2, 10, 2, shade(bag, 1.15f))
                x += 14
            }
        }
        return pm
    }

    private fun createBushTexture(): Texture {
        val pm = newPixmap(64, 64)
        val rnd = Random(51L)
        val base = Color(0.20f, 0.36f, 0.15f, 1f)
        for (i in 0 until 9) {
            val cx = 14 + rnd.nextInt(36)
            val cy = 14 + rnd.nextInt(36)
            pm.disc(cx, cy, 12 + rnd.nextInt(6), shade(base, 0.7f + rnd.nextFloat() * 0.2f))
        }
        for (i in 0 until 8) {
            pm.disc(14 + rnd.nextInt(36), 14 + rnd.nextInt(36), 6 + rnd.nextInt(4), shade(base, 1.0f + rnd.nextFloat() * 0.4f))
        }
        pm.setColor(shade(base, 1.7f))
        for (i in 0 until 22) pm.drawPixel(10 + rnd.nextInt(44), 10 + rnd.nextInt(44))
        return toTexture(pm, true)
    }

    private fun createDeadTreeTexture(): Texture {
        val pm = newPixmap(64, 64)
        val rnd = Random(52L)
        val bark = Color(0.26f, 0.20f, 0.15f, 1f)
        for (i in 0 until 9) {
            val ang = i * 40.0 + rnd.nextInt(20)
            val len = 18 + rnd.nextInt(14)
            val ex = 32 + (cos(Math.toRadians(ang)) * len).toInt()
            val ey = 32 + (sin(Math.toRadians(ang)) * len).toInt()
            pm.setColor(bark)
            pm.drawLine(32, 32, ex, ey)
            pm.drawLine(33, 32, ex + 1, ey)
            pm.drawLine(32, 33, ex, ey + 1)
            for (k in 0 until 2) {
                val a2 = Math.toRadians(ang + (if (k == 0) 35.0 else -35.0))
                val sx = 32 + (cos(Math.toRadians(ang)) * len * 0.6).toInt()
                val sy = 32 + (sin(Math.toRadians(ang)) * len * 0.6).toInt()
                pm.drawLine(sx, sy, sx + (cos(a2) * 10).toInt(), sy + (sin(a2) * 10).toInt())
            }
        }
        pm.disc(32, 32, 3, shade(bark, 0.7f))
        return toTexture(pm, true)
    }

    private fun createDebrisTexture(): Texture {
        val pm = newPixmap(64, 64)
        val rnd = Random(53L)
        pm.setColor(0f, 0f, 0f, 0.30f)
        pm.fillCircle(34, 30, 26)
        for (i in 0 until 26) {
            val a = rnd.nextFloat() * 6.28f
            val r = rnd.nextFloat() * 22f
            val x = 32 + (cos(a) * r).toInt()
            val y = 32 + (sin(a) * r).toInt()
            val w = 4 + rnd.nextInt(9)
            val h = 3 + rnd.nextInt(6)
            val tone = if (rnd.nextBoolean()) Color(0.55f, 0.40f, 0.32f, 1f) else Color(0.45f, 0.45f, 0.46f, 1f)
            val c = shade(tone, 0.7f + rnd.nextFloat() * 0.5f)
            pm.rect(x - w / 2, y - h / 2, w, h, c)
            pm.setColor(shade(c, 0.5f))
            pm.drawRectangle(x - w / 2, y - h / 2, w, h)
        }
        return toTexture(pm, true)
    }

    private fun createHedgehogTexture(): Texture {
        val pm = newPixmap(48, 48)
        val steel = Color(0.32f, 0.33f, 0.35f, 1f)
        pm.disc(26, 26, 18, Color(0f, 0f, 0f, 0.25f))
        for (i in 0 until 3) {
            val a = Math.toRadians(i * 60.0 + 15.0)
            val dx = (cos(a) * 19).toInt()
            val dy = (sin(a) * 19).toInt()
            for (o in -1..1) {
                pm.setColor(if (o == 0) shade(steel, 1.35f) else steel)
                pm.drawLine(24 - dx + o, 24 - dy, 24 + dx + o, 24 + dy)
                pm.drawLine(24 - dx, 24 - dy + o, 24 + dx, 24 + dy + o)
            }
        }
        pm.disc(24, 24, 3, shade(steel, 0.6f))
        return toTexture(pm, true)
    }

    private fun createCraterTexture(): Texture {
        val size = 128
        val pm = newPixmap(size, size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (x - 63.5f) / 64f
                val dy = (y - 63.5f) / 64f
                val d = sqrt(dx * dx + dy * dy)
                if (d >= 1f) continue
                val alpha: Float
                val c: Float
                when {
                    d < 0.55f -> {
                        c = 0.07f + d * 0.10f
                        alpha = 0.85f
                    }
                    d < 0.78f -> {
                        c = 0.18f + (d - 0.55f) * 1.0f
                        alpha = 0.80f
                    }
                    else -> {
                        c = 0.38f
                        alpha = (1f - d) / 0.22f * 0.65f
                    }
                }
                pm.setColor(c * 0.95f, c * 0.85f, c * 0.70f, alpha.coerceIn(0f, 1f))
                pm.drawPixel(x, y)
            }
        }
        return toTexture(pm, true)
    }

    private fun createRoadTexture(): Texture {
        val pm = newPixmap(128, 64)
        val rnd = Random(54L)
        for (y in 0 until 64) {
            val dist = kotlin.math.abs(y - 31.5f) / 32f
            val alpha = if (dist < 0.62f) 0.95f else ((1f - dist) / 0.38f * 0.95f).coerceIn(0f, 1f)
            val rut = if (kotlin.math.abs(dist - 0.38f) < 0.07f) 0.80f else 1f
            for (x in 0 until 128) {
                val n = 0.92f + rnd.nextFloat() * 0.16f
                pm.setColor(0.46f * rut * n, 0.38f * rut * n, 0.27f * rut * n, alpha)
                pm.drawPixel(x, y)
            }
        }
        return toTexture(pm, true)
    }

    private fun createFloorTexture(): Texture {
        val pm = newPixmap(128, 128)
        val rnd = Random(55L)
        val base = Color(0.40f, 0.38f, 0.35f, 1f)
        pm.setColor(shade(base, 0.6f))
        pm.fill()
        var y = 0
        while (y < 128) {
            var x = 0
            while (x < 128) {
                pm.rect(x + 1, y + 1, 14, 14, shade(base, 0.80f + rnd.nextFloat() * 0.35f))
                x += 16
            }
            y += 16
        }
        pm.setColor(shade(base, 0.45f))
        for (i in 0 until 6) {
            val x = rnd.nextInt(120)
            val yy = rnd.nextInt(120)
            pm.drawLine(x, yy, x + rnd.nextInt(24) - 12, yy + rnd.nextInt(24) - 12)
        }
        return toTexture(pm, true)
    }

    /** Soft round zone: frozen lake (cracked ice) or quicksand (swirls). */
    private fun createLakeTexture(base: Color, ice: Boolean): Texture {
        val size = 128
        val pm = newPixmap(size, size)
        val rnd = Random(if (ice) 56L else 57L)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (x - 63.5f) / 64f
                val dy = (y - 63.5f) / 64f
                val d = sqrt(dx * dx + dy * dy)
                if (d >= 1f) continue
                val edge = if (d < 0.78f) 1f else ((1f - d) / 0.22f).coerceIn(0f, 1f)
                var tone = 0.9f + 0.15f * sin(d * 18f + (if (ice) 0f else 2f))
                if (!ice && d > 0.2f) tone *= 0.9f + 0.1f * sin(d * 40f)
                pm.setColor(
                    (base.r * tone).coerceIn(0f, 1f),
                    (base.g * tone).coerceIn(0f, 1f),
                    (base.b * tone).coerceIn(0f, 1f),
                    edge * 0.88f
                )
                pm.drawPixel(x, y)
            }
        }
        if (ice) {
            pm.setColor(1f, 1f, 1f, 0.8f)
            for (i in 0 until 10) {
                val x = 25 + rnd.nextInt(78)
                val y = 25 + rnd.nextInt(78)
                pm.drawLine(x, y, x + rnd.nextInt(30) - 15, y + rnd.nextInt(30) - 15)
            }
        }
        return toTexture(pm, true)
    }

    private fun createDuneTexture(): Texture {
        val w = 128
        val h = 64
        val pm = newPixmap(w, h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val dx = (x - 63.5f) / 64f
                val dy = (y - 31.5f) / 32f
                val d = sqrt(dx * dx + dy * dy)
                if (d >= 1f) continue
                val a = (1f - d) * 0.55f
                if (y < 30) pm.setColor(0.90f, 0.80f, 0.58f, a) else pm.setColor(0.52f, 0.41f, 0.27f, a * 0.85f)
                pm.drawPixel(x, y)
            }
        }
        return toTexture(pm, true)
    }

    fun dispose() {
        regions.clear()
        textures.values.forEach { it.dispose() }
        textures.clear()
        Shaders.dispose()
        font.dispose()
        fontSmall.dispose()
        fontBig.dispose()
    }
}
