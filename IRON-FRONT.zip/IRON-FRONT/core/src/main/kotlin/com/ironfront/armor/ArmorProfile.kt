package com.ironfront.armor

/** Plate thickness in mm and slope measured from the vertical in degrees (0 = vertical, 60 = heavily sloped). */
data class ArmorPlate(val thicknessMm: Float, val slopeDeg: Float)

data class ArmorScheme(
    val hullFront: ArmorPlate,
    val hullSide: ArmorPlate,
    val hullRear: ArmorPlate,
    val turretFront: ArmorPlate,
    val turretSide: ArmorPlate,
    val turretRear: ArmorPlate
)

enum class HitZone { FRONT, SIDE, REAR }
enum class HitSection { HULL, TURRET }
