package com.ironfront.armor

import kotlin.math.cos

enum class HitZone { FRONT, SIDE, REAR }

enum class HitPart { HULL, TURRET }

/**
 * One armour plate.
 * [thicknessMm] is the real plate thickness, [slopeDeg] is the plate angle from the vertical
 * (0 = vertical plate, 60 = heavily sloped like the T-34 glacis).
 */
data class ArmorFace(val thicknessMm: Float, val slopeDeg: Float = 0f) {
    /** Line-of-sight thickness for a shell that arrives [impactDeviationDeg] off the plate normal. */
    fun effective(impactDeviationDeg: Float): Float {
        val total = (slopeDeg + impactDeviationDeg).coerceIn(0f, 80f)
        return thicknessMm / cos(Math.toRadians(total.toDouble())).toFloat()
    }
}

/** Hull + turret (or casemate) armour on three sides. */
data class ArmorProfile(
    val hullFront: ArmorFace,
    val hullSide: ArmorFace,
    val hullRear: ArmorFace,
    val turretFront: ArmorFace,
    val turretSide: ArmorFace,
    val turretRear: ArmorFace
) {
    val frontMm: Float get() = hullFront.thicknessMm
    val sideMm: Float get() = hullSide.thicknessMm
    val rearMm: Float get() = hullRear.thicknessMm

    fun face(part: HitPart, zone: HitZone): ArmorFace = when (part) {
        HitPart.HULL -> when (zone) {
            HitZone.FRONT -> hullFront
            HitZone.SIDE -> hullSide
            HitZone.REAR -> hullRear
        }
        HitPart.TURRET -> when (zone) {
            HitZone.FRONT -> turretFront
            HitZone.SIDE -> turretSide
            HitZone.REAR -> turretRear
        }
    }
}
