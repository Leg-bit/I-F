# IRON FRONT 2.0

2D top-down tank game for Android (Kotlin + libGDX). Everything (tank sprites, ground, sounds) is generated in code, so there are no image or audio files to manage.

## What's new in 2.0
- 38 real tanks from 5 nations (Germany, USSR, USA, United Kingdom, Japan), tiers 1-6, with a branching tech tree per nation.
- Detailed top-down 2D models painted from real dimensions (hull, tracks, skirts, turret shape, bustle, cupola, muzzle brake, camouflage, national markings).
- Real data per tank: weight, crew, engine hp, speed, armour thickness and slope for hull and turret on front/side/rear, gun, calibre, reload, muzzle velocity, AP/APCR/HE penetration.
- Armour model: shell angle + plate slope, ricochet (AP 70 deg, APCR 68 deg), overmatch (calibre >= 3x plate), effective thickness, penetration falloff over distance, ricochet bounce.
- Casemate tank destroyers with limited gun traverse, open-top turrets.
- Currencies: Credits, Gold, XP, daily supply, exchange screen, equipment shop.
- New UI: main menu, garage with full spec sheet, tech tree, exchange, battle setup (maps, allies, enemies, nations, level), minimap, result screen.
- Particle effects and synthesised sound effects.

## Build
GitHub Actions builds the APK automatically (`.github/workflows/build.yml`). Locally: `gradle :android:assembleDebug`.
