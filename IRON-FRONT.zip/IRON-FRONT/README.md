# IRON FRONT 3.1.1

2D top-down tank game for Android (Kotlin + libGDX). Everything (tank sprites, ground, sounds) is generated in code, so there are no image or audio files to manage.

## 3.1.1
- Fixed the third-person / sight camera rolling sideways while aiming (the camera's up direction was not reset every frame, so the tilt piled up while the turret turned).
- In the third-person and sight views the aim stick is now a turn-rate stick: push right = turn right, harder = faster (85 deg/s in third person, 26 deg/s in the sight), so the view no longer whips around. The top view still points the gun where the stick points.

## 3.1 - War Thunder style 3D
- Three cameras, switch with the CAM button in battle: CHASE (third person behind the tank, looking where the turret points), SIGHT (zoomed gunner's sight from the gun mount with scope, cross hair and range finder) and TOP (the tilted tactical view). The sticks are relative to the view: in CHASE and SIGHT stick-up means "where the camera looks".
- Cross hair with range in metres (red when an enemy tank is under it), reload bar and shell type + penetration.
- Graphics: sky gradient per map, distance haze that matches the sky, a ring of mountains on the horizon, huge ground plane, shadows (MEDIUM = soft blob shadows, HIGH = real shadow map), more detailed tank models (hatches, tool boxes, exhaust pipes, bore evacuators).
- VIEW button in Battle Setup cycles 2D / 3D LOW / 3D MEDIUM / 3D HIGH. If shadows cannot start on a device, HIGH quietly runs without them.

## 3.0.1 - updates keep your progress
- Every build is now signed with the same fixed key (`android/ironfront.keystore`, keep it in the repo and never replace it), so a new APK installs OVER the old one without uninstalling. The workflow prints the key fingerprint on every build.
- Rules for updating: same package (`com.ironfront.game`), same keystore, higher versionCode (raise it in `android/build.gradle.kts` for every new build).
- COPY SAVE / PASTE SAVE on the main menu: the whole save as one line of text, to keep in a notes app. Use it before any reinstall.
- One-time migration: APKs built before 3.0.1 were signed with a random key, so the first install of 3.0.1 still needs the old app removed once.

## 3.0 - 3D view
- Battles are now shown in 3D with a tilted camera: tanks built from their real dimensions (hull, tracks, road wheels, turret, barrel, muzzle brake; the painted top-down sprite is the roof), 3D forests (pines, broadleaf, dead trees), brick walls, cliffs, rocks, bushes, wrecks, roads and craters lying on the ground, lit by a sun.
- Gameplay and controls are unchanged: screen-up is still north. The fog / spotlight, light flashes, tint and vignette work in 3D through a shader that finds the ground point under every pixel.
- Setup screen has a VIEW toggle (3D / 2D light). If 3D can't start on a device the game falls back to 2D automatically.

## 2.3.1
- Tank explanation diagram in the Garage: the tank with blue leader lines ending in flat lines that give the gun (calibre, AP/APCR penetration), turret or casemate armour, hull front (with slope and effective mm), hull side and hull rear armour in mm.
- Spotlight: a much wider fan, `[tank]<`, whose width depends on the tank class (light 112 deg, medium 96, heavy 84, tank destroyer 76), softer edges, lighter fog. Vision range is shown in metres.

## What's new in 2.3
- New tactical look: obsidian palette, blueprint grid with radar scanline, shadowed panels with corner ticks, bevelled buttons, tier badges (I-VI), 10-segment stat bars.
- War Bonds (4th currency): earned from victories (3/6/12 by level), the Daily Combat Contract (destroy 5 enemy tanks) and the 7-day login streak. Can also be bought with Gold.
- Tank Mastery XP: battle XP is credited to the tank you played; it is spent first when researching its successors (a quarter also becomes Free XP).
- Elite Field Modification (War Bonds): permanent +8% HP, +6% speed, +6% reload for that tank.
- Main menu hangar hub with Firepower / Armor / Mobility / Reload bars, daily contract card, win rate. Garage class filter (ALL/LT/MT/HT/TD). Shop: war bond packs and login streak.
- Battle HUD: quick AP / APCR / HE selector, health bars shown only after a hit.

## 2.2.1 control fixes
- Aiming never fires. The turret stick only turns the turret; shooting is only the FIRE button (hold to keep shooting), so you can't waste a shot and lose the reload by accident. Tap-to-fire and auto-fire were removed.
- The move stick works from anywhere on the left side of the screen (it appears under your thumb), and the aim stick from anywhere on the right. The AMMO and REPAIR buttons moved to the top so thumbs don't hit them by accident.

## What's new in 2.2
- New controls: floating sticks (they appear under your thumb), DIRECT move mode (point where the tank should go; point backwards to reverse) or classic TANK mode, hold-to-fire FIRE button with a reload ring, tap the screen to aim and fire when on target, optional auto-fire. Switch modes on the main menu.
- Better tank movement: smooth steering, heavier tanks turn slower at speed, acceleration by power-to-weight, camera glides and looks ahead along the turret.
- Shaders (GLSL, with automatic fallback if a device can't compile them): bump-lit tank sprites, GPU fog/spotlight with line of sight, dynamic light from muzzle flashes and explosions, per-map colour tint, vignette. Fog is now one draw call instead of thousands.
- Graphics: tank drop shadows, tread marks, exhaust smoke, additive glowing flashes and sparks.

## What's new in 2.1
- Vision spotlight `[tank]<`: a cone in front of the turret plus a small circle around the hull. Enemies outside it are hidden in the fog. Walls, rocks, trunks and wrecks block sight, bushes hide tanks, firing reveals you for a moment, allies share vision. Coated Optics equipment extends range. Toggle in setup or during battle.
- Maps rebuilt: forests with tree canopies drawn over tanks, ruined houses with breakable brick walls, craters, dirt roads, cliffs, sandbags, tank hedgehogs, burnt-out wrecks, dunes, bushes, mud/quicksand/ice that slow tanks.
- Recoil: turret slides back, the hull is shoved backwards, dust blast, screen shake. Bigger guns kick harder.
- Sound: engine loop that follows speed, reload clunk, heavy/light gun pitch by calibre, stereo pan, wall and tree crashes, ground impacts, victory and defeat jingles.

## What's new in 2.0
- 38 real tanks from 5 nations (Germany, USSR, USA, United Kingdom, Japan), tiers 1-6, with a branching tech tree per nation.
- Detailed top-down 2D models painted from real dimensions (hull, tracks, skirts, turret shape, bustle, cupola, muzzle brake, camouflage, national markings).
- Real data per tank: weight, crew, engine hp, speed, armour thickness and slope for hull and turret on front/side/rear, gun, calibre, reload, muzzle velocity, AP/APCR/HE penetration.
- Armour model: shell angle + plate slope, ricochet (AP 70 deg, APCR 68 deg), overmatch (calibre >= 3x plate), effective thickness, penetration falloff over distance, ricochet bounce.
- Casemate tank destroyers with limited gun traverse, open-top turrets.
- Currencies: Credits, Gold, XP, daily supply, exchange screen, equipment shop.
- New UI: main menu, garage with full spec sheet, tech tree, exchange, battle setup (maps, allies, enemies, nations, level), minimap, result screen.
- Particle effects and synthesised sound effects.

## Build
GitHub Actions builds the APK automatically (`.github/workflows/build.yml`). Locally: `gradle :android:assembleDebug`.
