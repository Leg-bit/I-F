# IRON-FRONT (2D Top-Down Tactical Tank Warfare)

Game aksi taktis tank 2D Top-Down berbasis **libGDX** & **Kotlin**, dioptimalkan untuk **Android 8.0+ (API 26)** dengan dukungan native library **armeabi-v7a** dan **arm64-v8a**.

## Gameplay flow
Main menu -> **PLAY** -> **Battle Setup** (pick map, number of allies/enemies, fixed or random sides, level) -> **DEPLOY!**

- Maps: Steppe Dawn, Rocky Canyon, Urban Ruins (defined in `maps/MapData.kt`)
- Bots are either **friend (blue outline)** or **enemy (red outline)**
- In *random sides* mode every bot flips a coin to join your team or the enemy

## Real-life tank model
- 25 tanks, 4 nations (USSR, Germany, USA, UK) in `tanks/TankDatabase.kt`; guns and ammo in `weapons/Guns.kt`
- Hull is drawn at real size (10 px per metre), gun barrel at real length
- Armor: thickness + slope per plate (hull/turret x front/side/rear)
- Shell logic (`combat/DamageCalculator.kt`): obliquity, ricochet angle, overmatch, normalization per ammo type
  (AP, APCBC, APCR, HEAT, HE), penetration falls with distance flown
- Tech tree: RESEARCH (XP, needs a researched parent) -> BUY (credits) -> SELECT
