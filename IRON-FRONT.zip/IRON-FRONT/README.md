# IRON FRONT 2.2

2D top-down tank game for Android (Kotlin + libGDX). Everything (tank sprites, ground, sounds) is generated in code, so there are no image or audio files to manage.

## 2.2.1 control fixes
- Aiming never fires. The turret stick only turns the turret; shooting is only the FIRE button (hold to keep shooting), so you can't waste a shot and lose the reload by accident. Tap-to-fire and auto-fire were removed.
- The move stick works from anywhere on the left side of the screen (it appears under your thumb), and the aim stick from anywhere on the right. The AMMO and REPAIR buttons moved to the top so thumbs don't hit them by accident.

## What's new in 2.2
- New controls: floating sticks (they appear under your thumb), DIRECT move mode (point where the tank should go; point backwards to reverse) or classic TANK mode, hold-to-fire FIRE button with a reload ring, tap the screen to aim and fire when on target, optional auto-fire. Switch modes on the main menu.
- Better tank movement: smooth steering, heavier tanks turn slower at speed, acceleration by power-to-weight, camera glides and looks ahead along the turret.
- Shaders (GLSL, with automatic fallback if a device can't compile them): bump-lit tank sprites, GPU fog/spotlight with line of sight, dynamic light from muzzle flashes and explosions, per-map colour tint, vignette. Fog is now one draw call instead of thousands.
- Graphics: tank drop shadows, tread marks, exhaust smoke, additive glowing flashes and sparks.

## What's new in 2.1
- Vision spotlight `[tank]<`: a cone in front of the turret plus a small circle around the hull. Enemies outside it are hidden in the fog. Walls, rocks, trunks and wrecks block sight, bushes hide tanks, firing reveals you for a moment, allies share vision. Coated Optics equipment extends range. Toggle in setup or during battle.
- Maps rebuilt: forests with tree canopies drawn over tanks, ruined houses with breakable brick walls, craters, dirt roads, cliffs, sandbags, tank hedgehogs, burnt-out wrecks, dunes, bushes, mud/quicksand/ice that slow tanks.
- Recoil: turret slides back, the hull is shoved backwards, dust blast, screen shake. Bigger guns kick harder.
- Sound: engine loop that follows speed, reload clunk, heavy/light gun pitch by calibre, stereo pan, wall and tree crashes, ground impacts, victory and defeat jingles.

## What's new in 2.0
- 38 real tanks from 5 nations (Germany, USSR, USA, United Kingdom, Japan), tiers 1-6, with a branching tech tree per nation.
- Detailed top-down 2D models painted from real dimensions (hull, tracks, skirts, turret shape, bustle, cupola, muzzle brake, camouflage, national markings).
- Real data per tank: weight, crew, engine hp, speed, armour thickness and slope for hull and turret on front/side/rear, gun, calibre, reload, muzzle velocity, AP/APCR/HE penetration.
- Armour model: shell angle + plate slope, ricochet (AP 70 deg, APCR 68 deg), overmatch (calibre >= 3x plate), effective thickness, penetration falloff over distance, ricochet bounce.
- Casemate tank destroyers with limited gun traverse, open-top turrets.
- Currencies: Credits, Gold, XP, daily supply, exchange screen, equipment shop.
- New UI: main menu, garage with full spec sheet, tech tree, exchange, battle setup (maps, allies, enemies, nations, level), minimap, result screen.
- Particle effects and synthesised sound effects.

## Build
GitHub Actions builds the APK automatically (`.github/workflows/build.yml`). Locally: `gradle :android:assembleDebug`.
